package fr.phonemcp;

/* JADX INFO: loaded from: classes.dex */
public final class BuildConfig {
    public static final String APPLICATION_ID = "fr.phonemcp";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final int VERSION_CODE = 18;
    public static final String VERSION_NAME = "0.8.2";
}
