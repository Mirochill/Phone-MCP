package fr.phonemcp;

import android.content.Context;
import android.os.Binder;
import android.os.IBinder;
import android.os.Process;
import android.os.SystemClock;
import android.view.SurfaceControl;
import java.util.Iterator;
import java.util.Objects;
import java.util.concurrent.Callable;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public final class BackgroundControlService extends IBackgroundControl.Stub {
    private final FileEngine files;
    private IBinder owner;
    private final int ownerUid;
    private final VirtualEngine engine = new VirtualEngine();
    private final IBinder.DeathRecipient death = new IBinder.DeathRecipient() { // from class: fr.phonemcp.BackgroundControlService$$ExternalSyntheticLambda5
        @Override // android.os.IBinder.DeathRecipient
        public final void binderDied() {
            this.f$0.ownerGone();
        }
    };

    /* JADX INFO: Access modifiers changed from: private */
    public void ownerGone() {
        this.engine.destroy();
        this.files.destroy();
        System.exit(0);
    }

    public BackgroundControlService(Context context) throws Exception {
        int i = context.getApplicationInfo().uid;
        this.ownerUid = i;
        this.files = new FileEngine(context, i);
    }

    private void enforceCaller() {
        int callingUid = Binder.getCallingUid();
        if (callingUid != this.ownerUid && callingUid != Process.myUid()) {
            throw new SecurityException("Appelant non autorisé");
        }
    }

    private String wrap(Callable<JSONObject> callable) {
        try {
            return new JSONObject().put("ok", true).put("result", callable.call()).toString();
        } catch (Exception e) {
            return error(e);
        }
    }

    static String error(Exception exc) {
        try {
            return new JSONObject().put("ok", false).put("error", exc.getMessage() == null ? exc.getClass().getSimpleName() : exc.getMessage()).toString();
        } catch (Exception unused) {
            return "{\"ok\":false,\"error\":\"Erreur du service\"}";
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ JSONObject lambda$start$0(IBinder iBinder, long j, boolean z, boolean z2) throws Exception {
        if (iBinder == null) {
            throw new SecurityException("Session sans propriétaire");
        }
        IBinder iBinder2 = this.owner;
        if (iBinder2 != null) {
            iBinder2.unlinkToDeath(this.death, 0);
        }
        this.owner = iBinder;
        iBinder.linkToDeath(this.death, 0);
        this.files.start(j);
        JSONObject jSONObjectPut = new JSONObject().put("ready", false);
        if (z) {
            try {
                jSONObjectPut = this.engine.start(j, z2);
            } catch (Exception e) {
                jSONObjectPut.put("error", e.getMessage());
            }
        }
        return merge(jSONObjectPut);
    }

    @Override // fr.phonemcp.IBackgroundControl
    public String start(final long j, final IBinder iBinder, final boolean z, final boolean z2) {
        enforceCaller();
        return wrap(new Callable() { // from class: fr.phonemcp.BackgroundControlService$$ExternalSyntheticLambda6
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return this.f$0.lambda$start$0(iBinder, j, z2, z);
            }
        });
    }

    private JSONObject merge(JSONObject jSONObject) throws Exception {
        JSONObject jSONObjectStatus = this.files.status();
        Iterator<String> itKeys = jSONObjectStatus.keys();
        while (itKeys.hasNext()) {
            String next = itKeys.next();
            jSONObject.put(next, jSONObjectStatus.get(next));
        }
        return jSONObject;
    }

    @Override // fr.phonemcp.IBackgroundControl
    public String restorePanel() {
        enforceCaller();
        final VirtualEngine virtualEngine = this.engine;
        Objects.requireNonNull(virtualEngine);
        return wrap(new Callable() { // from class: fr.phonemcp.BackgroundControlService$$ExternalSyntheticLambda3
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return virtualEngine.restorePanel();
            }
        });
    }

    @Override // fr.phonemcp.IBackgroundControl
    public void setPreviewCallback(IPreviewCallback iPreviewCallback) {
        enforceCaller();
        this.engine.setPreviewCallback(iPreviewCallback);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ JSONObject lambda$attachPreview$1(String str, SurfaceControl surfaceControl) throws Exception {
        return this.engine.attachPreview(previewArgs(str), surfaceControl);
    }

    @Override // fr.phonemcp.IBackgroundControl
    public String attachPreview(final String str, final SurfaceControl surfaceControl) {
        enforceCaller();
        return wrap(new Callable() { // from class: fr.phonemcp.BackgroundControlService$$ExternalSyntheticLambda1
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return this.f$0.lambda$attachPreview$1(str, surfaceControl);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ JSONObject lambda$renewPreview$2(String str) throws Exception {
        return this.engine.renewPreview(previewArgs(str));
    }

    @Override // fr.phonemcp.IBackgroundControl
    public String renewPreview(final String str) {
        enforceCaller();
        return wrap(new Callable() { // from class: fr.phonemcp.BackgroundControlService$$ExternalSyntheticLambda0
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return this.f$0.lambda$renewPreview$2(str);
            }
        });
    }

    @Override // fr.phonemcp.IBackgroundControl
    public void detachPreview(String str) {
        enforceCaller();
        this.engine.detachPreview(str);
    }

    private JSONObject previewArgs(String str) throws Exception {
        if (str == null || str.length() > 20000) {
            throw new IllegalArgumentException("Arguments invalides");
        }
        return new JSONObject(str);
    }

    @Override // fr.phonemcp.IBackgroundControl
    public String previewFrame(final String str) {
        enforceCaller();
        return wrap(new Callable() { // from class: fr.phonemcp.BackgroundControlService$$ExternalSyntheticLambda2
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return this.f$0.lambda$previewFrame$3(str);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ JSONObject lambda$previewFrame$3(String str) throws Exception {
        if (str == null || str.length() > 20000) {
            throw new IllegalArgumentException("Arguments invalides");
        }
        return this.engine.previewFrame(new JSONObject(str));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ JSONObject lambda$execute$4(String str, String str2) throws Exception {
        if (str == null || str.length() > 20000) {
            throw new IllegalArgumentException("Arguments invalides");
        }
        JSONObject jSONObject = new JSONObject(str);
        if ("control_mode".equals(str2)) {
            if (this.owner == null || !SessionPolicy.active(true, SystemClock.elapsedRealtime(), jSONObject.getLong("deadline"))) {
                throw new SecurityException("Session de contrôle arrêtée.");
            }
            String string = jSONObject.getString("mode");
            if (!"foreground".equals(string) && !"parallel".equals(string)) {
                throw new IllegalArgumentException("Mode inconnu.");
            }
            if ("parallel".equals(string)) {
                return merge(this.engine.start(jSONObject.getLong("deadline"), jSONObject.optBoolean("panelOff")));
            }
            this.engine.stop();
            return merge(this.engine.execute("status", new JSONObject()));
        }
        if (str2.startsWith("file") || "download_file".equals(str2) || "install_apk".equals(str2)) {
            return this.files.execute(str2, jSONObject);
        }
        JSONObject jSONObjectExecute = this.engine.execute(str2, jSONObject);
        return "status".equals(str2) ? merge(jSONObjectExecute) : jSONObjectExecute;
    }

    @Override // fr.phonemcp.IBackgroundControl
    public String execute(final String str, final String str2) {
        enforceCaller();
        return wrap(new Callable() { // from class: fr.phonemcp.BackgroundControlService$$ExternalSyntheticLambda4
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return this.f$0.lambda$execute$4(str2, str);
            }
        });
    }

    @Override // fr.phonemcp.IBackgroundControl
    public void stop() {
        enforceCaller();
        this.files.stop();
        this.engine.stop();
    }

    @Override // fr.phonemcp.IBackgroundControl
    public void destroy() {
        enforceCaller();
        IBinder iBinder = this.owner;
        if (iBinder != null) {
            iBinder.unlinkToDeath(this.death, 0);
        }
        this.files.destroy();
        this.engine.destroy();
        System.exit(0);
    }
}
