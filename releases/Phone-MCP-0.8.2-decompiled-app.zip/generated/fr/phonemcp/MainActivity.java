package fr.phonemcp;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.res.ColorStateList;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowInsets;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.function.Predicate;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.internal.ws.RealWebSocket;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import rikka.shizuku.Shizuku;
import rikka.shizuku.ShizukuProvider;

/* JADX INFO: loaded from: classes.dex */
public final class MainActivity extends Activity {
    private static final int ACCENT = -8067634;
    private static final int BG = -16051941;
    private static final int CARD = -15458515;
    private static final int LINE = -14075830;
    private static final int MUTED = -5983291;
    private static final int RED = -19793;
    private static final int TEXT = -1182726;
    private LinearLayout body;
    private Settings config;
    private TextView connectionStatus;
    private Spinner duration;
    private EditText endpoint;
    private LinearLayout filesBody;
    private boolean filesBusy;
    private int mode;
    private Switch panelOff;
    private TextView requirements;
    private Button restore;
    private LinearLayout root;
    private TextView sessionDetail;
    private TextView sessionTitle;
    private Button start;
    private Button stop;
    private int tab;
    private EditText token;
    private String filesFingerprint = HttpUrl.FRAGMENT_ENCODE_SET;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Shizuku.OnRequestPermissionResultListener shizukuPermission = new Shizuku.OnRequestPermissionResultListener() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda40
        @Override // rikka.shizuku.Shizuku.OnRequestPermissionResultListener
        public final void onRequestPermissionResult(int i, int i2) {
            this.f$0.lambda$new$0(i, i2);
        }
    };
    private final Runnable refresh = new Runnable() { // from class: fr.phonemcp.MainActivity.1
        @Override // java.lang.Runnable
        public void run() {
            MainActivity.this.updateSession();
            if (MainActivity.this.tab == 1) {
                MainActivity.this.loadFiles();
            }
            MainActivity.this.handler.postDelayed(this, 2000L);
        }
    };

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$new$0(int i, int i2) {
        if (i == 41) {
            toast(i2 == 0 ? "Shizuku autorisé" : "Autorisation Shizuku refusée");
            render();
        }
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        int i;
        super.onCreate(bundle);
        Settings settings = new Settings(this);
        this.config = settings;
        if (settings.parallel()) {
            i = 0;
        } else {
            i = this.config.screenControl() ? 1 : 2;
        }
        this.mode = i;
        Shizuku.addRequestPermissionResultListener(this.shizukuPermission);
        render();
        handlePairing(getIntent());
    }

    private int dp(float f) {
        return Math.round(f * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable shape(int i, int i2, int i3) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(i);
        gradientDrawable.setCornerRadius(dp(i3));
        if (i2 != 0) {
            gradientDrawable.setStroke(dp(1.0f), i2);
        }
        return gradientDrawable;
    }

    private Drawable ripple(int i, int i2, int i3) {
        return new RippleDrawable(ColorStateList.valueOf(813685705), shape(i, i2, i3), null);
    }

    private LinearLayout column() {
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        return linearLayout;
    }

    private LinearLayout row() {
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        return linearLayout;
    }

    private TextView text(LinearLayout linearLayout, String str, int i, int i2, boolean z) {
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextSize(i);
        textView.setTextColor(i2);
        textView.setFontFeatureSettings("kern");
        textView.setTypeface(Typeface.create("sans-serif", z ? 1 : 0));
        textView.setLineSpacing(dp(2.0f), 1.0f);
        linearLayout.addView(textView, new LinearLayout.LayoutParams(-1, -2));
        return textView;
    }

    private void gap(LinearLayout linearLayout, int i) {
        linearLayout.addView(new View(this), new LinearLayout.LayoutParams(1, dp(i)));
    }

    private LinearLayout card(LinearLayout linearLayout) {
        LinearLayout linearLayoutColumn = column();
        linearLayoutColumn.setPadding(dp(18.0f), dp(18.0f), dp(18.0f), dp(18.0f));
        linearLayoutColumn.setBackground(shape(CARD, LINE, 22));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.bottomMargin = dp(16.0f);
        linearLayout.addView(linearLayoutColumn, layoutParams);
        return linearLayoutColumn;
    }

    private Button button(LinearLayout linearLayout, String str, int i, int i2, final Runnable runnable) {
        Button button = new Button(this);
        button.setText(str);
        button.setAllCaps(false);
        button.setTextSize(15.0f);
        button.setTypeface(Typeface.create("sans-serif-medium", 0));
        button.setTextColor(i2);
        button.setBackground(ripple(i, i == CARD ? LINE : 0, 14));
        button.setMinHeight(dp(52.0f));
        button.setMinimumHeight(dp(52.0f));
        button.setPadding(dp(14.0f), dp(10.0f), dp(14.0f), dp(10.0f));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = dp(10.0f);
        linearLayout.addView(button, layoutParams);
        button.setOnClickListener(new View.OnClickListener() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                runnable.run();
            }
        });
        return button;
    }

    private void section(String str, String str2) {
        text(this.body, str, 28, TEXT, true);
        if (!str2.isEmpty()) {
            gap(this.body, 6);
            text(this.body, str2, 14, MUTED, false);
        }
        gap(this.body, 24);
    }

    private EditText field(LinearLayout linearLayout, String str, String str2, boolean z) {
        text(linearLayout, str, 13, MUTED, false);
        EditText editText = new EditText(this);
        editText.setTextColor(TEXT);
        editText.setHintTextColor(MUTED);
        editText.setTextSize(14.0f);
        editText.setHint(str2);
        editText.setSingleLine(true);
        editText.setInputType(1 | (z ? 128 : 16));
        editText.setBackgroundTintList(ColorStateList.valueOf(ACCENT));
        editText.setPadding(dp(2.0f), dp(12.0f), dp(2.0f), dp(12.0f));
        linearLayout.addView(editText, new LinearLayout.LayoutParams(-1, -2));
        gap(linearLayout, 10);
        return editText;
    }

    private Switch toggle(LinearLayout linearLayout, String str, boolean z) {
        Switch r0 = new Switch(this);
        r0.setText(str);
        r0.setTextColor(TEXT);
        r0.setTextSize(14.0f);
        r0.setPadding(0, dp(10.0f), 0, dp(10.0f));
        r0.setMinHeight(dp(52.0f));
        r0.setChecked(z);
        r0.setThumbTintList(ColorStateList.valueOf(ACCENT));
        linearLayout.addView(r0, new LinearLayout.LayoutParams(-1, -2));
        return r0;
    }

    private void set(TextView textView, String str) {
        if (textView == null || str.contentEquals(textView.getText())) {
            return;
        }
        textView.setText(str);
    }

    private void render() {
        this.requirements = null;
        this.connectionStatus = null;
        this.sessionDetail = null;
        this.sessionTitle = null;
        this.stop = null;
        this.start = null;
        this.token = null;
        this.endpoint = null;
        this.filesBody = null;
        this.filesFingerprint = HttpUrl.FRAGMENT_ENCODE_SET;
        if (this.tab == 2) {
            getWindow().addFlags(8192);
        } else {
            getWindow().clearFlags(8192);
        }
        getWindow().getDecorView().setSystemUiVisibility(0);
        LinearLayout linearLayoutColumn = column();
        this.root = linearLayoutColumn;
        linearLayoutColumn.setBackgroundColor(BG);
        this.root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda36
            @Override // android.view.View.OnApplyWindowInsetsListener
            public final WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                return MainActivity.lambda$render$2(view, windowInsets);
            }
        });
        setContentView(this.root);
        this.root.requestApplyInsets();
        LinearLayout linearLayoutRow = row();
        linearLayoutRow.setPadding(dp(24.0f), dp(18.0f), dp(24.0f), dp(14.0f));
        this.root.addView(linearLayoutRow);
        TextView textView = new TextView(this);
        textView.setText("Phone MCP");
        textView.setTextColor(TEXT);
        textView.setTextSize(21.0f);
        textView.setTypeface(Typeface.create("sans-serif-medium", 0));
        linearLayoutRow.addView(textView, new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView textView2 = new TextView(this);
        textView2.setText(BuildConfig.VERSION_NAME);
        textView2.setTextSize(12.0f);
        textView2.setTextColor(MUTED);
        linearLayoutRow.addView(textView2);
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setClipToPadding(false);
        this.root.addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        LinearLayout linearLayoutColumn2 = column();
        this.body = linearLayoutColumn2;
        linearLayoutColumn2.setPadding(dp(24.0f), dp(12.0f), dp(24.0f), dp(24.0f));
        scrollView.addView(this.body);
        int i = this.tab;
        if (i == 0) {
            renderSession();
        } else if (i == 1) {
            renderFiles();
        } else {
            renderSettings();
        }
        if (this.tab == 0) {
            LinearLayout linearLayoutColumn3 = column();
            linearLayoutColumn3.setPadding(dp(24.0f), 0, dp(24.0f), dp(12.0f));
            this.start = button(linearLayoutColumn3, "Démarrer la session", ACCENT, BG, new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda37
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.startSession();
                }
            });
            this.stop = button(linearLayoutColumn3, "Arrêter la session", CARD, RED, new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda38
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$render$3();
                }
            });
            this.root.addView(linearLayoutColumn3);
        }
        LinearLayout linearLayoutRow2 = row();
        linearLayoutRow2.setPadding(dp(14.0f), dp(8.0f), dp(14.0f), dp(10.0f));
        linearLayoutRow2.setBackground(shape(BG, LINE, 0));
        String[] strArr = {"Session", "Fichiers", "Réglages"};
        final int i2 = 0;
        while (i2 < 3) {
            Button button = new Button(this);
            button.setText(strArr[i2]);
            button.setAllCaps(false);
            button.setTextSize(14.0f);
            button.setMinHeight(dp(52.0f));
            button.setTextColor(this.tab == i2 ? ACCENT : MUTED);
            button.setTypeface(Typeface.create("sans-serif-medium", 0));
            button.setBackground(ripple(this.tab == i2 ? CARD : BG, 0, 14));
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
            layoutParams.setMargins(dp(3.0f), 0, dp(3.0f), 0);
            linearLayoutRow2.addView(button, layoutParams);
            button.setSelected(this.tab == i2);
            button.setOnClickListener(new View.OnClickListener() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda39
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.lambda$render$4(i2, view);
                }
            });
            i2++;
        }
        this.root.addView(linearLayoutRow2);
        updateSession();
    }

    static /* synthetic */ WindowInsets lambda$render$2(View view, WindowInsets windowInsets) {
        Insets insets = windowInsets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
        view.setPadding(insets.left, insets.top, insets.right, insets.bottom);
        return windowInsets;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$render$3() {
        BridgeService.stop(this);
        updateSession();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$render$4(int i, View view) {
        this.tab = i;
        render();
    }

    private void renderSession() {
        LinearLayout linearLayout;
        section("Votre session", "Choisissez comment l’IA utilise votre téléphone.");
        LinearLayout linearLayoutCard = card(this.body);
        this.connectionStatus = text(linearLayoutCard, HttpUrl.FRAGMENT_ENCODE_SET, 12, ACCENT, true);
        gap(linearLayoutCard, 10);
        this.sessionTitle = text(linearLayoutCard, HttpUrl.FRAGMENT_ENCODE_SET, 25, TEXT, true);
        gap(linearLayoutCard, 6);
        this.sessionDetail = text(linearLayoutCard, HttpUrl.FRAGMENT_ENCODE_SET, 14, MUTED, false);
        LinearLayout linearLayoutCard2 = card(this.body);
        text(linearLayoutCard2, "Mode de contrôle", 17, TEXT, true);
        gap(linearLayoutCard2, 12);
        String[] strArr = {"Écran séparé", "Écran du téléphone", "Notifications"};
        String[] strArr2 = {"Utilisez une autre app en même temps · Shizuku", "L’IA agit sur l’écran que vous voyez", "Lire et répondre sans ouvrir les apps"};
        final int i = 0;
        while (i < 3) {
            LinearLayout linearLayoutColumn = column();
            linearLayoutColumn.setPadding(dp(14.0f), dp(13.0f), dp(14.0f), dp(13.0f));
            int i2 = this.mode;
            int i3 = i2 == i ? -15059656 : CARD;
            int i4 = ACCENT;
            linearLayoutColumn.setBackground(ripple(i3, i2 == i ? ACCENT : LINE, 14));
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
            layoutParams.bottomMargin = dp(8.0f);
            linearLayoutCard2.addView(linearLayoutColumn, layoutParams);
            String str = (this.mode == i ? "●  " : "○  ") + strArr[i];
            if (this.mode != i) {
                i4 = TEXT;
            }
            text(linearLayoutColumn, str, 15, i4, true);
            gap(linearLayoutColumn, 4);
            text(linearLayoutColumn, strArr2[i], 13, MUTED, false);
            linearLayoutColumn.setContentDescription(strArr[i] + ". " + strArr2[i] + (this.mode == i ? ". Sélectionné" : HttpUrl.FRAGMENT_ENCODE_SET));
            linearLayoutColumn.setOnClickListener(new View.OnClickListener() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda16
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.lambda$renderSession$5(i, view);
                }
            });
            i++;
        }
        if (this.mode == 0) {
            Switch r1 = toggle(linearLayoutCard2, "Éteindre l’écran physique", this.config.panelOff());
            this.panelOff = r1;
            r1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda17
                @Override // android.widget.CompoundButton.OnCheckedChangeListener
                public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    this.f$0.lambda$renderSession$6(compoundButton, z);
                }
            });
            linearLayout = linearLayoutCard2;
            text(linearLayout, "Le bouton latéral verrouille votre écran. La session reste ouverte sur l’écran séparé.", 12, MUTED, false);
        } else {
            linearLayout = linearLayoutCard2;
            this.panelOff = null;
        }
        gap(linearLayout, 14);
        text(linearLayout, "Durée", 13, MUTED, false);
        this.duration = new Spinner(this);
        this.duration.setAdapter((SpinnerAdapter) new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"Sans limite de durée", "30 minutes", "1 heure", "8 heures"}));
        this.duration.setContentDescription("Durée de la session");
        this.duration.setMinimumHeight(dp(48.0f));
        linearLayout.addView(this.duration);
        this.restore = button(this.body, "Rallumer l’écran physique", CARD, TEXT, new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda18
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$renderSession$7();
            }
        });
        gap(this.body, 20);
        this.requirements = text(this.body, HttpUrl.FRAGMENT_ENCODE_SET, 13, MUTED, false);
        button(this.body, "Gérer les autorisations", BG, MUTED, new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda19
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$renderSession$8();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$renderSession$5(int i, View view) {
        this.mode = i;
        this.config.parallel(i == 0);
        this.config.screenControl(this.mode == 1);
        render();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$renderSession$6(CompoundButton compoundButton, boolean z) {
        this.config.panelOff(z);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$renderSession$7() {
        startService(new Intent(this, (Class<?>) BridgeService.class).setAction("RESTORE_PANEL"));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$renderSession$8() {
        this.tab = 2;
        render();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateSession() {
        String strConcat;
        String string;
        String strConcat2;
        boolean zActive = BridgeService.active();
        JSONObject jSONObjectBackgroundState = BridgeService.backgroundState();
        TextView textView = this.connectionStatus;
        if (zActive) {
            strConcat = "●  ".concat(BridgeService.status().startsWith("Connecté") ? "CONNECTÉ" : "SESSION ACTIVE");
        } else {
            strConcat = "○  SESSION ARRÊTÉE";
        }
        set(textView, strConcat);
        set(this.sessionTitle, zActive ? "Vous gardez la main" : "Prêt quand vous l’êtes");
        TextView textView2 = this.sessionDetail;
        String strConcat3 = HttpUrl.FRAGMENT_ENCODE_SET;
        if (zActive) {
            StringBuilder sbAppend = new StringBuilder().append(BridgeService.status()).append("\n");
            if (BridgeService.parallelEnabled()) {
                strConcat2 = "Écran séparé".concat(jSONObjectBackgroundState.optBoolean("physicalPanelOff") ? " · écran physique éteint" : HttpUrl.FRAGMENT_ENCODE_SET);
            } else {
                strConcat2 = BridgeService.screenControlEnabled() ? "Écran du téléphone" : "Notifications";
            }
            string = sbAppend.append(strConcat2).toString();
        } else {
            string = "Démarrez une session pour donner accès aux apps autorisées.";
        }
        set(textView2, string);
        Button button = this.start;
        if (button != null) {
            button.setText(zActive ? "Appliquer et redémarrer" : "Démarrer la session");
            this.stop.setVisibility(zActive ? 0 : 8);
        }
        Button button2 = this.restore;
        if (button2 != null) {
            button2.setVisibility((zActive && BridgeService.parallelEnabled()) ? 0 : 8);
        }
        String strOptString = jSONObjectBackgroundState.optString("error");
        TextView textView3 = this.requirements;
        StringBuilder sbAppend2 = new StringBuilder("Shizuku : ").append(BackgroundClient.permissionStatus()).append(!strOptString.isEmpty() ? "\n" + strOptString : HttpUrl.FRAGMENT_ENCODE_SET);
        if (this.config.filesAllowed()) {
            strConcat3 = "\nFichiers et APK : ".concat(jSONObjectBackgroundState.optBoolean("fileServiceReady") ? "prêts" : "disponibles avec Shizuku pendant une session");
        }
        set(textView3, sbAppend2.append(strConcat3).toString());
    }

    private void renderFiles() {
        section("Vos fichiers", "Transférez et installez sans quitter vos autres apps.");
        LinearLayout linearLayoutCard = card(this.body);
        text(linearLayoutCard, "Téléchargements / PhoneMCP", 16, TEXT, true);
        gap(linearLayoutCard, 6);
        text(linearLayoutCard, "Lien HTTPS direct · jusqu’à 512 Mo par fichier. Une session et Shizuku actifs sont nécessaires, même pour installer une APK.", 13, MUTED, false);
        button(linearLayoutCard, "Ajouter un fichier", ACCENT, BG, new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda25
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.downloadDialog();
            }
        });
        button(linearLayoutCard, "Actualiser", CARD, TEXT, new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda26
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$renderFiles$9();
            }
        });
        LinearLayout linearLayoutColumn = column();
        this.filesBody = linearLayoutColumn;
        this.body.addView(linearLayoutColumn);
        loadFiles();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$renderFiles$9() {
        this.filesFingerprint = HttpUrl.FRAGMENT_ENCODE_SET;
        loadFiles();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void loadFiles() {
        if (this.filesBody == null || this.filesBusy) {
            return;
        }
        if (!BridgeService.active() || !BridgeService.backgroundState().optBoolean("fileServiceReady") || !this.config.filesAllowed()) {
            if ("inactive".equals(this.filesFingerprint)) {
                return;
            }
            this.filesFingerprint = "inactive";
            this.filesBody.removeAllViews();
            LinearLayout linearLayoutCard = card(this.filesBody);
            text(linearLayoutCard, "Fichiers en pause", 18, TEXT, true);
            gap(linearLayoutCard, 8);
            text(linearLayoutCard, "Démarrez Shizuku, autorisez Fichiers et APK, puis lancez une session.", 14, MUTED, false);
            button(linearLayoutCard, "Aller à la session", CARD, ACCENT, new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda21
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$loadFiles$10();
                }
            });
            return;
        }
        this.filesBusy = true;
        BridgeService.files("files_list", new JSONObject(), new PhoneAccessibilityService.Reply() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda23
            @Override // fr.phonemcp.PhoneAccessibilityService.Reply
            public final void done(JSONObject jSONObject, String str) {
                this.f$0.lambda$loadFiles$11(jSONObject, str);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$loadFiles$10() {
        this.tab = 0;
        render();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$loadFiles$11(JSONObject jSONObject, String str) {
        this.filesBusy = false;
        if (this.tab != 1 || this.filesBody == null) {
            return;
        }
        if (str != null) {
            if (str.equals(this.filesFingerprint)) {
                return;
            }
            this.filesFingerprint = str;
            this.filesBody.removeAllViews();
            text(this.filesBody, str, 14, RED, false);
            return;
        }
        String string = jSONObject.toString();
        if (string.equals(this.filesFingerprint)) {
            return;
        }
        this.filesFingerprint = string;
        showFiles(jSONObject);
    }

    /* JADX WARN: Code duplicated, block: B:11:0x003e  */
    /* JADX WARN: Multi-variable type inference failed */
    private void showFiles(JSONObject jSONObject) {
        this.filesBody.removeAllViews();
        JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("jobs");
        char c = 0;
        if (jSONArrayOptJSONArray != null) {
            int i = 0;
            while (i < jSONArrayOptJSONArray.length()) {
                final JSONObject jSONObjectOptJSONObject = jSONArrayOptJSONArray.optJSONObject(i);
                String strOptString = jSONObjectOptJSONObject.optString("state");
                if (!"completed".equals(strOptString) || "install".equals(jSONObjectOptJSONObject.optString("kind"))) {
                    LinearLayout linearLayoutCard = card(this.filesBody);
                    text(linearLayoutCard, jSONObjectOptJSONObject.optString("fileName", "Opération"), 15, TEXT, true);
                    gap(linearLayoutCard, 6);
                    text(linearLayoutCard, jobState(strOptString) + (jSONObjectOptJSONObject.has("bytesDone") ? " · " + size(jSONObjectOptJSONObject.optLong("bytesDone")) : HttpUrl.FRAGMENT_ENCODE_SET), 13, MUTED, false);
                    if (jSONObjectOptJSONObject.has("error")) {
                        gap(linearLayoutCard, 6);
                        text(linearLayoutCard, jSONObjectOptJSONObject.optString("error"), 13, RED, false);
                    }
                    String[] strArr = new String[3];
                    strArr[c] = "downloading";
                    strArr[1] = "queued";
                    strArr[2] = "verifying";
                    if (Arrays.asList(strArr).contains(strOptString)) {
                        ProgressBar progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
                        progressBar.setProgressTintList(ColorStateList.valueOf(ACCENT));
                        long jOptLong = jSONObjectOptJSONObject.optLong("totalBytes", -1L);
                        progressBar.setIndeterminate(jOptLong <= 0 ? 1 : c);
                        if (jOptLong > 0) {
                            progressBar.setProgress((int) Math.min(100L, (jSONObjectOptJSONObject.optLong("bytesDone") * 100) / jOptLong));
                        }
                        linearLayoutCard.addView(progressBar);
                        button(linearLayoutCard, "Annuler", CARD, RED, new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda30
                            @Override // java.lang.Runnable
                            public final void run() {
                                this.f$0.lambda$showFiles$12(jSONObjectOptJSONObject);
                            }
                        });
                    } else {
                        i = i;
                    }
                } else {
                    i = i;
                }
                i++;
                c = 0;
            }
        }
        JSONArray jSONArrayOptJSONArray2 = jSONObject.optJSONArray("files");
        if (jSONArrayOptJSONArray2 == null || jSONArrayOptJSONArray2.length() == 0) {
            gap(this.filesBody, 12);
            text(this.filesBody, "Les fichiers transférés apparaîtront ici.", 14, MUTED, false);
            return;
        }
        for (int i2 = 0; i2 < jSONArrayOptJSONArray2.length(); i2++) {
            final JSONObject jSONObjectOptJSONObject2 = jSONArrayOptJSONArray2.optJSONObject(i2);
            LinearLayout linearLayoutCard2 = card(this.filesBody);
            text(linearLayoutCard2, jSONObjectOptJSONObject2.optString("fileName"), 16, TEXT, true);
            gap(linearLayoutCard2, 6);
            text(linearLayoutCard2, size(jSONObjectOptJSONObject2.optLong("sizeBytes")) + (jSONObjectOptJSONObject2.has("versionName") ? " · version " + jSONObjectOptJSONObject2.optString("versionName") : HttpUrl.FRAGMENT_ENCODE_SET), 13, MUTED, false);
            if (jSONObjectOptJSONObject2.has("packageName")) {
                button(linearLayoutCard2, "Installer l’APK", CARD, ACCENT, new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda31
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.lambda$showFiles$14(jSONObjectOptJSONObject2);
                    }
                });
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$showFiles$12(JSONObject jSONObject) {
        fileCall("file_job", json("jobId", jSONObject.optString("jobId"), "action", "cancel"));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$showFiles$13(JSONObject jSONObject, DialogInterface dialogInterface, int i) {
        fileCall("install_apk", json("requestId", UUID.randomUUID().toString(), "fileId", jSONObject.optString("fileId"), "sha256", jSONObject.optString("sha256"), "expectedPackage", jSONObject.optString("packageName")));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$showFiles$14(final JSONObject jSONObject) {
        new AlertDialog.Builder(this).setTitle("Installer cette application ?").setMessage(jSONObject.optString("fileName") + "\n" + jSONObject.optString("packageName") + "\nVersion " + jSONObject.optString("versionName") + "\nUne version déjà installée sera mise à jour si sa signature correspond.").setNegativeButton("Annuler", (DialogInterface.OnClickListener) null).setPositiveButton("Installer", new DialogInterface.OnClickListener() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda24
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.lambda$showFiles$13(jSONObject, dialogInterface, i);
            }
        }).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void downloadDialog() {
        LinearLayout linearLayoutColumn = column();
        linearLayoutColumn.setPadding(dp(24.0f), dp(8.0f), dp(24.0f), dp(8.0f));
        final EditText editTextField = field(linearLayoutColumn, "Lien de téléchargement", "https://…", false);
        final EditText editTextField2 = field(linearLayoutColumn, "Nom du fichier", "document.pdf ou application.apk", false);
        final EditText editTextField3 = field(linearLayoutColumn, "SHA-256 (facultatif)", "64 caractères", false);
        final AlertDialog alertDialogCreate = new AlertDialog.Builder(this).setTitle("Ajouter un fichier").setView(linearLayoutColumn).setNegativeButton("Annuler", (DialogInterface.OnClickListener) null).setPositiveButton("Télécharger", (DialogInterface.OnClickListener) null).create();
        alertDialogCreate.setOnShowListener(new DialogInterface.OnShowListener() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda15
            @Override // android.content.DialogInterface.OnShowListener
            public final void onShow(DialogInterface dialogInterface) {
                this.f$0.lambda$downloadDialog$16(alertDialogCreate, editTextField, editTextField2, editTextField3, dialogInterface);
            }
        });
        alertDialogCreate.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$downloadDialog$15(EditText editText, EditText editText2, EditText editText3, AlertDialog alertDialog, View view) {
        try {
            JSONObject jSONObjectJson = json("requestId", UUID.randomUUID().toString(), "url", FilePolicy.url(editText.getText().toString()), "fileName", FilePolicy.name(editText2.getText().toString()), "sha256", FilePolicy.hash(editText3.getText().toString(), false));
            alertDialog.dismiss();
            fileCall("download_file", jSONObjectJson);
        } catch (Exception e) {
            toast(e.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$downloadDialog$16(final AlertDialog alertDialog, final EditText editText, final EditText editText2, final EditText editText3, DialogInterface dialogInterface) {
        alertDialog.getButton(-1).setOnClickListener(new View.OnClickListener() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.lambda$downloadDialog$15(editText, editText2, editText3, alertDialog, view);
            }
        });
    }

    private void fileCall(final String str, JSONObject jSONObject) {
        BridgeService.files(str, jSONObject, new PhoneAccessibilityService.Reply() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda2
            @Override // fr.phonemcp.PhoneAccessibilityService.Reply
            public final void done(JSONObject jSONObject2, String str2) {
                this.f$0.lambda$fileCall$17(str, jSONObject2, str2);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$fileCall$17(String str, JSONObject jSONObject, String str2) {
        String str3;
        if (str2 != null) {
            toast(str2);
            return;
        }
        if ("install_apk".equals(str)) {
            str3 = "Installation lancée";
        } else {
            str3 = "download_file".equals(str) ? "Téléchargement lancé" : "Opération annulée";
        }
        toast(str3);
        this.filesFingerprint = HttpUrl.FRAGMENT_ENCODE_SET;
        loadFiles();
    }

    private static JSONObject json(String... strArr) {
        JSONObject jSONObject = new JSONObject();
        for (int i = 0; i < strArr.length; i += 2) {
            try {
                jSONObject.put(strArr[i], strArr[i + 1]);
            } catch (JSONException e) {
                throw new IllegalArgumentException(e);
            }
        }
        return jSONObject;
    }

    private static String size(long j) {
        if (j < RealWebSocket.DEFAULT_MINIMUM_DEFLATE_SIZE) {
            return j + " o";
        }
        return j < 1048576 ? String.format(Locale.FRANCE, "%.1f Ko", Double.valueOf(j / 1024.0d)) : String.format(Locale.FRANCE, "%.1f Mo", Double.valueOf(j / 1048576.0d));
    }

    private static String jobState(String str) {
        str.hashCode();
        switch (str) {
            case "interrupted":
                return "Interrompu";
            case "verifying":
                return "Vérification de l’APK";
            case "completed":
                return "Installation terminée";
            case "downloading":
                return "Téléchargement";
            case "queued":
                return "En attente";
            case "cancelled":
                return "Annulé";
            case "installing":
                return "Installation par Android";
            default:
                return "Échec";
        }
    }

    private void renderSettings() {
        section("Réglages", "Les accès restent sous votre contrôle.");
        LinearLayout linearLayoutCard = card(this.body);
        text(linearLayoutCard, "Connexion au serveur", 18, TEXT, true);
        gap(linearLayoutCard, 16);
        EditText editTextField = field(linearLayoutCard, "Adresse du serveur", "https://mcp.votre-domaine.fr", false);
        this.endpoint = editTextField;
        editTextField.setText(this.config.endpoint());
        this.token = field(linearLayoutCard, "Jeton d’appairage", "Saisir uniquement pour modifier la connexion", true);
        button(linearLayoutCard, "Enregistrer la connexion", CARD, ACCENT, new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$renderSettings$18();
            }
        });
        LinearLayout linearLayoutCard2 = card(this.body);
        text(linearLayoutCard2, "Shizuku", 18, TEXT, true);
        gap(linearLayoutCard2, 6);
        text(linearLayoutCard2, BackgroundClient.permissionStatus() + ". À relancer après un redémarrage du téléphone.", 13, MUTED, false);
        button(linearLayoutCard2, "Ouvrir Shizuku", CARD, TEXT, new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.openShizuku();
            }
        });
        button(linearLayoutCard2, "Autoriser Phone MCP", CARD, ACCENT, new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$renderSettings$19();
            }
        });
        LinearLayout linearLayoutCard3 = card(this.body);
        text(linearLayoutCard3, "Autorisations", 18, TEXT, true);
        gap(linearLayoutCard3, 6);
        text(linearLayoutCard3, "Actives uniquement pendant une session démarrée manuellement. Les mots de passe restent masqués.", 13, MUTED, false);
        toggle(linearLayoutCard3, "Fichiers et installation d’APK", this.config.filesAllowed()).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda7
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                this.f$0.lambda$renderSettings$20(compoundButton, z);
            }
        });
        toggle(linearLayoutCard3, "Toutes les apps par défaut", this.config.allApps()).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda8
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                this.f$0.lambda$renderSettings$21(compoundButton, z);
            }
        });
        button(linearLayoutCard3, "Gérer les accès par application", CARD, TEXT, new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda9
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.appPicker();
            }
        });
        button(linearLayoutCard3, "Accès à l’écran · ".concat(PhoneAccessibilityService.instance != null ? "actif" : "à activer"), CARD, TEXT, new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda10
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$renderSettings$22();
            }
        });
        button(linearLayoutCard3, "Accès aux notifications · ".concat(PhoneNotificationService.instance == null ? "à activer" : "actif"), CARD, TEXT, new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda12
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$renderSettings$23();
            }
        });
        LinearLayout linearLayoutCard4 = card(this.body);
        text(linearLayoutCard4, "Dernière activité", 16, TEXT, true);
        gap(linearLayoutCard4, 8);
        text(linearLayoutCard4, Audit.latest(), 13, MUTED, false);
        button(this.body, "Supprimer l’appairage", BG, RED, new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda13
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$renderSettings$25();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$renderSettings$18() {
        try {
            this.config.saveConnection(this.endpoint.getText().toString(), this.token.getText().toString());
            BridgeService.stop(this);
            this.token.setText(HttpUrl.FRAGMENT_ENCODE_SET);
            toast("Connexion enregistrée. La session est arrêtée.");
        } catch (Exception e) {
            toast(e.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$renderSettings$19() {
        String str;
        try {
            if (!Shizuku.pingBinder()) {
                str = "Démarrez Shizuku par débogage sans fil.";
            } else {
                if (!BackgroundClient.permitted()) {
                    Shizuku.requestPermission(41);
                    return;
                }
                str = "Shizuku est déjà autorisé.";
            }
            toast(str);
        } catch (Exception unused) {
            toast("Ouvrez Shizuku puis réessayez.");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$renderSettings$20(CompoundButton compoundButton, boolean z) {
        this.config.filesAllowed(z);
        if (z) {
            return;
        }
        BridgeService.revokeFiles();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$renderSettings$21(CompoundButton compoundButton, boolean z) {
        this.config.allApps(z);
        PhoneAccessibilityService.invalidate();
        PhoneNotificationService.invalidate();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$renderSettings$22() {
        startActivity(new Intent("android.settings.ACCESSIBILITY_SETTINGS"));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$renderSettings$23() {
        startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$renderSettings$24(DialogInterface dialogInterface, int i) {
        BridgeService.stop(this);
        this.config.forget();
        render();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$renderSettings$25() {
        new AlertDialog.Builder(this).setTitle("Supprimer l’appairage ?").setMessage("La session sera arrêtée. Un nouvel appairage sera nécessaire pour reconnecter ce téléphone.").setNegativeButton("Annuler", (DialogInterface.OnClickListener) null).setPositiveButton("Supprimer", new DialogInterface.OnClickListener() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda20
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.lambda$renderSettings$24(dialogInterface, i);
            }
        }).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void appPicker() {
        final ArrayList arrayList = new ArrayList(getPackageManager().getInstalledApplications(0));
        arrayList.removeIf(new Predicate() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda0
            @Override // java.util.function.Predicate
            public final boolean test(Object obj) {
                return MainActivity.lambda$appPicker$26((ApplicationInfo) obj);
            }
        });
        arrayList.sort(Comparator.comparing(new Function() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda11
            @Override // java.util.function.Function
            public final Object apply(Object obj) {
                return this.f$0.lambda$appPicker$27((ApplicationInfo) obj);
            }
        }, String.CASE_INSENSITIVE_ORDER));
        LinearLayout linearLayoutColumn = column();
        linearLayoutColumn.setPadding(dp(16.0f), 0, dp(16.0f), dp(8.0f));
        final EditText editTextField = field(linearLayoutColumn, "Rechercher une application", "Nom ou identifiant", false);
        ListView listView = new ListView(this);
        linearLayoutColumn.addView(listView, new LinearLayout.LayoutParams(-1, dp(380.0f)));
        final ArrayList arrayList2 = new ArrayList();
        final ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1);
        listView.setAdapter((ListAdapter) arrayAdapter);
        final Runnable runnable = new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda22
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$appPicker$28(editTextField, arrayList2, arrayAdapter, arrayList);
            }
        };
        runnable.run();
        editTextField.addTextChangedListener(new TextWatcher() { // from class: fr.phonemcp.MainActivity.2
            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                runnable.run();
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda33
            @Override // android.widget.AdapterView.OnItemClickListener
            public final void onItemClick(AdapterView adapterView, View view, int i, long j) {
                this.f$0.lambda$appPicker$31(arrayList2, adapterView, view, i, j);
            }
        });
        new AlertDialog.Builder(this).setTitle("Accès par application").setView(linearLayoutColumn).setPositiveButton("Fermer", (DialogInterface.OnClickListener) null).show();
    }

    static /* synthetic */ boolean lambda$appPicker$26(ApplicationInfo applicationInfo) {
        return !AccessPolicy.validPackage(applicationInfo.packageName);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ String lambda$appPicker$27(ApplicationInfo applicationInfo) {
        return getPackageManager().getApplicationLabel(applicationInfo).toString();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$appPicker$28(EditText editText, List list, ArrayAdapter arrayAdapter, List list2) {
        String lowerCase = editText.getText().toString().toLowerCase(Locale.ROOT);
        list.clear();
        arrayAdapter.clear();
        Iterator it = list2.iterator();
        while (it.hasNext()) {
            ApplicationInfo applicationInfo = (ApplicationInfo) it.next();
            String string = getPackageManager().getApplicationLabel(applicationInfo).toString();
            if ((string + " " + applicationInfo.packageName).toLowerCase(Locale.ROOT).contains(lowerCase)) {
                list.add(applicationInfo);
                arrayAdapter.add(string + "\n" + applicationInfo.packageName);
            }
        }
    }

    static /* synthetic */ void lambda$appPicker$29(boolean[] zArr, DialogInterface dialogInterface, int i, boolean z) {
        zArr[i] = z;
        if (i == 0 && !z) {
            for (int i2 = 1; i2 < 4; i2++) {
                zArr[i2] = false;
                ((AlertDialog) dialogInterface).getListView().setItemChecked(i2, false);
            }
            return;
        }
        if (i <= 0 || !z) {
            return;
        }
        zArr[0] = true;
        ((AlertDialog) dialogInterface).getListView().setItemChecked(0, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$appPicker$30(String str, String[] strArr, boolean[] zArr, DialogInterface dialogInterface, int i) {
        for (int i2 = 0; i2 < 4; i2++) {
            this.config.grant(str, strArr[i2], zArr[i2]);
        }
        PhoneAccessibilityService.invalidate();
        PhoneNotificationService.invalidate();
        toast("Accès mis à jour");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$appPicker$31(List list, AdapterView adapterView, View view, int i, long j) {
        ApplicationInfo applicationInfo = (ApplicationInfo) list.get(i);
        final String str = applicationInfo.packageName;
        final String[] strArr = {"read", "write", "capture", "notifications"};
        String[] strArr2 = {"Lecture", "Actions", "Captures", "Notifications"};
        final boolean[] zArr = new boolean[4];
        for (int i2 = 0; i2 < 4; i2++) {
            zArr[i2] = this.config.allowed(str, strArr[i2]);
        }
        new AlertDialog.Builder(this).setTitle(getPackageManager().getApplicationLabel(applicationInfo)).setMultiChoiceItems(strArr2, zArr, new DialogInterface.OnMultiChoiceClickListener() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda27
            @Override // android.content.DialogInterface.OnMultiChoiceClickListener
            public final void onClick(DialogInterface dialogInterface, int i3, boolean z) {
                MainActivity.lambda$appPicker$29(zArr, dialogInterface, i3, z);
            }
        }).setNegativeButton("Annuler", (DialogInterface.OnClickListener) null).setPositiveButton("Enregistrer", new DialogInterface.OnClickListener() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda28
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i3) {
                this.f$0.lambda$appPicker$30(str, strArr, zArr, dialogInterface, i3);
            }
        }).create().show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startSession() {
        MainActivity mainActivity;
        String str;
        Switch r0;
        int i = this.mode;
        final boolean z = i == 0;
        final boolean z2 = i == 1;
        if (z && !BackgroundClient.permitted()) {
            toast("Démarrez et autorisez Shizuku dans Réglages.");
            return;
        }
        if (z2 && PhoneAccessibilityService.instance == null) {
            toast("Activez l’accès à l’écran dans Réglages.");
            return;
        }
        if (this.mode == 2 && PhoneNotificationService.instance == null) {
            toast("Activez l’accès aux notifications dans Réglages.");
            return;
        }
        try {
            if (this.config.endpoint().isEmpty() || this.config.token().isEmpty()) {
                mainActivity = this;
                try {
                    mainActivity.toast("Appairez le serveur dans Réglages.");
                    return;
                } catch (Exception unused) {
                    mainActivity.toast("Réenregistrez l’appairage.");
                    return;
                }
            }
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0) {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
                toast("Autorisez les notifications puis démarrez la session.");
                return;
            }
            if (!((NotificationManager) getSystemService(NotificationManager.class)).areNotificationsEnabled()) {
                startActivity(new Intent("android.settings.APP_NOTIFICATION_SETTINGS").putExtra("android.provider.extra.APP_PACKAGE", getPackageName()));
                return;
            }
            final int i2 = new int[]{0, 30, 60, 480}[this.duration.getSelectedItemPosition()];
            final boolean z3 = z && (r0 = this.panelOff) != null && r0.isChecked();
            StringBuilder sbAppend = new StringBuilder().append(i2 == 0 ? "Sans expiration automatique" : "Pendant " + i2 + " minutes").append(", l’IA pourra ");
            if (z) {
                str = "contrôler les apps autorisées sur un écran séparé";
            } else {
                str = z2 ? "contrôler les apps autorisées sur votre écran" : "lire et utiliser les notifications autorisées";
            }
            StringBuilder sbAppend2 = sbAppend.append(str);
            boolean zFilesAllowed = this.config.filesAllowed();
            String str2 = HttpUrl.FRAGMENT_ENCODE_SET;
            StringBuilder sbAppend3 = sbAppend2.append((zFilesAllowed && BackgroundClient.permitted()) ? ", transférer des fichiers et installer des APK via Shizuku" : HttpUrl.FRAGMENT_ENCODE_SET).append(".").append(z ? " L’écran séparé pourra rester contrôlable même si votre écran est verrouillé." : HttpUrl.FRAGMENT_ENCODE_SET);
            if (z3) {
                str2 = " L’écran physique sera éteint au démarrage.";
            }
            new AlertDialog.Builder(this).setTitle("Démarrer cette session ?").setMessage(sbAppend3.append(str2).append("\nVous pouvez arrêter à tout moment depuis la notification. La session ne reprend pas après un redémarrage.").toString()).setNegativeButton("Annuler", (DialogInterface.OnClickListener) null).setPositiveButton("Démarrer", new DialogInterface.OnClickListener() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda35
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i3) {
                    this.f$0.lambda$startSession$32(i2, z, z2, z3, dialogInterface, i3);
                }
            }).show();
        } catch (Exception unused2) {
            mainActivity = this;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$startSession$32(int i, boolean z, boolean z2, boolean z3, DialogInterface dialogInterface, int i2) {
        startForegroundService(new Intent(this, (Class<?>) BridgeService.class).putExtra("minutes", i).putExtra("parallel", z).putExtra("screenControl", z2).putExtra("panelOff", z3));
        this.handler.postDelayed(new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda29
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.updateSession();
            }
        }, 400L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void openShizuku() {
        Intent launchIntentForPackage = getPackageManager().getLaunchIntentForPackage(ShizukuProvider.MANAGER_APPLICATION_ID);
        if (launchIntentForPackage == null) {
            launchIntentForPackage = new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api"));
        }
        startActivity(launchIntentForPackage);
    }

    @Override // android.app.Activity
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handlePairing(intent);
    }

    private void handlePairing(Intent intent) {
        Uri data = intent == null ? null : intent.getData();
        if (data != null && "phonemcp".equals(data.getScheme()) && "pair".equals(data.getHost())) {
            intent.setData(null);
            final String queryParameter = data.getQueryParameter("server");
            final String queryParameter2 = data.getQueryParameter("code");
            try {
                URI uri = new URI(queryParameter);
                if (!"https".equals(uri.getScheme()) || uri.getHost() == null || uri.getUserInfo() != null || uri.getQuery() != null || uri.getFragment() != null || !uri.getPath().isEmpty() || queryParameter2 == null || !queryParameter2.matches("[A-Za-z0-9_-]{32,256}")) {
                    throw new Exception();
                }
                new AlertDialog.Builder(this).setTitle("Connecter ce serveur ?").setMessage(queryParameter + "\nLa connexion ne démarre aucune session.").setNegativeButton("Annuler", (DialogInterface.OnClickListener) null).setPositiveButton("Appairer", new DialogInterface.OnClickListener() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda14
                    @Override // android.content.DialogInterface.OnClickListener
                    public final void onClick(DialogInterface dialogInterface, int i) {
                        this.f$0.lambda$handlePairing$33(queryParameter, queryParameter2, dialogInterface, i);
                    }
                }).show();
            } catch (Exception unused) {
                toast("Lien d’appairage invalide.");
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$handlePairing$33(String str, String str2, DialogInterface dialogInterface, int i) {
        redeemPairing(str, str2);
    }

    private void redeemPairing(final String str, final String str2) {
        final OkHttpClient okHttpClientBuild = new OkHttpClient.Builder().callTimeout(20L, TimeUnit.SECONDS).build();
        new Thread(new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda41
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$redeemPairing$36(str2, okHttpClientBuild, str);
            }
        }, "phone-mcp-pairing").start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$redeemPairing$36(String str, OkHttpClient okHttpClient, String str2) {
        try {
            try {
                Response responseExecute = okHttpClient.newCall(new Request.Builder().url(str2 + "/pair").post(RequestBody.create(new JSONObject().put("code", str).toString(), MediaType.get("application/json"))).build()).execute();
                try {
                    if (!responseExecute.isSuccessful() || responseExecute.body() == null) {
                        throw new Exception("Code expiré ou déjà utilisé. Régénérez l’appairage.");
                    }
                    JSONObject jSONObject = new JSONObject(responseExecute.body().string());
                    if (!str2.equals(jSONObject.getString("endpoint"))) {
                        throw new Exception("Le serveur d’appairage a changé.");
                    }
                    BridgeService.stop(this);
                    this.config.saveConnection(str2, jSONObject.getString("token"));
                    runOnUiThread(new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda32
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.lambda$redeemPairing$34();
                        }
                    });
                    if (responseExecute != null) {
                        responseExecute.close();
                    }
                    okHttpClient.dispatcher().executorService().shutdown();
                    okHttpClient.connectionPool().evictAll();
                } catch (Throwable th) {
                    if (responseExecute != null) {
                        try {
                            responseExecute.close();
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                    }
                    throw th;
                }
            } catch (Throwable th3) {
                okHttpClient.dispatcher().executorService().shutdown();
                okHttpClient.connectionPool().evictAll();
                throw th3;
            }
        } catch (Exception e) {
            runOnUiThread(new Runnable() { // from class: fr.phonemcp.MainActivity$$ExternalSyntheticLambda34
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$redeemPairing$35(e);
                }
            });
            okHttpClient.dispatcher().executorService().shutdown();
            okHttpClient.connectionPool().evictAll();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$redeemPairing$34() {
        toast("Serveur appairé");
        render();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$redeemPairing$35(Exception exc) {
        toast(exc.getMessage() == null ? "Appairage impossible" : exc.getMessage());
    }

    private void toast(String str) {
        if (str == null) {
            str = "Opération impossible";
        }
        Toast.makeText(this, str, 1).show();
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        this.handler.removeCallbacks(this.refresh);
        this.handler.post(this.refresh);
    }

    @Override // android.app.Activity
    protected void onPause() {
        this.handler.removeCallbacks(this.refresh);
        super.onPause();
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(this.shizukuPermission);
        super.onDestroy();
    }
}
