package fr.phonemcp;

import android.view.accessibility.AccessibilityNodeInfo;
import java.util.Arrays;
import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
final class NodeIdentity {
    NodeIdentity() {
    }

    static boolean protectedAncestor(AccessibilityNodeInfo accessibilityNodeInfo) {
        AccessibilityNodeInfo parent = accessibilityNodeInfo.getParent();
        int i = 0;
        while (parent != null && i < 64) {
            try {
                if (parent.isPassword()) {
                    if (parent != null) {
                        parent.recycle();
                    }
                    return true;
                }
                AccessibilityNodeInfo parent2 = parent.getParent();
                parent.recycle();
                i++;
                parent = parent2;
            } catch (Throwable th) {
                if (parent != null) {
                    parent.recycle();
                }
                throw th;
            }
        }
        boolean z = parent != null;
        if (parent != null) {
            parent.recycle();
        }
        return z;
    }

    private static String value(CharSequence charSequence) {
        return charSequence == null ? HttpUrl.FRAGMENT_ENCODE_SET : charSequence.toString();
    }

    static String of(AccessibilityNodeInfo accessibilityNodeInfo) {
        return Arrays.asList(value(accessibilityNodeInfo.getPackageName()), Integer.valueOf(accessibilityNodeInfo.getWindowId()), value(accessibilityNodeInfo.getClassName()), accessibilityNodeInfo.getViewIdResourceName(), value(accessibilityNodeInfo.getText()), value(accessibilityNodeInfo.getContentDescription()), Boolean.valueOf(accessibilityNodeInfo.isPassword()), Boolean.valueOf(accessibilityNodeInfo.isEnabled()), Boolean.valueOf(accessibilityNodeInfo.isEditable()), Boolean.valueOf(accessibilityNodeInfo.isClickable()), Boolean.valueOf(accessibilityNodeInfo.isLongClickable()), Boolean.valueOf(accessibilityNodeInfo.isScrollable()), Boolean.valueOf(accessibilityNodeInfo.isCheckable()), Boolean.valueOf(accessibilityNodeInfo.isChecked()), Boolean.valueOf(accessibilityNodeInfo.isSelected())).toString();
    }
}
