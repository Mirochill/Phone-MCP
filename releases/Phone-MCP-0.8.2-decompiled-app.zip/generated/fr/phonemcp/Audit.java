package fr.phonemcp;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
final class Audit {
    private static final ArrayDeque<String> entries = new ArrayDeque<>();

    Audit() {
    }

    static synchronized void add(String str, boolean z) {
        entries.addFirst(new SimpleDateFormat("HH:mm:ss", Locale.FRANCE).format(new Date()) + " · " + str + " · " + (z ? "OK" : "refus/échec"));
        while (true) {
            ArrayDeque<String> arrayDeque = entries;
            if (arrayDeque.size() > 8) {
                arrayDeque.removeLast();
            }
        }
    }

    static synchronized String latest() {
        return String.join("\n", entries);
    }
}
