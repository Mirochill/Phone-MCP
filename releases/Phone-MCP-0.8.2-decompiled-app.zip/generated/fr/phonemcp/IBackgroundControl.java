package fr.phonemcp;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import android.view.SurfaceControl;

/* JADX INFO: loaded from: classes.dex */
public interface IBackgroundControl extends IInterface {
    public static final String DESCRIPTOR = "fr.phonemcp.IBackgroundControl";

    public static class Default implements IBackgroundControl {
        @Override // android.os.IInterface
        public IBinder asBinder() {
            return null;
        }

        @Override // fr.phonemcp.IBackgroundControl
        public String attachPreview(String str, SurfaceControl surfaceControl) throws RemoteException {
            return null;
        }

        @Override // fr.phonemcp.IBackgroundControl
        public void destroy() throws RemoteException {
        }

        @Override // fr.phonemcp.IBackgroundControl
        public void detachPreview(String str) throws RemoteException {
        }

        @Override // fr.phonemcp.IBackgroundControl
        public String execute(String str, String str2) throws RemoteException {
            return null;
        }

        @Override // fr.phonemcp.IBackgroundControl
        public String previewFrame(String str) throws RemoteException {
            return null;
        }

        @Override // fr.phonemcp.IBackgroundControl
        public String renewPreview(String str) throws RemoteException {
            return null;
        }

        @Override // fr.phonemcp.IBackgroundControl
        public String restorePanel() throws RemoteException {
            return null;
        }

        @Override // fr.phonemcp.IBackgroundControl
        public void setPreviewCallback(IPreviewCallback iPreviewCallback) throws RemoteException {
        }

        @Override // fr.phonemcp.IBackgroundControl
        public String start(long j, IBinder iBinder, boolean z, boolean z2) throws RemoteException {
            return null;
        }

        @Override // fr.phonemcp.IBackgroundControl
        public void stop() throws RemoteException {
        }
    }

    String attachPreview(String str, SurfaceControl surfaceControl) throws RemoteException;

    void destroy() throws RemoteException;

    void detachPreview(String str) throws RemoteException;

    String execute(String str, String str2) throws RemoteException;

    String previewFrame(String str) throws RemoteException;

    String renewPreview(String str) throws RemoteException;

    String restorePanel() throws RemoteException;

    void setPreviewCallback(IPreviewCallback iPreviewCallback) throws RemoteException;

    String start(long j, IBinder iBinder, boolean z, boolean z2) throws RemoteException;

    void stop() throws RemoteException;

    public static abstract class Stub extends Binder implements IBackgroundControl {
        static final int TRANSACTION_attachPreview = 7;
        static final int TRANSACTION_destroy = 16777115;
        static final int TRANSACTION_detachPreview = 9;
        static final int TRANSACTION_execute = 2;
        static final int TRANSACTION_previewFrame = 5;
        static final int TRANSACTION_renewPreview = 8;
        static final int TRANSACTION_restorePanel = 4;
        static final int TRANSACTION_setPreviewCallback = 6;
        static final int TRANSACTION_start = 1;
        static final int TRANSACTION_stop = 3;

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }

        public Stub() {
            attachInterface(this, IBackgroundControl.DESCRIPTOR);
        }

        public static IBackgroundControl asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface(IBackgroundControl.DESCRIPTOR);
            if (iInterfaceQueryLocalInterface != null && (iInterfaceQueryLocalInterface instanceof IBackgroundControl)) {
                return (IBackgroundControl) iInterfaceQueryLocalInterface;
            }
            return new Proxy(iBinder);
        }

        @Override // android.os.Binder
        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i >= 1 && i <= 16777215) {
                parcel.enforceInterface(IBackgroundControl.DESCRIPTOR);
            }
            if (i == 1598968902) {
                parcel2.writeString(IBackgroundControl.DESCRIPTOR);
                return true;
            }
            if (i != 16777115) {
                switch (i) {
                    case 1:
                        String strStart = start(parcel.readLong(), parcel.readStrongBinder(), parcel.readInt() != 0, parcel.readInt() != 0);
                        parcel2.writeNoException();
                        parcel2.writeString(strStart);
                        break;
                    case 2:
                        String strExecute = execute(parcel.readString(), parcel.readString());
                        parcel2.writeNoException();
                        parcel2.writeString(strExecute);
                        break;
                    case 3:
                        stop();
                        parcel2.writeNoException();
                        break;
                    case 4:
                        String strRestorePanel = restorePanel();
                        parcel2.writeNoException();
                        parcel2.writeString(strRestorePanel);
                        break;
                    case 5:
                        String strPreviewFrame = previewFrame(parcel.readString());
                        parcel2.writeNoException();
                        parcel2.writeString(strPreviewFrame);
                        break;
                    case 6:
                        setPreviewCallback(IPreviewCallback.Stub.asInterface(parcel.readStrongBinder()));
                        parcel2.writeNoException();
                        break;
                    case 7:
                        String strAttachPreview = attachPreview(parcel.readString(), (SurfaceControl) _Parcel.readTypedObject(parcel, SurfaceControl.CREATOR));
                        parcel2.writeNoException();
                        parcel2.writeString(strAttachPreview);
                        break;
                    case 8:
                        String strRenewPreview = renewPreview(parcel.readString());
                        parcel2.writeNoException();
                        parcel2.writeString(strRenewPreview);
                        break;
                    case 9:
                        detachPreview(parcel.readString());
                        parcel2.writeNoException();
                        break;
                    default:
                        return super.onTransact(i, parcel, parcel2, i2);
                }
            } else {
                destroy();
                parcel2.writeNoException();
            }
            return true;
        }

        private static class Proxy implements IBackgroundControl {
            private IBinder mRemote;

            Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return IBackgroundControl.DESCRIPTOR;
            }

            @Override // fr.phonemcp.IBackgroundControl
            public String start(long j, IBinder iBinder, boolean z, boolean z2) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IBackgroundControl.DESCRIPTOR);
                    parcelObtain.writeLong(j);
                    parcelObtain.writeStrongBinder(iBinder);
                    parcelObtain.writeInt(z ? 1 : 0);
                    parcelObtain.writeInt(z2 ? 1 : 0);
                    this.mRemote.transact(1, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return parcelObtain2.readString();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // fr.phonemcp.IBackgroundControl
            public String execute(String str, String str2) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IBackgroundControl.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    parcelObtain.writeString(str2);
                    this.mRemote.transact(2, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return parcelObtain2.readString();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // fr.phonemcp.IBackgroundControl
            public void stop() throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IBackgroundControl.DESCRIPTOR);
                    this.mRemote.transact(3, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // fr.phonemcp.IBackgroundControl
            public String restorePanel() throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IBackgroundControl.DESCRIPTOR);
                    this.mRemote.transact(4, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return parcelObtain2.readString();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // fr.phonemcp.IBackgroundControl
            public String previewFrame(String str) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IBackgroundControl.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    this.mRemote.transact(5, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return parcelObtain2.readString();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // fr.phonemcp.IBackgroundControl
            public void setPreviewCallback(IPreviewCallback iPreviewCallback) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IBackgroundControl.DESCRIPTOR);
                    parcelObtain.writeStrongInterface(iPreviewCallback);
                    this.mRemote.transact(6, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // fr.phonemcp.IBackgroundControl
            public String attachPreview(String str, SurfaceControl surfaceControl) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IBackgroundControl.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    _Parcel.writeTypedObject(parcelObtain, surfaceControl, 0);
                    this.mRemote.transact(7, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return parcelObtain2.readString();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // fr.phonemcp.IBackgroundControl
            public String renewPreview(String str) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IBackgroundControl.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    this.mRemote.transact(8, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return parcelObtain2.readString();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // fr.phonemcp.IBackgroundControl
            public void detachPreview(String str) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IBackgroundControl.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    this.mRemote.transact(9, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // fr.phonemcp.IBackgroundControl
            public void destroy() throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IBackgroundControl.DESCRIPTOR);
                    this.mRemote.transact(16777115, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }
        }
    }

    public static class _Parcel {
        /* JADX INFO: Access modifiers changed from: private */
        public static <T> T readTypedObject(Parcel parcel, Parcelable.Creator<T> creator) {
            if (parcel.readInt() != 0) {
                return creator.createFromParcel(parcel);
            }
            return null;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static <T extends Parcelable> void writeTypedObject(Parcel parcel, T t, int i) {
            if (t != null) {
                parcel.writeInt(1);
                t.writeToParcel(parcel, i);
            } else {
                parcel.writeInt(0);
            }
        }
    }
}
