package fr.phonemcp;

import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
final class AccessPolicy {
    static final String PREFIX = "grant.v4.";

    AccessPolicy() {
    }

    static boolean validPackage(String str) {
        return str != null && str.length() <= 240 && str.matches("[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)*");
    }

    static boolean capability(String str) {
        return "read".equals(str) || "write".equals(str) || "capture".equals(str) || "notifications".equals(str);
    }

    static String key(String str, String str2) {
        return PREFIX + str + "." + str2;
    }

    private static boolean value(Map<String, ?> map, String str, boolean z) {
        return map.containsKey(str) ? Boolean.TRUE.equals(map.get(str)) : z;
    }

    static boolean allowed(String str, String str2, boolean z, boolean z2, Map<String, ?> map) {
        return validPackage(str) && capability(str2) && z && value(map, key(str, "read"), z2) && value(map, key(str, str2), z2);
    }
}
