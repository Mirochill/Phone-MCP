package fr.phonemcp;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Process;
import android.os.SystemClock;
import android.system.Os;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.ToLongFunction;
import javax.net.ssl.HttpsURLConnection;
import kotlin.UByte;
import okhttp3.HttpUrl;
import okio.Segment;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
final class FileEngine {
    private volatile Job active;
    private final Context context;
    private volatile long deadline;
    private final File downloads;
    private final File records;
    private final int user;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final ScheduledExecutorService timeouts = Executors.newSingleThreadScheduledExecutor();
    private final Map<String, Job> jobs = new LinkedHashMap();

    /* JADX INFO: Access modifiers changed from: private */
    interface Work {
        void run() throws Exception;
    }

    /* JADX INFO: Access modifiers changed from: private */
    static final class Job {
        volatile boolean cancelled;
        volatile HttpsURLConnection connection;
        volatile Process process;
        final JSONObject value;

        Job(JSONObject jSONObject) {
            this.value = jSONObject;
        }
    }

    FileEngine(Context context, int i) throws Exception {
        this.context = context;
        int i2 = i / 100000;
        this.user = i2;
        this.records = new File("/data/local/tmp/phone-mcp-" + i);
        this.downloads = new File("/storage/emulated/" + i2 + "/Download/PhoneMCP");
    }

    synchronized void start(long j) throws Exception {
        File[] fileArrListFiles;
        if (Process.myUid() != 2000 || !SessionPolicy.validDeadline(SystemClock.elapsedRealtime(), j)) {
            throw new SecurityException("Service fichiers Shizuku non autorisé.");
        }
        ensureDirectory(this.records);
        Os.chmod(this.records.getPath(), 448);
        ensureDirectory(this.downloads);
        if (this.jobs.isEmpty() && (fileArrListFiles = this.records.listFiles(new FilenameFilter() { // from class: fr.phonemcp.FileEngine$$ExternalSyntheticLambda0
            @Override // java.io.FilenameFilter
            public final boolean accept(File file, String str) {
                return str.matches("[0-9a-f-]{36}\\.json");
            }
        })) != null) {
            Arrays.sort(fileArrListFiles, Comparator.comparingLong(new ToLongFunction() { // from class: fr.phonemcp.FileEngine$$ExternalSyntheticLambda1
                @Override // java.util.function.ToLongFunction
                public final long applyAsLong(Object obj) {
                    return ((File) obj).lastModified();
                }
            }).reversed());
            for (File file : (File[]) Arrays.copyOf(fileArrListFiles, Math.min(fileArrListFiles.length, 128))) {
                try {
                    if (file.length() <= 10000 && !Files.isSymbolicLink(file.toPath())) {
                        Job job = new Job(new JSONObject(new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8)));
                        if (!terminal(job.value.optString("state"))) {
                            job.value.put("state", "interrupted").put("error", "Opération interrompue. Vérifiez le résultat avant de recommencer.");
                        }
                        this.jobs.put(FilePolicy.id(job.value.getString("jobId")), job);
                    }
                } catch (Exception unused) {
                }
            }
        }
        File[] fileArrListFiles2 = this.records.listFiles(new FilenameFilter() { // from class: fr.phonemcp.FileEngine$$ExternalSyntheticLambda2
            @Override // java.io.FilenameFilter
            public final boolean accept(File file2, String str) {
                return str.matches("[0-9a-f-]{36}\\.apk");
            }
        });
        if (fileArrListFiles2 != null) {
            for (File file2 : fileArrListFiles2) {
                if (!Files.isSymbolicLink(file2.toPath())) {
                    Files.deleteIfExists(file2.toPath());
                }
            }
        }
        this.deadline = j;
    }

    private static void ensureDirectory(File file) throws Exception {
        if (Files.isSymbolicLink(file.toPath()) || !(file.isDirectory() || file.mkdirs())) {
            throw new IOException("Dossier PhoneMCP inaccessible.");
        }
        while (file != null) {
            if (Files.isSymbolicLink(file.toPath())) {
                throw new SecurityException("Un lien symbolique remplace le dossier de transfert.");
            }
            file = file.getParentFile();
        }
    }

    private void requireSession() {
        if (!SessionPolicy.validDeadline(SystemClock.elapsedRealtime(), this.deadline)) {
            throw new IllegalStateException("Session fichiers arrêtée ou expirée.");
        }
    }

    private void check(Job job) {
        requireSession();
        if (job.cancelled || Thread.currentThread().isInterrupted()) {
            throw new CancellationException("Opération annulée.");
        }
    }

    synchronized JSONObject status() throws JSONException {
        boolean z;
        JSONObject jSONObjectPut;
        z = true;
        jSONObjectPut = new JSONObject().put("fileServiceReady", this.deadline > SystemClock.elapsedRealtime());
        if (this.active == null) {
            z = false;
        }
        return jSONObjectPut.put("fileJobActive", z).put("activeFileJob", this.active == null ? JSONObject.NULL : copy(this.active)).put("filesFolder", "Download/PhoneMCP").put("maxFileBytes", 536870912L);
    }

    synchronized JSONObject execute(String str, JSONObject jSONObject) throws Exception {
        final Job job;
        requireSession();
        if ("files_list".equals(str)) {
            JSONArray jSONArray = new JSONArray();
            JSONArray jSONArray2 = new JSONArray();
            ArrayList<Job> arrayList = new ArrayList(this.jobs.values());
            arrayList.sort(Comparator.comparingLong(new ToLongFunction() { // from class: fr.phonemcp.FileEngine$$ExternalSyntheticLambda3
                @Override // java.util.function.ToLongFunction
                public final long applyAsLong(Object obj) {
                    return ((FileEngine.Job) obj).value.optLong("createdAt");
                }
            }).reversed());
            for (Job job2 : arrayList) {
                if (jSONArray2.length() < 20) {
                    jSONArray2.put(copy(job2));
                }
                if ("download".equals(job2.value.optString("kind")) && "completed".equals(job2.value.optString("state"))) {
                    try {
                        File file = file(job2.value.getString("jobId"), job2.value.getString("fileName"));
                        if (file.isFile() && jSONArray.length() < 100) {
                            jSONArray.put(copy(job2).put("fileId", job2.value.getString("jobId")).put("sizeBytes", file.length()));
                        }
                    } catch (Exception unused) {
                    }
                }
            }
            return new JSONObject().put("files", jSONArray).put("jobs", jSONArray2).put("folder", "Download/PhoneMCP");
        }
        if ("file_job".equals(str)) {
            Job job3 = this.jobs.get(FilePolicy.id(jSONObject.getString("jobId")));
            if (job3 == null) {
                throw new IllegalArgumentException("Opération introuvable. Consultez phone_files_list avant de relancer.");
            }
            if ("cancel".equals(jSONObject.optString("action", "status")) && !terminal(job3.value.optString("state"))) {
                if ("installing".equals(job3.value.optString("state"))) {
                    throw new IllegalStateException("L’installation a été remise à Android ; elle ne peut plus être annulée ici.");
                }
                cancel(job3);
            }
            return copy(job3);
        }
        if ("files_cancel_all".equals(str)) {
            if (this.active != null) {
                cancel(this.active);
            }
            return new JSONObject().put("cancelled", true);
        }
        String strId = FilePolicy.id(jSONObject.getString("requestId"));
        Job job4 = this.jobs.get(strId);
        String strFingerprint = fingerprint(str, jSONObject);
        if (job4 != null) {
            if (!strFingerprint.equals(job4.value.optString("requestFingerprint"))) {
                throw new IllegalArgumentException("Cet identifiant appartient à une autre opération.");
            }
            return copy(job4);
        }
        if (this.active != null) {
            throw new IllegalStateException("Un transfert ou une installation est déjà en cours. Consultez phone_file_job.");
        }
        if (this.jobs.size() >= 128) {
            throw new IllegalStateException("Historique complet (128 opérations). Les fichiers existants restent disponibles.");
        }
        if ("download_file".equals(str)) {
            final String strUrl = FilePolicy.url(jSONObject.getString("url"));
            final String strName = FilePolicy.name(jSONObject.getString("fileName"));
            final String strHash = FilePolicy.hash(jSONObject.optString("sha256"), false);
            final long jLimit = FilePolicy.limit(jSONObject.optLong("maxBytes", 536870912L));
            job = new Job(new JSONObject().put("jobId", strId).put("kind", "download").put("fileName", strName).put("state", "queued").put("createdAt", System.currentTimeMillis()).put("bytesDone", 0).put("requestFingerprint", strFingerprint));
            begin(job, new Work() { // from class: fr.phonemcp.FileEngine$$ExternalSyntheticLambda4
                @Override // fr.phonemcp.FileEngine.Work
                public final void run() throws Exception {
                    this.f$0.lambda$execute$3(job, strUrl, strName, strHash, jLimit);
                }
            });
        } else if ("install_apk".equals(str)) {
            final String strId2 = FilePolicy.id(jSONObject.getString("fileId"));
            final String strHash2 = FilePolicy.hash(jSONObject.getString("sha256"), true);
            final String strPkg = FilePolicy.pkg(jSONObject.getString("expectedPackage"));
            Job job5 = this.jobs.get(strId2);
            if (job5 == null || !"download".equals(job5.value.optString("kind")) || !"completed".equals(job5.value.optString("state"))) {
                throw new IllegalArgumentException("Téléchargez et vérifiez d’abord l’APK avec phone_download_file.");
            }
            final String string = job5.value.getString("fileName");
            if (!string.toLowerCase(Locale.ROOT).endsWith(".apk")) {
                throw new IllegalArgumentException("Le fichier doit être une APK unique ; les archives XAPK/APKS ne sont pas prises en charge.");
            }
            job = new Job(new JSONObject().put("jobId", strId).put("kind", "install").put("fileId", strId2).put("fileName", string).put("packageName", strPkg).put("state", "queued").put("createdAt", System.currentTimeMillis()).put("requestFingerprint", strFingerprint));
            begin(job, new Work() { // from class: fr.phonemcp.FileEngine$$ExternalSyntheticLambda5
                @Override // fr.phonemcp.FileEngine.Work
                public final void run() throws Exception {
                    this.f$0.lambda$execute$4(job, strId2, string, strHash2, strPkg);
                }
            });
        } else {
            throw new IllegalArgumentException("Commande fichiers inconnue.");
        }
        return copy(job);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$execute$4(Job job, String str, String str2, String str3, String str4) throws Exception {
        install(job, file(str, str2), str3, str4);
    }

    private synchronized void begin(final Job job, final Work work) throws Exception {
        this.jobs.put(job.value.getString("jobId"), job);
        this.active = job;
        save(job);
        this.worker.execute(new Runnable() { // from class: fr.phonemcp.FileEngine$$ExternalSyntheticLambda8
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$begin$5(job, work);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Bottom block not found for handler: all -> 0x0018 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public /* synthetic */ void lambda$begin$5(Job job, Work work) {
        try {
            check(job);
            work.run();
            synchronized (this) {
                try {
                    save(job);
                } catch (Exception unused) {
                }
                if (this.active == job) {
                    this.active = null;
                }
            }
            return;
        } catch (Exception e) {
            synchronized (this) {
                try {
                    try {
                        job.value.put("state", job.cancelled ? "cancelled" : "failed").put("error", safeError(e));
                    } catch (Throwable th) {
                        throw th;
                    }
                } catch (JSONException unused2) {
                }
                synchronized (this) {
                    try {
                        save(job);
                    } catch (Exception unused3) {
                    }
                    if (this.active == job) {
                        this.active = null;
                    }
                    return;
                }
            }
        }
        if (this.active == job) {
            this.active = null;
        }
        throw th;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code duplicated, block: B:123:0x026c  */
    /* JADX WARN: Code duplicated, block: B:126:0x0275  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r24v0, types: [fr.phonemcp.FileEngine] */
    /* JADX WARN: Type inference failed for: r2v0, types: [fr.phonemcp.FileEngine$Job] */
    /* JADX WARN: Type inference failed for: r2v1, types: [fr.phonemcp.FileEngine$Job] */
    /* JADX WARN: Type inference failed for: r2v10 */
    /* JADX WARN: Type inference failed for: r2v11 */
    /* JADX WARN: Type inference failed for: r2v12 */
    /* JADX WARN: Type inference failed for: r2v15, types: [fr.phonemcp.FileEngine$Job] */
    /* JADX WARN: Type inference failed for: r2v16 */
    /* JADX WARN: Type inference failed for: r2v17 */
    /* JADX WARN: Type inference failed for: r2v18 */
    /* JADX WARN: Type inference failed for: r2v19, types: [fr.phonemcp.FileEngine$Job] */
    /* JADX WARN: Type inference failed for: r2v2 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Type inference failed for: r2v4 */
    /* JADX WARN: Type inference failed for: r2v5 */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX INFO: renamed from: download, reason: merged with bridge method [inline-methods] */
    public void lambda$execute$3(Job job, String str, String str2, String str3, long j) throws Exception {
        HttpsURLConnection httpsURLConnection;
        Throwable th;
        OutputStream outputStream;
        OutputStream outputStream2;
        ?? r2 = job;
        File file = new File(this.downloads, r2.value.getString("jobId"));
        ensureDirectory(file);
        File file2 = file(r2.value.getString("jobId"), str2);
        File file3 = new File(file, ".download.part");
        if (file2.exists() || file3.exists()) {
            throw new IOException("Le transfert existe déjà. Vérifiez son état.");
        }
        String string = str;
        int i = 0;
        HttpsURLConnection httpsURLConnection2 = null;
        while (true) {
            if (i > 5) {
                httpsURLConnection = httpsURLConnection2;
                break;
            }
            try {
                check(job);
                HttpsURLConnection httpsURLConnection3 = (HttpsURLConnection) new URL(FilePolicy.url(string)).openConnection();
                try {
                    r2.connection = httpsURLConnection3;
                    httpsURLConnection3.setConnectTimeout(15000);
                    httpsURLConnection3.setReadTimeout(30000);
                    httpsURLConnection3.setInstanceFollowRedirects(false);
                    httpsURLConnection3.setRequestProperty("Accept-Encoding", "identity");
                    int responseCode = httpsURLConnection3.getResponseCode();
                    if (responseCode < 300 || responseCode >= 400) {
                        if (responseCode != 200) {
                            throw new IOException("Téléchargement refusé (HTTP " + responseCode + ").");
                        }
                        httpsURLConnection = httpsURLConnection3;
                        break;
                    }
                    String headerField = httpsURLConnection3.getHeaderField("Location");
                    httpsURLConnection3.disconnect();
                    if (headerField == null || i == 5) {
                        throw new IOException("Trop de redirections du téléchargement.");
                    }
                    string = new URL(new URL(string), headerField).toString();
                    i++;
                    httpsURLConnection2 = httpsURLConnection3;
                } catch (Throwable th2) {
                    th = th2;
                    httpsURLConnection2 = httpsURLConnection3;
                    r2.connection = null;
                    if (httpsURLConnection2 != null) {
                        httpsURLConnection2.disconnect();
                    }
                    if (file3.exists()) {
                        Files.deleteIfExists(file3.toPath());
                    }
                    throw th;
                }
            } catch (Throwable th3) {
                th = th3;
            }
        }
        try {
            long contentLengthLong = httpsURLConnection.getContentLengthLong();
            if (contentLengthLong > j) {
                throw new IOException("Fichier trop volumineux.");
            }
            update(r2, "downloading", 0L, contentLengthLong);
            try {
                MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
                long jElapsedRealtime = SystemClock.elapsedRealtime();
                InputStream inputStream = httpsURLConnection.getInputStream();
                try {
                    OutputStream outputStreamNewOutputStream = Files.newOutputStream(file3.toPath(), StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
                    r2 = 65536;
                    try {
                        try {
                            byte[] bArr = new byte[65536];
                            long j2 = 0;
                            long j3 = 0;
                            while (true) {
                                int i2 = inputStream.read(bArr);
                                if (i2 == -1) {
                                    r2 = job;
                                    OutputStream outputStream3 = outputStreamNewOutputStream;
                                    if (outputStream3 != null) {
                                        outputStream3.close();
                                    }
                                    if (inputStream != null) {
                                        inputStream.close();
                                    }
                                    check(job);
                                    if (j2 == 0 || (contentLengthLong >= 0 && j2 != contentLengthLong)) {
                                        throw new IOException("Téléchargement vide ou incomplet.");
                                    }
                                    String strHex = hex(messageDigest.digest());
                                    if (!str3.isEmpty() && !MessageDigest.isEqual(strHex.getBytes(StandardCharsets.US_ASCII), str3.getBytes(StandardCharsets.US_ASCII))) {
                                        throw new SecurityException("Empreinte SHA-256 différente : fichier refusé.");
                                    }
                                    if (!file3.renameTo(file2)) {
                                        throw new IOException("Impossible de terminer le fichier.");
                                    }
                                    synchronized (this) {
                                        r2.value.put("state", "completed").put("bytesDone", j2).put("totalBytes", j2).put("sha256", strHex).put("fileId", r2.value.getString("jobId")).put("folder", "Download/PhoneMCP/" + r2.value.getString("jobId"));
                                        addArchiveInfo(r2, file2);
                                        save(job);
                                    }
                                    r2.connection = null;
                                    if (httpsURLConnection != null) {
                                        httpsURLConnection.disconnect();
                                    }
                                    if (file3.exists()) {
                                        Files.deleteIfExists(file3.toPath());
                                        return;
                                    }
                                    return;
                                }
                                check(job);
                                outputStream2 = outputStreamNewOutputStream;
                                long j4 = j2 + ((long) i2);
                                if (j4 > j) {
                                    break;
                                }
                                try {
                                    if (SystemClock.elapsedRealtime() - jElapsedRealtime > 600000) {
                                        break;
                                    }
                                    outputStreamNewOutputStream = outputStream2;
                                    outputStreamNewOutputStream.write(bArr, 0, i2);
                                    messageDigest.update(bArr, 0, i2);
                                    if (j4 - j3 >= 262144) {
                                        outputStream = outputStreamNewOutputStream;
                                        byte[] bArr2 = bArr;
                                        r2 = job;
                                        try {
                                            update(r2, "downloading", j4, contentLengthLong);
                                            bArr = bArr2;
                                            j3 = j4;
                                            outputStreamNewOutputStream = outputStream;
                                            j2 = j3;
                                        } catch (Throwable th4) {
                                            th = th4;
                                        }
                                    } else {
                                        bArr = bArr;
                                        j2 = j4;
                                        outputStreamNewOutputStream = outputStreamNewOutputStream;
                                    }
                                } catch (Throwable th5) {
                                    th = th5;
                                    r2 = job;
                                    outputStream = outputStream2;
                                }
                                th = th4;
                                Throwable th6 = th;
                                if (outputStream == null) {
                                    throw th6;
                                }
                                try {
                                    outputStream.close();
                                    throw th6;
                                } catch (Throwable th7) {
                                    th6.addSuppressed(th7);
                                    throw th6;
                                }
                            }
                            r2 = job;
                            outputStream = outputStream2;
                            throw new IOException("Limite de taille ou délai de téléchargement dépassé.");
                        } catch (Throwable th8) {
                            th = th8;
                            r2 = job;
                            outputStream = outputStreamNewOutputStream;
                        }
                    } catch (Throwable th9) {
                        th = th9;
                        Throwable th10 = th;
                        if (inputStream == null) {
                            throw th10;
                        }
                        try {
                            inputStream.close();
                            throw th10;
                        } catch (Throwable th11) {
                            th10.addSuppressed(th11);
                            throw th10;
                        }
                    }
                } catch (Throwable th12) {
                    th = th12;
                    r2 = job;
                }
            } catch (Throwable th13) {
                th = th13;
                r2 = job;
                httpsURLConnection2 = httpsURLConnection;
                r2.connection = null;
                if (httpsURLConnection2 != null) {
                    httpsURLConnection2.disconnect();
                }
                if (file3.exists()) {
                    Files.deleteIfExists(file3.toPath());
                }
                throw th;
            }
        } catch (Throwable th14) {
            th = th14;
            httpsURLConnection2 = httpsURLConnection;
            r2.connection = null;
            if (httpsURLConnection2 != null) {
                httpsURLConnection2.disconnect();
            }
            if (file3.exists()) {
                Files.deleteIfExists(file3.toPath());
            }
            throw th;
        }
    }

    /* JADX WARN: Code duplicated, block: B:127:0x026d  */
    /* JADX WARN: Code duplicated, block: B:130:0x0275  */
    /* JADX WARN: Code duplicated, block: B:137:0x025f A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:167:? A[Catch: all -> 0x0268, SYNTHETIC, TRY_LEAVE, TryCatch #3 {all -> 0x0268, blocks: (B:3:0x0029, B:18:0x0092, B:19:0x0095, B:21:0x00ba, B:23:0x00ca, B:25:0x00d2, B:26:0x00d5, B:33:0x00f7, B:102:0x023d, B:103:0x023e, B:104:0x0245, B:105:0x0246, B:106:0x024d, B:122:0x0267, B:121:0x0264, B:118:0x025f, B:27:0x00d6, B:31:0x00f3, B:32:0x00f6, B:30:0x00f1, B:4:0x0049, B:16:0x008d, B:114:0x025a, B:113:0x0257), top: B:141:0x0029, inners: #1, #10, #11 }] */
    private void install(Job job, File file, String str, String str2) throws Exception {
        final Process processStart;
        ScheduledFuture<?> scheduledFutureSchedule;
        File file2 = new File(this.records, job.value.getString("jobId") + ".apk");
        try {
            update(job, "verifying", 0L, file.length());
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            InputStream inputStreamNewInputStream = Files.newInputStream(file.toPath(), LinkOption.NOFOLLOW_LINKS);
            try {
                OutputStream outputStreamNewOutputStream = Files.newOutputStream(file2.toPath(), StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
                try {
                    byte[] bArr = new byte[65536];
                    long j = 0;
                    while (true) {
                        int i = inputStreamNewInputStream.read(bArr);
                        if (i != -1) {
                            check(job);
                            j += (long) i;
                            if (j > 536870912) {
                                throw new IOException("APK trop volumineuse.");
                            }
                            outputStreamNewOutputStream.write(bArr, 0, i);
                            messageDigest.update(bArr, 0, i);
                            if (inputStreamNewInputStream != null) {
                                throw th;
                            }
                            try {
                                inputStreamNewInputStream.close();
                                throw th;
                            } catch (Throwable th) {
                                th.addSuppressed(th);
                                throw th;
                            }
                        }
                        long j2 = j;
                        if (outputStreamNewOutputStream != null) {
                            outputStreamNewOutputStream.close();
                        }
                        if (inputStreamNewInputStream != null) {
                            inputStreamNewInputStream.close();
                        }
                        Os.chmod(file2.getPath(), 384);
                        String strHex = hex(messageDigest.digest());
                        if (!MessageDigest.isEqual(strHex.getBytes(StandardCharsets.US_ASCII), str.getBytes(StandardCharsets.US_ASCII))) {
                            throw new SecurityException("L’APK ne correspond plus à l’empreinte attendue. Aucune installation effectuée.");
                        }
                        PackageInfo packageArchiveInfo = this.context.getPackageManager().getPackageArchiveInfo(file2.getPath(), 0);
                        if (packageArchiveInfo == null || !str2.equals(packageArchiveInfo.packageName)) {
                            throw new SecurityException("L’APK ne correspond pas à l’application attendue.");
                        }
                        check(job);
                        synchronized (this) {
                            job.value.put("sha256", strHex).put("versionCode", packageArchiveInfo.getLongVersionCode()).put("versionName", packageArchiveInfo.versionName == null ? HttpUrl.FRAGMENT_ENCODE_SET : packageArchiveInfo.versionName);
                        }
                        update(job, "installing", j2, j2);
                        processStart = new ProcessBuilder(FilePolicy.installArgs(str2, j2, this.user)).redirectErrorStream(true).start();
                        try {
                            job.process = processStart;
                            final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                            scheduledFutureSchedule = this.timeouts.schedule(new Runnable() { // from class: fr.phonemcp.FileEngine$$ExternalSyntheticLambda6
                                @Override // java.lang.Runnable
                                public final void run() {
                                    FileEngine.lambda$install$6(processStart);
                                }
                            }, 120L, TimeUnit.SECONDS);
                            try {
                                Thread thread = new Thread(new Runnable() { // from class: fr.phonemcp.FileEngine$$ExternalSyntheticLambda7
                                    @Override // java.lang.Runnable
                                    public final void run() {
                                        FileEngine.lambda$install$7(processStart, byteArrayOutputStream);
                                    }
                                }, "phone-mcp-install-result");
                                thread.start();
                                InputStream inputStreamNewInputStream2 = Files.newInputStream(file2.toPath(), new OpenOption[0]);
                                try {
                                    OutputStream outputStream = processStart.getOutputStream();
                                    try {
                                        byte[] bArr2 = new byte[65536];
                                        while (true) {
                                            int i2 = inputStreamNewInputStream2.read(bArr2);
                                            if (i2 == -1) {
                                                break;
                                            }
                                            check(job);
                                            outputStream.write(bArr2, 0, i2);
                                            th = th;
                                            if (scheduledFutureSchedule != null) {
                                                scheduledFutureSchedule.cancel(false);
                                            }
                                            job.process = null;
                                            if (processStart != null && processStart.isAlive()) {
                                                processStart.destroyForcibly();
                                            }
                                            Files.deleteIfExists(file2.toPath());
                                            throw th;
                                        }
                                        if (outputStream != null) {
                                            outputStream.close();
                                        }
                                        if (inputStreamNewInputStream2 != null) {
                                            inputStreamNewInputStream2.close();
                                        }
                                        if (!processStart.waitFor(120L, TimeUnit.SECONDS)) {
                                            processStart.destroyForcibly();
                                            throw new IOException("Android n’a pas confirmé l’installation. Vérifiez la version installée avant de réessayer.");
                                        }
                                        scheduledFutureSchedule.cancel(false);
                                        thread.join(2000L);
                                        String string = byteArrayOutputStream.toString("UTF-8");
                                        if (processStart.exitValue() != 0 || !string.trim().equals("Success")) {
                                            throw new IOException("Installation refusée par Android : " + string.substring(0, Math.min(string.length(), 1200)));
                                        }
                                        PackageInfo packageInfo = this.context.getPackageManager().getPackageInfo(str2, 0);
                                        if (packageInfo.getLongVersionCode() != packageArchiveInfo.getLongVersionCode()) {
                                            throw new IOException("La version installée ne correspond pas au résultat attendu.");
                                        }
                                        synchronized (this) {
                                            job.value.put("state", "completed").put("installed", true).put("installedVersion", packageInfo.versionName == null ? HttpUrl.FRAGMENT_ENCODE_SET : packageInfo.versionName);
                                            save(job);
                                        }
                                        if (scheduledFutureSchedule != null) {
                                            scheduledFutureSchedule.cancel(false);
                                        }
                                        job.process = null;
                                        if (processStart != null && processStart.isAlive()) {
                                            processStart.destroyForcibly();
                                        }
                                        Files.deleteIfExists(file2.toPath());
                                        return;
                                    } catch (Throwable th2) {
                                        if (outputStream == null) {
                                            throw th2;
                                        }
                                        try {
                                            outputStream.close();
                                            throw th2;
                                        } catch (Throwable th3) {
                                            th2.addSuppressed(th3);
                                            throw th2;
                                        }
                                        th = th;
                                        if (scheduledFutureSchedule != null) {
                                            scheduledFutureSchedule.cancel(false);
                                        }
                                        job.process = null;
                                        if (processStart != null) {
                                            processStart.destroyForcibly();
                                        }
                                        Files.deleteIfExists(file2.toPath());
                                        throw th;
                                    }
                                } catch (Throwable th4) {
                                    if (inputStreamNewInputStream2 == null) {
                                        throw th4;
                                    }
                                    try {
                                        inputStreamNewInputStream2.close();
                                        throw th4;
                                    } catch (Throwable th5) {
                                        th4.addSuppressed(th5);
                                        throw th4;
                                    }
                                }
                            } catch (Throwable th6) {
                                th = th6;
                            }
                        } catch (Throwable th7) {
                            th = th7;
                            scheduledFutureSchedule = null;
                        }
                        th = th;
                        processStart = null;
                        scheduledFutureSchedule = null;
                        if (scheduledFutureSchedule != null) {
                            scheduledFutureSchedule.cancel(false);
                        }
                        job.process = null;
                        if (processStart != null) {
                            processStart.destroyForcibly();
                        }
                        Files.deleteIfExists(file2.toPath());
                        throw th;
                    }
                } catch (Throwable th8) {
                    if (outputStreamNewOutputStream == null) {
                        throw th8;
                    }
                    try {
                        outputStreamNewOutputStream.close();
                        throw th8;
                    } catch (Throwable th9) {
                        th8.addSuppressed(th9);
                        throw th8;
                    }
                    th = th;
                    processStart = null;
                    scheduledFutureSchedule = null;
                    if (scheduledFutureSchedule != null) {
                        scheduledFutureSchedule.cancel(false);
                    }
                    job.process = null;
                    if (processStart != null) {
                        processStart.destroyForcibly();
                    }
                    Files.deleteIfExists(file2.toPath());
                    throw th;
                }
            } catch (Throwable th10) {
                if (inputStreamNewInputStream != null) {
                    throw th10;
                }
                inputStreamNewInputStream.close();
                throw th10;
            }
        } catch (Throwable th11) {
            th = th11;
            processStart = null;
        }
    }

    static /* synthetic */ void lambda$install$6(Process process) {
        if (process.isAlive()) {
            process.destroyForcibly();
        }
    }

    static /* synthetic */ void lambda$install$7(Process process, ByteArrayOutputStream byteArrayOutputStream) {
        try {
            InputStream inputStream = process.getInputStream();
            try {
                byte[] bArr = new byte[Segment.SHARE_MINIMUM];
                while (true) {
                    int i = inputStream.read(bArr);
                    if (i == -1) {
                        break;
                    } else if (byteArrayOutputStream.size() < 16000) {
                        byteArrayOutputStream.write(bArr, 0, Math.min(i, 16000 - byteArrayOutputStream.size()));
                    }
                }
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (Throwable th) {
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                }
                throw th;
            }
        } catch (IOException unused) {
        }
    }

    private void addArchiveInfo(Job job, File file) {
        PackageInfo packageArchiveInfo;
        try {
            if (!file.getName().toLowerCase(Locale.ROOT).endsWith(".apk") || (packageArchiveInfo = this.context.getPackageManager().getPackageArchiveInfo(file.getPath(), 0)) == null) {
                return;
            }
            job.value.put("packageName", packageArchiveInfo.packageName).put("versionName", packageArchiveInfo.versionName == null ? HttpUrl.FRAGMENT_ENCODE_SET : packageArchiveInfo.versionName).put("versionCode", packageArchiveInfo.getLongVersionCode());
        } catch (Exception unused) {
        }
    }

    private File file(String str, String str2) throws Exception {
        File file = new File(this.downloads, FilePolicy.id(str));
        File file2 = new File(file, FilePolicy.name(str2));
        ensureDirectory(this.downloads);
        if (Files.isSymbolicLink(file.toPath()) || Files.isSymbolicLink(file2.toPath()) || !file2.getCanonicalPath().equals(new File(this.downloads.getCanonicalFile(), str + "/" + str2).getPath())) {
            throw new SecurityException("Chemin de fichier refusé.");
        }
        return file2;
    }

    private synchronized void update(Job job, String str, long j, long j2) throws Exception {
        job.value.put("state", str).put("bytesDone", j).put("totalBytes", j2);
    }

    private synchronized void save(Job job) throws Exception {
        File file = new File(this.records, FilePolicy.id(job.value.getString("jobId")) + ".json");
        File file2 = new File(this.records, file.getName() + ".tmp");
        if (Files.isSymbolicLink(file.toPath()) || Files.isSymbolicLink(file2.toPath())) {
            throw new SecurityException("Historique de transfert invalide.");
        }
        Files.write(file2.toPath(), job.value.toString().getBytes(StandardCharsets.UTF_8), new OpenOption[0]);
        Os.chmod(file2.getPath(), 384);
        Files.move(file2.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
    }

    private static JSONObject copy(Job job) throws JSONException {
        JSONObject jSONObject = new JSONObject(job.value.toString());
        jSONObject.remove("requestFingerprint");
        return jSONObject;
    }

    private static String fingerprint(String str, JSONObject jSONObject) throws Exception {
        String[] strArr = "download_file".equals(str) ? new String[]{"url", "fileName", "sha256", "maxBytes"} : new String[]{"fileId", "sha256", "expectedPackage"};
        JSONArray jSONArrayPut = new JSONArray().put(str);
        for (String str2 : strArr) {
            Object objOpt = jSONObject.opt(str2);
            if ("maxBytes".equals(str2)) {
                objOpt = Long.valueOf(jSONObject.optLong(str2, 536870912L));
            } else if ("sha256".equals(str2)) {
                objOpt = jSONObject.optString(str2, HttpUrl.FRAGMENT_ENCODE_SET).toLowerCase(Locale.ROOT);
            }
            jSONArrayPut.put(objOpt);
        }
        return hex(MessageDigest.getInstance("SHA-256").digest(jSONArrayPut.toString().getBytes(StandardCharsets.UTF_8)));
    }

    private static String hex(byte[] bArr) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bArr) {
            sb.append(String.format(Locale.ROOT, "%02x", Integer.valueOf(b & UByte.MAX_VALUE)));
        }
        return sb.toString();
    }

    private static boolean terminal(String str) {
        return Arrays.asList("completed", "failed", "cancelled", "interrupted").contains(str);
    }

    private static String safeError(Exception exc) {
        String message = exc.getMessage();
        if (message == null) {
            return "Opération impossible.";
        }
        String strReplaceAll = message.replaceAll("https?://[^\\s]+", "[lien]");
        return strReplaceAll.substring(0, Math.min(strReplaceAll.length(), 1400));
    }

    private void cancel(Job job) {
        job.cancelled = true;
        if (job.connection != null) {
            job.connection.disconnect();
        }
    }

    synchronized void stop() {
        this.deadline = 0L;
        if (this.active != null) {
            cancel(this.active);
            if (this.active.process != null) {
                this.active.process.destroyForcibly();
            }
        }
    }

    void destroy() {
        stop();
        this.worker.shutdownNow();
        this.timeouts.shutdownNow();
    }
}
