package fr.phonemcp;

import android.graphics.Bitmap;
import android.media.Image;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: loaded from: classes.dex */
final class PreviewFrames {
    private final AtomicReference<CompletableFuture<byte[]>> pending = new AtomicReference<>();

    PreviewFrames() {
    }

    byte[] next() throws Exception {
        CompletableFuture completableFuture = new CompletableFuture();
        if (!PhoneNotificationService$$ExternalSyntheticBackport0.m(this.pending, null, completableFuture)) {
            throw new IllegalStateException("Aperçu en cours.");
        }
        try {
            return (byte[]) completableFuture.get(850L, TimeUnit.MILLISECONDS);
        } finally {
            PhoneNotificationService$$ExternalSyntheticBackport0.m(this.pending, completableFuture, null);
            completableFuture.cancel(false);
        }
    }

    void accept(Image image) {
        Bitmap bitmap = null;
        CompletableFuture<byte[]> andSet = this.pending.getAndSet(null);
        if (andSet != null) {
            try {
                if (andSet.isDone()) {
                    return;
                }
                try {
                    Image.Plane plane = image.getPlanes()[0];
                    int width = image.getWidth();
                    int height = image.getHeight();
                    int pixelStride = plane.getPixelStride();
                    if (pixelStride != 4) {
                        throw new IllegalStateException("Format d’aperçu indisponible.");
                    }
                    ByteBuffer buffer = plane.getBuffer();
                    ByteBuffer byteBufferAllocate = ByteBuffer.allocate(width * height * pixelStride);
                    for (int i = 0; i < height; i++) {
                        ByteBuffer byteBufferDuplicate = buffer.duplicate();
                        byteBufferDuplicate.position(plane.getRowStride() * i);
                        byteBufferDuplicate.limit(byteBufferDuplicate.position() + (width * pixelStride));
                        byteBufferAllocate.put(byteBufferDuplicate);
                    }
                    byteBufferAllocate.rewind();
                    Bitmap bitmapCreateBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                    bitmapCreateBitmap.copyPixelsFromBuffer(byteBufferAllocate);
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    bitmapCreateBitmap.compress(Bitmap.CompressFormat.JPEG, 65, byteArrayOutputStream);
                    if (byteArrayOutputStream.size() > 300000) {
                        throw new IllegalStateException("Aperçu trop volumineux.");
                    }
                    andSet.complete(byteArrayOutputStream.toByteArray());
                    if (bitmapCreateBitmap != null) {
                        bitmapCreateBitmap.recycle();
                    }
                } catch (Exception e) {
                    andSet.completeExceptionally(e);
                    if (0 != 0) {
                        bitmap.recycle();
                    }
                }
            } catch (Throwable th) {
                if (0 != 0) {
                    bitmap.recycle();
                }
                throw th;
            }
        }
    }

    void clear() {
        CompletableFuture<byte[]> andSet = this.pending.getAndSet(null);
        if (andSet != null) {
            andSet.cancel(false);
        }
    }
}
