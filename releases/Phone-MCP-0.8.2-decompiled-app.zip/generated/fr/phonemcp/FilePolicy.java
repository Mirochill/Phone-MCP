package fr.phonemcp;

import java.net.URI;
import java.util.Locale;
import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
final class FilePolicy {
    static final long MAX_BYTES = 536870912;

    FilePolicy() {
    }

    static String url(String str) {
        if (str != null) {
            try {
                if (str.length() <= 4096) {
                    URI uri = new URI(str);
                    if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null || uri.getUserInfo() != null || uri.getFragment() != null) {
                        throw new Exception();
                    }
                    return uri.toASCIIString();
                }
            } catch (Exception unused) {
                throw new IllegalArgumentException("Utilisez un lien de téléchargement HTTPS direct, sans identifiants intégrés.");
            }
        }
        throw new Exception();
    }

    static String name(String str) {
        if (str == null || str.length() < 1 || str.length() > 140 || !str.equals(str.trim()) || str.startsWith(".") || str.equals("..") || str.matches(".*[\\\\/:*?\"<>|\\p{Cntrl}].*") || str.toLowerCase(Locale.ROOT).endsWith(".part")) {
            throw new IllegalArgumentException("Nom de fichier invalide : utilisez un nom simple, sans dossier.");
        }
        return str;
    }

    static String id(String str) {
        if (str == null || !str.matches("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")) {
            throw new IllegalArgumentException("Identifiant de transfert invalide.");
        }
        return str;
    }

    static String hash(String str, boolean z) {
        if ((str == null || str.isEmpty()) && !z) {
            return HttpUrl.FRAGMENT_ENCODE_SET;
        }
        if (str == null || !str.matches("[A-Fa-f0-9]{64}")) {
            throw new IllegalArgumentException("Une empreinte SHA-256 de 64 caractères est nécessaire.");
        }
        return str.toLowerCase(Locale.ROOT);
    }

    static String pkg(String str) {
        if (str == null || str.length() > 240 || !str.matches("[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+")) {
            throw new IllegalArgumentException("Identifiant d’application invalide.");
        }
        return str;
    }

    static long limit(long j) {
        if (j < 1 || j > MAX_BYTES) {
            throw new IllegalArgumentException("La taille maximale est de 512 Mo par fichier.");
        }
        return j;
    }

    static String[] installArgs(String str, long j, int i) {
        if (j < 1 || j > MAX_BYTES || i < 0) {
            throw new IllegalArgumentException("Installation invalide.");
        }
        return new String[]{"/system/bin/pm", "install", "-r", "--restrict-permissions", "--user", Integer.toString(i), "--pkg", pkg(str), "-S", Long.toString(j), "--", "-"};
    }
}
