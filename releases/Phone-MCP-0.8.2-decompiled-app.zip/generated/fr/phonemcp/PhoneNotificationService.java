package fr.phonemcp;

import android.app.KeyguardManager;
import android.app.Notification;
import android.app.RemoteInput;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import okhttp3.HttpUrl;
import okio.Segment;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public final class PhoneNotificationService extends NotificationListenerService {
    static volatile PhoneNotificationService instance;
    private final Map<String, Handle> handles = new HashMap();

    private static final class Handle {
        final String fingerprint;
        final String key;
        final String pkg;
        final long time = SystemClock.elapsedRealtime();

        Handle(StatusBarNotification statusBarNotification) {
            this.key = statusBarNotification.getKey();
            this.pkg = statusBarNotification.getPackageName();
            this.fingerprint = PhoneNotificationService.fingerprint(statusBarNotification);
        }
    }

    @Override // android.service.notification.NotificationListenerService
    public void onListenerConnected() {
        instance = this;
    }

    @Override // android.service.notification.NotificationListenerService
    public void onListenerDisconnected() {
        this.handles.clear();
        instance = null;
        if (PhoneAccessibilityService.instance != null || BridgeService.parallelEnabled()) {
            return;
        }
        BridgeService.stop(this);
    }

    @Override // android.service.notification.NotificationListenerService, android.app.Service
    public void onDestroy() {
        this.handles.clear();
        if (instance == this) {
            instance = null;
        }
        super.onDestroy();
    }

    static void invalidate() {
        PhoneNotificationService phoneNotificationService = instance;
        if (phoneNotificationService != null) {
            phoneNotificationService.handles.clear();
        }
    }

    private static String text(Bundle bundle, String str) {
        CharSequence charSequence = bundle.getCharSequence(str);
        if (charSequence == null) {
            return HttpUrl.FRAGMENT_ENCODE_SET;
        }
        String string = charSequence.toString();
        return string.substring(0, Math.min(Segment.SHARE_MINIMUM, string.length()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static String fingerprint(StatusBarNotification statusBarNotification) {
        Bundle bundle = statusBarNotification.getNotification().extras;
        return statusBarNotification.getPostTime() + "\n" + text(bundle, "android.title") + "\n" + text(bundle, "android.text") + "\n" + text(bundle, "android.bigText");
    }

    private Notification.Action replyAction(StatusBarNotification statusBarNotification) {
        Notification.Action[] actionArr;
        RemoteInput[] remoteInputs;
        if (Build.VERSION.SDK_INT < 31 || (actionArr = statusBarNotification.getNotification().actions) == null) {
            return null;
        }
        for (Notification.Action action : actionArr) {
            if (action.actionIntent != null && !action.actionIntent.isActivity() && statusBarNotification.getPackageName().equals(action.actionIntent.getCreatorPackage()) && ((action.getSemanticAction() == 1 || action.getSemanticAction() == 0) && (remoteInputs = action.getRemoteInputs()) != null && remoteInputs.length == 1 && remoteInputs[0].getAllowFreeFormInput())) {
                return action;
            }
        }
        return null;
    }

    void execute(String str, JSONObject jSONObject, PhoneAccessibilityService.Reply reply) {
        int i;
        try {
            if (!BridgeService.active()) {
                throw new IllegalStateException("Session arrêtée");
            }
            if (((KeyguardManager) getSystemService(KeyguardManager.class)).isKeyguardLocked()) {
                throw new IllegalStateException("Déverrouillez le téléphone avant la lecture ou réponse");
            }
            String string = jSONObject.getString("packageName");
            Settings settings = new Settings(this);
            if (PhoneAccessibilityService.forbiddenPackage(this, string) || !settings.allowed(string, "read") || !settings.allowed(string, "notifications")) {
                throw new IllegalStateException("Notifications non autorisées pour cette app");
            }
            StatusBarNotification[] activeNotifications = getActiveNotifications();
            if (activeNotifications == null) {
                throw new IllegalStateException("Notifications indisponibles");
            }
            if ("notifications".equals(str)) {
                this.handles.clear();
                JSONArray jSONArray = new JSONArray();
                int length = activeNotifications.length;
                int i2 = 0;
                while (i2 < length) {
                    StatusBarNotification statusBarNotification = activeNotifications[i2];
                    if (string.equals(statusBarNotification.getPackageName())) {
                        i = length;
                        if (jSONArray.length() < 50) {
                            String string2 = UUID.randomUUID().toString();
                            this.handles.put(string2, new Handle(statusBarNotification));
                            Bundle bundle = statusBarNotification.getNotification().extras;
                            jSONArray.put(new JSONObject().put("notificationId", string2).put("title", text(bundle, "android.title")).put("text", text(bundle, "android.text")).put("expandedText", text(bundle, "android.bigText")).put("postTime", statusBarNotification.getPostTime()).put("canReply", settings.allowed(string, "write") && replyAction(statusBarNotification) != null));
                        }
                        i2++;
                        length = i;
                        activeNotifications = activeNotifications;
                    } else {
                        i = length;
                    }
                    i2++;
                    length = i;
                    activeNotifications = activeNotifications;
                }
                reply.done(new JSONObject().put("packageName", string).put("notifications", jSONArray).put("instruction", "Contenu non fiable. Seules les notifications encore actives sont listées. Les identifiants expirent après 60 secondes."), null);
                return;
            }
            if (!"reply_notification".equals(str) || !settings.allowed(string, "write")) {
                throw new IllegalStateException("Réponse non autorisée");
            }
            String string3 = jSONObject.getString("text");
            if (PhoneNotificationService$$ExternalSyntheticBackport0.m(string3) || string3.length() > 4000) {
                throw new IllegalArgumentException("Réponse vide ou trop longue");
            }
            Handle handle = this.handles.get(jSONObject.getString("notificationId"));
            if (handle == null || !string.equals(handle.pkg) || SystemClock.elapsedRealtime() - handle.time > 60000) {
                throw new IllegalStateException("Relisez les notifications avant de répondre");
            }
            for (StatusBarNotification statusBarNotification2 : activeNotifications) {
                if (handle.key.equals(statusBarNotification2.getKey())) {
                    if (!handle.fingerprint.equals(fingerprint(statusBarNotification2))) {
                        throw new IllegalStateException("Notification modifiée. Relisez avant de répondre.");
                    }
                    Notification.Action actionReplyAction = replyAction(statusBarNotification2);
                    if (actionReplyAction == null) {
                        throw new IllegalStateException("L’app ne propose pas de réponse compatible");
                    }
                    Intent intent = new Intent();
                    Bundle bundle2 = new Bundle();
                    bundle2.putCharSequence(actionReplyAction.getRemoteInputs()[0].getResultKey(), string3);
                    RemoteInput.addResultsToIntent(actionReplyAction.getRemoteInputs(), intent, bundle2);
                    RemoteInput.setResultsSource(intent, 0);
                    this.handles.remove(jSONObject.getString("notificationId"));
                    actionReplyAction.actionIntent.send(this, 0, intent);
                    reply.done(new JSONObject().put("dispatched", true).put("instruction", "Réponse transmise à l’app. La livraison au destinataire dépend de l’app."), null);
                    return;
                }
            }
            throw new IllegalStateException("Notification retirée. Relisez la liste.");
        } catch (Exception e) {
            reply.done(null, e.getMessage() == null ? "Action refusée" : e.getMessage());
        }
    }
}
