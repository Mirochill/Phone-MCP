package fr.phonemcp;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* JADX INFO: loaded from: classes.dex */
public interface IPreviewCallback extends IInterface {
    public static final String DESCRIPTOR = "fr.phonemcp.IPreviewCallback";

    public static class Default implements IPreviewCallback {
        @Override // android.os.IInterface
        public IBinder asBinder() {
            return null;
        }

        @Override // fr.phonemcp.IPreviewCallback
        public void onPreviewRequested(String str) throws RemoteException {
        }
    }

    void onPreviewRequested(String str) throws RemoteException;

    public static abstract class Stub extends Binder implements IPreviewCallback {
        static final int TRANSACTION_onPreviewRequested = 1;

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }

        public Stub() {
            attachInterface(this, IPreviewCallback.DESCRIPTOR);
        }

        public static IPreviewCallback asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface(IPreviewCallback.DESCRIPTOR);
            if (iInterfaceQueryLocalInterface != null && (iInterfaceQueryLocalInterface instanceof IPreviewCallback)) {
                return (IPreviewCallback) iInterfaceQueryLocalInterface;
            }
            return new Proxy(iBinder);
        }

        @Override // android.os.Binder
        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i >= 1 && i <= 16777215) {
                parcel.enforceInterface(IPreviewCallback.DESCRIPTOR);
            }
            if (i == 1598968902) {
                parcel2.writeString(IPreviewCallback.DESCRIPTOR);
                return true;
            }
            if (i == 1) {
                onPreviewRequested(parcel.readString());
                return true;
            }
            return super.onTransact(i, parcel, parcel2, i2);
        }

        private static class Proxy implements IPreviewCallback {
            private IBinder mRemote;

            Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return IPreviewCallback.DESCRIPTOR;
            }

            @Override // fr.phonemcp.IPreviewCallback
            public void onPreviewRequested(String str) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IPreviewCallback.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    this.mRemote.transact(1, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }
        }
    }
}
