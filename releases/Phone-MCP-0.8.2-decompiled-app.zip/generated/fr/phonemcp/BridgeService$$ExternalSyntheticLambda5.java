package fr.phonemcp;

/* JADX INFO: compiled from: D8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class BridgeService$$ExternalSyntheticLambda5 implements Runnable {
    public final /* synthetic */ BridgeService f$0;

    public /* synthetic */ BridgeService$$ExternalSyntheticLambda5(BridgeService bridgeService) {
        this.f$0 = bridgeService;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f$0.tick();
    }
}
