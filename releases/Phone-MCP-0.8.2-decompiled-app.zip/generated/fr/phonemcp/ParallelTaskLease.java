package fr.phonemcp;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

/* JADX INFO: loaded from: classes.dex */
final class ParallelTaskLease {
    private final Map<String, Set<Integer>> tasks = new HashMap();

    ParallelTaskLease() {
    }

    static /* synthetic */ Set lambda$observe$0(String str) {
        return new HashSet();
    }

    void observe(String str, int i, int i2, int i3) {
        if (str == null || str.isEmpty() || i < 0 || i3 <= 0 || i2 != i3) {
            return;
        }
        this.tasks.computeIfAbsent(str, new Function() { // from class: fr.phonemcp.ParallelTaskLease$$ExternalSyntheticLambda0
            @Override // java.util.function.Function
            public final Object apply(Object obj) {
                return ParallelTaskLease.lambda$observe$0((String) obj);
            }
        }).add(Integer.valueOf(i));
    }

    boolean owns(String str) {
        return this.tasks.containsKey(str);
    }

    void retain(Set<String> set) {
        this.tasks.keySet().retainAll(set);
    }

    boolean reclaim(String str, int i, int i2, int i3, String[] strArr) {
        if (i3 <= 0 || i2 != 0 || !this.tasks.containsKey(str) || !this.tasks.get(str).contains(Integer.valueOf(i)) || strArr == null) {
            return false;
        }
        for (String str2 : strArr) {
            if (str2 == null || !(str2.equals(str) || str2.startsWith(str + "/"))) {
                return false;
            }
        }
        return true;
    }

    void clear() {
        this.tasks.clear();
    }
}
