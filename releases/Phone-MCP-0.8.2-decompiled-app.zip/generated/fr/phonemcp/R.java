package fr.phonemcp;

/* JADX INFO: loaded from: classes.dex */
public final class R {

    public static final class drawable {
        public static int ic_phone = 0x7f010000;

        private drawable() {
        }
    }

    public static final class string {
        public static int accessibility_description = 0x7f020000;
        public static int all_apps_default = 0x7f020001;
        public static int preview_active = 0x7f020002;
        public static int preview_close = 0x7f020003;
        public static int preview_description = 0x7f020004;
        public static int preview_notification_action = 0x7f020005;
        public static int preview_stopped = 0x7f020006;
        public static int preview_unavailable = 0x7f020007;

        private string() {
        }
    }

    public static final class style {
        public static int AppTheme = 0x7f030000;

        private style() {
        }
    }

    public static final class xml {
        public static int accessibility = 0x7f040000;
        public static int data_extraction_rules = 0x7f040001;

        private xml() {
        }
    }

    private R() {
    }
}
