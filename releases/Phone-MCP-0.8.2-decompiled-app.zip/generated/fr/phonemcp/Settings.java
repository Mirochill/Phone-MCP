package fr.phonemcp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.security.keystore.KeyGenParameterSpec;
import android.util.Base64;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
final class Settings {
    private static final String KEY_ALIAS = "phone-mcp-pairing";
    private final Context context;
    private final SharedPreferences prefs;

    Settings(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = context.getSharedPreferences("settings", 0);
    }

    String endpoint() {
        return this.prefs.getString("endpoint", HttpUrl.FRAGMENT_ENCODE_SET);
    }

    void saveConnection(String str, String str2) throws Exception {
        URI uri = new URI(str.trim());
        if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null || uri.getUserInfo() != null || uri.getQuery() != null || uri.getFragment() != null || (!uri.getPath().isEmpty() && !"/".equals(uri.getPath()))) {
            throw new IllegalArgumentException("Utilisez l’origine HTTPS du serveur, sans chemin ni paramètres.");
        }
        if (!str2.matches("[A-Za-z0-9_-]{32,256}")) {
            throw new IllegalArgumentException("Jeton d’appairage invalide.");
        }
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(1, key());
        this.prefs.edit().putString("endpoint", "https://" + uri.getRawAuthority()).putString("token", Base64.encodeToString(cipher.doFinal(str2.getBytes(StandardCharsets.UTF_8)), 2)).putString("iv", Base64.encodeToString(cipher.getIV(), 2)).apply();
    }

    String token() throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(2, key(), new GCMParameterSpec(128, Base64.decode(this.prefs.getString("iv", HttpUrl.FRAGMENT_ENCODE_SET), 2)));
        return new String(cipher.doFinal(Base64.decode(this.prefs.getString("token", HttpUrl.FRAGMENT_ENCODE_SET), 2)), StandardCharsets.UTF_8);
    }

    private SecretKey key() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (!keyStore.containsAlias(KEY_ALIAS)) {
            KeyGenerator keyGenerator = KeyGenerator.getInstance("AES", "AndroidKeyStore");
            keyGenerator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS, 3).setBlockModes("GCM").setEncryptionPaddings("NoPadding").build());
            return keyGenerator.generateKey();
        }
        return (SecretKey) keyStore.getKey(KEY_ALIAS, null);
    }

    boolean allApps() {
        return this.prefs.getBoolean("policy.v4.allApps", true);
    }

    boolean screenControl() {
        return this.prefs.getBoolean("policy.v4.screenControl", true);
    }

    void screenControl(boolean z) {
        this.prefs.edit().putBoolean("policy.v4.screenControl", z).apply();
    }

    boolean parallel() {
        return this.prefs.getBoolean("parallel.enabled", false);
    }

    void parallel(boolean z) {
        this.prefs.edit().putBoolean("parallel.enabled", z).apply();
    }

    boolean panelOff() {
        return this.prefs.getBoolean("parallel.panelOff", false);
    }

    void panelOff(boolean z) {
        this.prefs.edit().putBoolean("parallel.panelOff", z).apply();
    }

    boolean filesAllowed() {
        return this.prefs.getBoolean("files.enabled", true);
    }

    void filesAllowed(boolean z) {
        this.prefs.edit().putBoolean("files.enabled", z).apply();
    }

    Set<String> availablePackages() {
        Intent intentAddCategory = new Intent("android.intent.action.MAIN").addCategory("android.intent.category.LAUNCHER");
        HashSet hashSet = new HashSet();
        Iterator<ResolveInfo> it = this.context.getPackageManager().queryIntentActivities(intentAddCategory, 0).iterator();
        while (it.hasNext()) {
            String str = it.next().activityInfo.packageName;
            if (AccessPolicy.validPackage(str)) {
                hashSet.add(str);
            }
        }
        return hashSet;
    }

    Set<String> packages() {
        Set<String> setAvailablePackages = availablePackages();
        setAvailablePackages.removeIf(new Predicate() { // from class: fr.phonemcp.Settings$$ExternalSyntheticLambda0
            @Override // java.util.function.Predicate
            public final boolean test(Object obj) {
                return this.f$0.lambda$packages$0((String) obj);
            }
        });
        return setAvailablePackages;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ boolean lambda$packages$0(String str) {
        return !allowed(str, "read");
    }

    boolean allowed(String str, String str2) {
        if (AccessPolicy.validPackage(str) && AccessPolicy.capability(str2)) {
            try {
                this.context.getPackageManager().getApplicationInfo(str, 0);
                return AccessPolicy.allowed(str, str2, true, allApps(), this.prefs.getAll());
            } catch (PackageManager.NameNotFoundException unused) {
            }
        }
        return false;
    }

    void grant(String str, String str2, boolean z) {
        if (!AccessPolicy.validPackage(str) || !AccessPolicy.capability(str2)) {
            throw new IllegalArgumentException("App ou capacité invalide");
        }
        SharedPreferences.Editor editorPutBoolean = this.prefs.edit().putBoolean(AccessPolicy.key(str, str2), z);
        if ("read".equals(str2) && !z) {
            String[] strArr = {"write", "capture", "notifications"};
            for (int i = 0; i < 3; i++) {
                editorPutBoolean.putBoolean(AccessPolicy.key(str, strArr[i]), false);
            }
        }
        editorPutBoolean.apply();
        BridgeService.permissionsChanged();
    }

    void allApps(boolean z) {
        SharedPreferences.Editor editorPutBoolean = this.prefs.edit().putBoolean("policy.v4.allApps", z);
        for (String str : this.prefs.getAll().keySet()) {
            if (str.startsWith("grant.v4.")) {
                editorPutBoolean.remove(str);
            }
        }
        editorPutBoolean.apply();
        BridgeService.permissionsChanged();
    }

    void forget() {
        this.prefs.edit().remove("endpoint").remove("token").remove("iv").apply();
    }
}
