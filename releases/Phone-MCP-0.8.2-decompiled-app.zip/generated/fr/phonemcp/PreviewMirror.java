package fr.phonemcp;

import android.graphics.Rect;
import android.os.SystemClock;
import android.view.SurfaceControl;
import java.lang.reflect.Constructor;
import org.json.JSONArray;

/* JADX INFO: loaded from: classes.dex */
final class PreviewMirror {
    JSONArray capturePackages;
    long deadline;
    private SurfaceControl layer;
    String pkg;
    String viewer;

    PreviewMirror() {
    }

    boolean active() {
        return this.layer != null;
    }

    void attach(int i, SurfaceControl surfaceControl, String str, String str2, JSONArray jSONArray, int i2, int i3) throws Exception {
        if (i <= 0 || surfaceControl == null || !surfaceControl.isValid() || i2 < 1 || i3 < 1 || i2 > 8192 || i3 > 8192) {
            throw new SecurityException("Surface d’aperçu invalide.");
        }
        clear();
        Constructor declaredConstructor = SurfaceControl.class.getDeclaredConstructor(new Class[0]);
        declaredConstructor.setAccessible(true);
        SurfaceControl surfaceControl2 = (SurfaceControl) declaredConstructor.newInstance(new Object[0]);
        try {
            if (!((Boolean) Class.forName("android.view.IWindowManager").getMethod("mirrorDisplay", Integer.TYPE, SurfaceControl.class).invoke(Class.forName("android.view.WindowManagerGlobal").getMethod("getWindowManagerService", new Class[0]).invoke(null, new Object[0]), Integer.valueOf(i), surfaceControl2)).booleanValue() || !surfaceControl2.isValid()) {
                throw new IllegalStateException("Miroir Android indisponible.");
            }
            float f = i2;
            float f2 = i3;
            float fMin = Math.min(f / 720.0f, f2 / 1280.0f);
            SurfaceControl.Transaction transaction = new SurfaceControl.Transaction();
            try {
                SurfaceControl.Transaction.class.getMethod("setDropInputMode", SurfaceControl.class, Integer.TYPE).invoke(transaction, surfaceControl2, 1);
                transaction.reparent(surfaceControl2, surfaceControl).setLayer(surfaceControl2, 1).setCrop(surfaceControl2, new Rect(0, 0, 720, 1280)).setScale(surfaceControl2, fMin, fMin).setPosition(surfaceControl2, (f - (720.0f * fMin)) / 2.0f, (f2 - (fMin * 1280.0f)) / 2.0f).setVisibility(surfaceControl2, true).apply();
                transaction.close();
                this.layer = surfaceControl2;
                this.viewer = str;
                this.pkg = str2;
                this.capturePackages = jSONArray;
                this.deadline = SystemClock.elapsedRealtime() + 2500;
            } catch (Throwable th) {
                try {
                    transaction.close();
                    throw th;
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                    throw th;
                }
            }
        } catch (Exception e) {
            surfaceControl2.release();
            throw e;
        }
    }

    boolean matches(String str) {
        return (this.layer == null || str == null || !str.equals(this.viewer)) ? false : true;
    }

    void visible(boolean z) {
        SurfaceControl surfaceControl = this.layer;
        if (surfaceControl == null || !surfaceControl.isValid()) {
            return;
        }
        SurfaceControl.Transaction transaction = new SurfaceControl.Transaction();
        try {
            transaction.setVisibility(this.layer, z).apply();
            transaction.close();
        } catch (Throwable th) {
            try {
                transaction.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    void clear() {
        SurfaceControl surfaceControl = this.layer;
        this.layer = null;
        this.viewer = null;
        this.pkg = null;
        this.capturePackages = null;
        this.deadline = 0L;
        if (surfaceControl != null) {
            try {
                if (surfaceControl.isValid()) {
                    SurfaceControl.Transaction transaction = new SurfaceControl.Transaction();
                    try {
                        transaction.setVisibility(surfaceControl, false).reparent(surfaceControl, null).apply();
                        transaction.close();
                    } catch (Throwable th) {
                        try {
                            transaction.close();
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                        throw th;
                    }
                }
                surfaceControl.release();
            } catch (Throwable th3) {
                surfaceControl.release();
                throw th3;
            }
        }
    }
}
