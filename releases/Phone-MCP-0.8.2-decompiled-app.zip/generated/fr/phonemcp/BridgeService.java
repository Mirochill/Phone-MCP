package fr.phonemcp;

import android.app.ActivityOptions;
import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.view.SurfaceControl;
import android.widget.Toast;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public final class BridgeService extends Service {
    private static volatile String connection = "Arrêté";
    private static volatile BridgeService instance;
    private static volatile boolean parallel;
    private static volatile boolean screenControl;
    private static volatile long sessionEnd;
    private int attempt;
    private BackgroundClient background;
    private boolean busy;
    private int epoch;
    private WebSocket socket;
    private long wakeLeaseAt;
    private PowerManager.WakeLock wakeLock;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final OkHttpClient client = new OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build();

    static /* synthetic */ void lambda$permissionsChanged$0(JSONObject jSONObject, String str) {
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    public static boolean active() {
        return SessionPolicy.active(instance != null, SystemClock.elapsedRealtime(), sessionEnd);
    }

    public static boolean unlimited() {
        return active() && SessionPolicy.unlimited(sessionEnd);
    }

    public static boolean parallelEnabled() {
        return active() && parallel;
    }

    static JSONObject backgroundState() {
        return (instance == null || instance.background == null) ? new JSONObject() : instance.background.state();
    }

    static boolean canPreview(String str) {
        BridgeService bridgeService = instance;
        if (parallelEnabled() && bridgeService != null && BackgroundClient.permitted() && bridgeService.background.controls(str)) {
            Settings settings = new Settings(bridgeService);
            if (settings.allowed(str, "read") && settings.allowed(str, "capture")) {
                return true;
            }
        }
        return false;
    }

    static void permissionsChanged() {
        BridgeService bridgeService = instance;
        if (bridgeService != null && active() && bridgeService.background.filesReady()) {
            bridgeService.background.refresh(new PhoneAccessibilityService.Reply() { // from class: fr.phonemcp.BridgeService$$ExternalSyntheticLambda3
                @Override // fr.phonemcp.PhoneAccessibilityService.Reply
                public final void done(JSONObject jSONObject, String str) {
                    BridgeService.lambda$permissionsChanged$0(jSONObject, str);
                }
            });
        }
    }

    static void previewSurface(String str, String str2, SurfaceControl surfaceControl, int i, int i2, PhoneAccessibilityService.Reply reply) {
        BridgeService bridgeService = instance;
        if (bridgeService == null || !canPreview(str)) {
            reply.done(null, "Aperçu arrêté.");
        } else {
            bridgeService.background.previewSurface(str, str2, surfaceControl, i, i2, reply);
        }
    }

    static void detachPreview(String str) {
        BridgeService bridgeService = instance;
        if (bridgeService != null) {
            bridgeService.background.detachPreview(str);
        }
    }

    static void previewFrame(String str, PhoneAccessibilityService.Reply reply) {
        BridgeService bridgeService = instance;
        if (!canPreview(str) || bridgeService == null) {
            reply.done(null, "Aperçu arrêté.");
        } else {
            bridgeService.background.previewFrame(str, reply);
        }
    }

    static void showPreview(String str) {
        Context context;
        BridgeService bridgeService = instance;
        if (bridgeService == null || !canPreview(str) || !((PowerManager) bridgeService.getSystemService(PowerManager.class)).isInteractive() || ((KeyguardManager) bridgeService.getSystemService(KeyguardManager.class)).isKeyguardLocked()) {
            return;
        }
        Intent intentAddFlags = new Intent(bridgeService, (Class<?>) PreviewActivity.class).putExtra("packageName", str).addFlags(872415232);
        if (PhoneAccessibilityService.instance != null) {
            context = bridgeService;
            context = PhoneAccessibilityService.instance;
        }
        context = bridgeService;
        try {
            context.startActivity(intentAddFlags, ActivityOptions.makeBasic().setLaunchDisplayId(0).toBundle());
        } catch (RuntimeException unused) {
            Audit.add("ouverture aperçu", false);
        }
    }

    public static boolean screenControlEnabled() {
        return active() && screenControl;
    }

    static boolean filesOperation(String str) {
        return Arrays.asList("files_list", "file_job", "download_file", "install_apk").contains(str);
    }

    static void files(String str, JSONObject jSONObject, final PhoneAccessibilityService.Reply reply) {
        final BridgeService bridgeService = instance;
        if (bridgeService == null || !active()) {
            reply.done(null, "Démarrez une session pour accéder aux fichiers.");
        } else {
            bridgeService.background.executeFiles(str, jSONObject, new PhoneAccessibilityService.Reply() { // from class: fr.phonemcp.BridgeService$$ExternalSyntheticLambda6
                @Override // fr.phonemcp.PhoneAccessibilityService.Reply
                public final void done(JSONObject jSONObject2, String str2) {
                    BridgeService.lambda$files$1(this.f$0, reply, jSONObject2, str2);
                }
            });
        }
    }

    static /* synthetic */ void lambda$files$1(BridgeService bridgeService, PhoneAccessibilityService.Reply reply, JSONObject jSONObject, String str) {
        bridgeService.updateWakeLease();
        reply.done(jSONObject, str);
    }

    static void revokeFiles() {
        final BridgeService bridgeService = instance;
        if (bridgeService == null || !bridgeService.background.filesReady()) {
            return;
        }
        bridgeService.background.executeFiles("files_cancel_all", new JSONObject(), new PhoneAccessibilityService.Reply() { // from class: fr.phonemcp.BridgeService$$ExternalSyntheticLambda10
            @Override // fr.phonemcp.PhoneAccessibilityService.Reply
            public final void done(JSONObject jSONObject, String str) {
                this.f$0.updateWakeLease();
            }
        });
    }

    public static String status() {
        if (active()) {
            return connection + (unlimited() ? " · sans limite de durée" : " · " + Math.max(1L, (sessionEnd - SystemClock.elapsedRealtime()) / 60000) + " min restantes");
        }
        return "Session arrêtée";
    }

    public static void stop(Context context) {
        sessionEnd = 0L;
        screenControl = false;
        parallel = false;
        if (instance != null && instance.background != null) {
            instance.background.close();
        }
        PhoneAccessibilityService.invalidate();
        PhoneNotificationService.invalidate();
        context.stopService(new Intent(context, (Class<?>) BridgeService.class));
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        instance = this;
        this.background = new BackgroundClient(this);
        PowerManager.WakeLock wakeLockNewWakeLock = ((PowerManager) getSystemService(PowerManager.class)).newWakeLock(1, "phonemcp:session");
        this.wakeLock = wakeLockNewWakeLock;
        wakeLockNewWakeLock.setReferenceCounted(false);
        ((NotificationManager) getSystemService(NotificationManager.class)).createNotificationChannel(new NotificationChannel("control", "Contrôle MCP actif", 2));
        startForeground(1, notification("Connexion en cours"));
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stop(this);
            return 2;
        }
        if (intent != null && "RESTORE_PANEL".equals(intent.getAction())) {
            if (active() && parallel) {
                this.background.restorePanel(new PhoneAccessibilityService.Reply() { // from class: fr.phonemcp.BridgeService$$ExternalSyntheticLambda0
                    @Override // fr.phonemcp.PhoneAccessibilityService.Reply
                    public final void done(JSONObject jSONObject, String str) {
                        this.f$0.lambda$onStartCommand$3(jSONObject, str);
                    }
                });
            } else if (!active()) {
                stopSelf();
            }
            return 2;
        }
        if (intent == null) {
            stopSelf();
            return 2;
        }
        try {
            sessionEnd = SessionPolicy.deadline(SystemClock.elapsedRealtime(), intent.getIntExtra("minutes", 30));
            screenControl = intent.getBooleanExtra("screenControl", false);
            parallel = intent.getBooleanExtra("parallel", false);
            if (parallel) {
                screenControl = false;
            }
            if (this.wakeLock.isHeld()) {
                this.wakeLock.release();
            }
            this.wakeLeaseAt = 0L;
            if (parallel) {
                this.wakeLock.acquire(30000L);
            }
            this.main.removeCallbacksAndMessages(null);
            this.epoch++;
            this.busy = false;
            PhoneAccessibilityService.invalidate();
            WebSocket webSocket = this.socket;
            if (webSocket != null) {
                webSocket.cancel();
            }
            if (parallel || (BackgroundClient.permitted() && new Settings(this).filesAllowed())) {
                connection = "Préparation de Shizuku";
                final int i3 = this.epoch;
                this.background.start(sessionEnd, parallel && intent.getBooleanExtra("panelOff", false), parallel, new PhoneAccessibilityService.Reply() { // from class: fr.phonemcp.BridgeService$$ExternalSyntheticLambda4
                    @Override // fr.phonemcp.PhoneAccessibilityService.Reply
                    public final void done(JSONObject jSONObject, String str) {
                        this.f$0.lambda$onStartCommand$4(i3, jSONObject, str);
                    }
                });
            } else {
                this.background.close();
            }
            lambda$reconnect$6(this.epoch);
            this.main.postDelayed(new BridgeService$$ExternalSyntheticLambda5(this), 1000L);
            return 2;
        } catch (ArithmeticException | IllegalArgumentException unused) {
            Audit.add("durée de session", false);
            stop(this);
            return 2;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onStartCommand$3(JSONObject jSONObject, String str) {
        if (str != null) {
            Toast.makeText(this, str, 1).show();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onStartCommand$4(int i, JSONObject jSONObject, String str) {
        if (i == this.epoch && active()) {
            if (str != null) {
                Toast.makeText(this, str, 1).show();
                Audit.add("service Shizuku", false);
            }
            updateWakeLease();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void tick() {
        if (!active() || ((!parallel && PhoneAccessibilityService.instance == null && PhoneNotificationService.instance == null) || !((NotificationManager) getSystemService(NotificationManager.class)).areNotificationsEnabled())) {
            stop(this);
            return;
        }
        ((NotificationManager) getSystemService(NotificationManager.class)).notify(1, notification(status()));
        if (parallel || this.background.filesReady()) {
            if (BackgroundClient.permitted()) {
                this.background.refresh(new PhoneAccessibilityService.Reply() { // from class: fr.phonemcp.BridgeService$$ExternalSyntheticLambda11
                    @Override // fr.phonemcp.PhoneAccessibilityService.Reply
                    public final void done(JSONObject jSONObject, String str) {
                        this.f$0.lambda$tick$5(jSONObject, str);
                    }
                });
            } else {
                BackgroundClient.lastError = BackgroundClient.permissionStatus();
                this.background.close();
                updateWakeLease();
            }
        }
        this.main.postDelayed(new BridgeService$$ExternalSyntheticLambda5(this), 5000L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$tick$5(JSONObject jSONObject, String str) {
        updateWakeLease();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateWakeLease() {
        if (!active() || ((!parallel || !this.background.ready()) && !this.background.fileJobActive())) {
            if (this.wakeLock.isHeld()) {
                this.wakeLock.release();
            }
            this.wakeLeaseAt = 0L;
            return;
        }
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        if (this.wakeLeaseAt == 0 || !this.wakeLock.isHeld() || jElapsedRealtime - this.wakeLeaseAt >= 30000) {
            this.wakeLock.acquire(90000L);
            this.wakeLeaseAt = jElapsedRealtime;
        }
    }

    private Notification notification(String str) {
        Notification.Builder builderAddAction = new Notification.Builder(this, "control").setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("Phone MCP · contrôle autorisé").setContentText(str).setOngoing(true).setContentIntent(PendingIntent.getActivity(this, 1, new Intent(this, (Class<?>) MainActivity.class), 201326592)).addAction(new Notification.Action.Builder((Icon) null, "Arrêter la session", PendingIntent.getService(this, 2, new Intent(this, (Class<?>) BridgeService.class).setAction("STOP"), 201326592)).build());
        if (parallel) {
            builderAddAction.addAction(new Notification.Action.Builder((Icon) null, "Rallumer la dalle", PendingIntent.getService(this, 3, new Intent(this, (Class<?>) BridgeService.class).setAction("RESTORE_PANEL"), 201326592)).build());
            String strPreviewPackage = this.background.previewPackage();
            if (strPreviewPackage != null && canPreview(strPreviewPackage)) {
                builderAddAction.addAction(new Notification.Action.Builder((Icon) null, getString(R.string.preview_notification_action), PendingIntent.getActivity(this, 4, new Intent(this, (Class<?>) PreviewActivity.class).putExtra("packageName", strPreviewPackage).addFlags(335544320), 201326592)).build());
            }
        }
        return builderAddAction.build();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: connect, reason: merged with bridge method [inline-methods] */
    public void lambda$reconnect$6(int i) {
        if (active() && i == this.epoch) {
            try {
                Settings settings = new Settings(this);
                this.socket = this.client.newWebSocket(new Request.Builder().url("wss://" + settings.endpoint().substring("https://".length()) + "/device").header("Authorization", "Bearer " + settings.token()).build(), new AnonymousClass1(i));
            } catch (Exception unused) {
                Audit.add("appairage", false);
                stop(this);
            }
        }
    }

    /* JADX INFO: renamed from: fr.phonemcp.BridgeService$1, reason: invalid class name */
    class AnonymousClass1 extends WebSocketListener {
        final /* synthetic */ int val$expected;

        AnonymousClass1(int i) {
            this.val$expected = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$onOpen$0(int i, WebSocket webSocket) {
            if (i != BridgeService.this.epoch || !BridgeService.active()) {
                webSocket.cancel();
            } else {
                BridgeService.this.attempt = 0;
                BridgeService.connection = "Connecté au MCP";
            }
        }

        @Override // okhttp3.WebSocketListener
        public void onOpen(final WebSocket webSocket, Response response) {
            Handler handler = BridgeService.this.main;
            final int i = this.val$expected;
            handler.post(new Runnable() { // from class: fr.phonemcp.BridgeService$1$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$onOpen$0(i, webSocket);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$onMessage$1(WebSocket webSocket, String str, int i) {
            BridgeService.this.command(webSocket, str, i);
        }

        @Override // okhttp3.WebSocketListener
        public void onMessage(final WebSocket webSocket, final String str) {
            Handler handler = BridgeService.this.main;
            final int i = this.val$expected;
            handler.post(new Runnable() { // from class: fr.phonemcp.BridgeService$1$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$onMessage$1(webSocket, str, i);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$onClosed$2(int i) {
            BridgeService.this.reconnect(i);
        }

        @Override // okhttp3.WebSocketListener
        public void onClosed(WebSocket webSocket, int i, String str) {
            Handler handler = BridgeService.this.main;
            final int i2 = this.val$expected;
            handler.post(new Runnable() { // from class: fr.phonemcp.BridgeService$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$onClosed$2(i2);
                }
            });
        }

        @Override // okhttp3.WebSocketListener
        public void onFailure(WebSocket webSocket, Throwable th, final Response response) {
            Handler handler = BridgeService.this.main;
            final int i = this.val$expected;
            handler.post(new Runnable() { // from class: fr.phonemcp.BridgeService$1$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$onFailure$3(i, response);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$onFailure$3(int i, Response response) {
            if (i == BridgeService.this.epoch && BridgeService.active()) {
                if (response != null && (response.code() == 401 || response.code() == 409)) {
                    BridgeService.connection = "Appairage refusé ou téléphone déjà connecté";
                    Audit.add("connexion", false);
                    BridgeService.stop(BridgeService.this);
                    return;
                }
                BridgeService.this.reconnect(i);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void reconnect(final int i) {
        if (active() && i == this.epoch) {
            this.busy = false;
            connection = "Hors ligne · reconnexion";
            int i2 = this.attempt;
            this.attempt = i2 + 1;
            this.main.postDelayed(new Runnable() { // from class: fr.phonemcp.BridgeService$$ExternalSyntheticLambda9
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$reconnect$6(i);
                }
            }, Math.min(30000L, 1000 << Math.min(i2, 5)));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void command(final WebSocket webSocket, String str, final int i) {
        BridgeService bridgeService = this;
        if (i != bridgeService.epoch || !active() || webSocket != bridgeService.socket || str.length() > 20000) {
            return;
        }
        try {
            JSONObject jSONObject = new JSONObject(str);
            final String string = jSONObject.getString("id");
            final String string2 = jSONObject.getString("op");
            final long j = jSONObject.getLong("expiresAt");
            if (string.length() <= 80 && string2.length() <= 40) {
                if (j >= System.currentTimeMillis() && j <= System.currentTimeMillis() + 30000) {
                    try {
                        if (bridgeService.busy) {
                            bridgeService.respond(webSocket, string, string2, null, "Une commande est déjà en cours", i);
                            return;
                        }
                        PhoneAccessibilityService phoneAccessibilityService = PhoneAccessibilityService.instance;
                        boolean z = "notifications".equals(string2) || "reply_notification".equals(string2);
                        boolean zFilesOperation = filesOperation(string2);
                        if (z && PhoneNotificationService.instance == null) {
                            respond(webSocket, string, string2, null, "Accès aux notifications désactivé", i);
                            return;
                        }
                        if (!z && !zFilesOperation && !parallel && phoneAccessibilityService == null && !"status".equals(string2) && !"stop".equals(string2)) {
                            respond(webSocket, string, string2, null, "Accessibilité désactivée", i);
                            return;
                        }
                        try {
                            this.busy = true;
                            try {
                                final PhoneAccessibilityService.Reply reply = new PhoneAccessibilityService.Reply() { // from class: fr.phonemcp.BridgeService$$ExternalSyntheticLambda12
                                    @Override // fr.phonemcp.PhoneAccessibilityService.Reply
                                    public final void done(JSONObject jSONObject2, String str2) {
                                        this.f$0.lambda$command$8(i, j, webSocket, string, string2, jSONObject2, str2);
                                    }
                                };
                                if ("control_mode".equals(string2)) {
                                    controlMode(jSONObject.optJSONObject("args"), reply);
                                    return;
                                }
                                if (zFilesOperation) {
                                    files(string2, jSONObject.optJSONObject("args"), reply);
                                    return;
                                }
                                if (z) {
                                    PhoneNotificationService.instance.execute(string2, jSONObject.optJSONObject("args"), reply);
                                    return;
                                }
                                if ("status".equals(string2)) {
                                    if (!parallel && !this.background.filesReady()) {
                                        reply.done(PhoneAccessibilityService.statusResult(this), null);
                                        return;
                                    }
                                    this.background.refresh(new PhoneAccessibilityService.Reply() { // from class: fr.phonemcp.BridgeService$$ExternalSyntheticLambda1
                                        @Override // fr.phonemcp.PhoneAccessibilityService.Reply
                                        public final void done(JSONObject jSONObject2, String str2) {
                                            this.f$0.lambda$command$9(reply, jSONObject2, str2);
                                        }
                                    });
                                    return;
                                }
                                if ("stop".equals(string2)) {
                                    reply.done(new JSONObject().put("stopped", true), null);
                                    this.main.postDelayed(new Runnable() { // from class: fr.phonemcp.BridgeService$$ExternalSyntheticLambda2
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            this.f$0.lambda$command$10();
                                        }
                                    }, 150L);
                                    return;
                                } else if (parallel) {
                                    this.background.execute(string2, jSONObject.optJSONObject("args"), reply);
                                    return;
                                } else {
                                    phoneAccessibilityService.execute(string2, jSONObject.optJSONObject("args"), reply);
                                    return;
                                }
                            } catch (Exception unused) {
                                bridgeService = this;
                                bridgeService.busy = false;
                                Audit.add("commande invalide", false);
                                return;
                            }
                        } catch (Exception unused2) {
                            bridgeService = this;
                        }
                    } catch (Exception unused3) {
                        bridgeService = this;
                    }
                }
                bridgeService.respond(webSocket, string, string2, null, "Commande expirée", i);
            }
        } catch (Exception unused4) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$command$8(final int i, final long j, final WebSocket webSocket, final String str, final String str2, final JSONObject jSONObject, final String str3) {
        this.main.post(new Runnable() { // from class: fr.phonemcp.BridgeService$$ExternalSyntheticLambda7
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$command$7(i, j, webSocket, str, str2, jSONObject, str3);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$command$7(int i, long j, WebSocket webSocket, String str, String str2, JSONObject jSONObject, String str3) {
        if (i != this.epoch) {
            return;
        }
        this.busy = false;
        if (j < System.currentTimeMillis()) {
            respond(webSocket, str, str2, null, "Commande expirée", i);
        } else {
            respond(webSocket, str, str2, jSONObject, str3, i);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$command$9(PhoneAccessibilityService.Reply reply, JSONObject jSONObject, String str) {
        try {
            reply.done(PhoneAccessibilityService.statusResult(this), null);
        } catch (Exception e) {
            reply.done(null, e.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$command$10() {
        stop(this);
    }

    private void controlMode(JSONObject jSONObject, final PhoneAccessibilityService.Reply reply) {
        try {
            if (!active() || (!parallel && !screenControl)) {
                throw new SecurityException("Une session de contrôle d’écran doit déjà être autorisée. Le mode notifications ne peut pas accorder cet accès.");
            }
            String string = jSONObject.getString("mode");
            final boolean zEquals = "parallel".equals(string);
            if (!zEquals && !"foreground".equals(string)) {
                throw new IllegalArgumentException("Mode inconnu.");
            }
            if (!((PowerManager) getSystemService(PowerManager.class)).isInteractive() || ((KeyguardManager) getSystemService(KeyguardManager.class)).isKeyguardLocked()) {
                throw new SecurityException("Déverrouillez le téléphone avant de changer d’affichage.");
            }
            if (!zEquals && PhoneAccessibilityService.instance == null) {
                throw new SecurityException("Activez l’accessibilité avant de choisir l’écran physique.");
            }
            final int i = this.epoch;
            PhoneAccessibilityService.Reply reply2 = new PhoneAccessibilityService.Reply() { // from class: fr.phonemcp.BridgeService$$ExternalSyntheticLambda8
                @Override // fr.phonemcp.PhoneAccessibilityService.Reply
                public final void done(JSONObject jSONObject2, String str) {
                    this.f$0.lambda$controlMode$11(i, reply, zEquals, jSONObject2, str);
                }
            };
            if (this.background.filesReady() || parallel) {
                this.background.controlMode(string, zEquals && jSONObject.optBoolean("panelOff"), sessionEnd, reply2);
            } else {
                if (zEquals) {
                    throw new IllegalStateException("Démarrez une session avec Shizuku avant de choisir l’écran séparé.");
                }
                reply2.done(new JSONObject(), null);
            }
        } catch (Exception e) {
            reply.done(null, e.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$controlMode$11(int i, PhoneAccessibilityService.Reply reply, boolean z, JSONObject jSONObject, String str) {
        if (i == this.epoch && active()) {
            if (str != null) {
                reply.done(null, str);
                return;
            }
            if (z && !jSONObject.optBoolean("ready")) {
                reply.done(null, "L’affichage séparé n’est pas prêt. Le mode n’a pas été changé.");
                return;
            }
            parallel = z;
            screenControl = !z;
            PhoneAccessibilityService.invalidate();
            updateWakeLease();
            Settings settings = new Settings(this);
            settings.parallel(z);
            settings.screenControl(!z);
            try {
                reply.done(PhoneAccessibilityService.statusResult(this).put("modeChanged", true), null);
            } catch (Exception e) {
                reply.done(null, e.getMessage());
            }
        }
    }

    private void respond(WebSocket webSocket, String str, String str2, JSONObject jSONObject, String str3, int i) {
        if (active() && i == this.epoch) {
            try {
                boolean z = true;
                JSONObject jSONObjectPut = new JSONObject().put("id", str).put("ok", str3 == null);
                if (str3 != null) {
                    jSONObjectPut.put("error", str3);
                } else {
                    jSONObjectPut.put("result", jSONObject);
                }
                webSocket.send(jSONObjectPut.toString());
                if (str3 != null) {
                    z = false;
                }
                Audit.add(str2, z);
            } catch (Exception unused) {
                Audit.add(str2, false);
            }
        }
    }

    @Override // android.app.Service
    public void onDestroy() {
        sessionEnd = 0L;
        screenControl = false;
        parallel = false;
        BackgroundClient backgroundClient = this.background;
        if (backgroundClient != null) {
            backgroundClient.destroy();
        }
        this.epoch++;
        this.main.removeCallbacksAndMessages(null);
        PowerManager.WakeLock wakeLock = this.wakeLock;
        if (wakeLock != null && wakeLock.isHeld()) {
            this.wakeLock.release();
        }
        WebSocket webSocket = this.socket;
        if (webSocket != null) {
            webSocket.cancel();
        }
        this.client.dispatcher().executorService().shutdown();
        instance = null;
        connection = "Arrêté";
        PhoneAccessibilityService.invalidate();
        PhoneNotificationService.invalidate();
        stopForeground(1);
        super.onDestroy();
    }
}
