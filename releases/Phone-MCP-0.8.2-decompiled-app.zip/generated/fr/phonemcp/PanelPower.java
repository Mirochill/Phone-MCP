package fr.phonemcp;

import android.os.IBinder;
import android.os.Process;
import android.os.SystemClock;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: classes.dex */
final class PanelPower {
    private boolean changed;
    private final Class<?> physical;
    private final Object power;
    private final Class<?> surface;

    PanelPower() throws Exception {
        Class<?> cls = Class.forName("android.view.SurfaceControl");
        this.surface = cls;
        if (Process.myUid() != 2000) {
            throw new SecurityException("Alimentation réservée au service Shizuku ADB.");
        }
        try {
            cls.getMethod("getPhysicalDisplayIds", new Class[0]);
        } catch (NoSuchMethodException unused) {
            cls = ((ClassLoader) Class.forName("com.android.internal.os.ClassLoaderFactory").getDeclaredMethod("createClassLoader", String.class, String.class, String.class, ClassLoader.class, Integer.TYPE, Boolean.TYPE, String.class).invoke(null, System.getenv("SYSTEMSERVERCLASSPATH"), null, null, ClassLoader.getSystemClassLoader(), 0, true, null)).loadClass("com.android.server.display.DisplayControl");
            Method declaredMethod = Runtime.class.getDeclaredMethod("loadLibrary0", Class.class, String.class);
            declaredMethod.setAccessible(true);
            declaredMethod.invoke(Runtime.getRuntime(), cls, "android_servers");
        }
        this.physical = cls;
        this.power = Class.forName("android.os.IPowerManager$Stub").getMethod("asInterface", IBinder.class).invoke(null, (IBinder) Class.forName("android.os.ServiceManager").getMethod("getService", String.class).invoke(null, "power"));
    }

    void keepActive(int i) throws Exception {
        this.power.getClass().getMethod("userActivity", Integer.TYPE, Long.TYPE, Integer.TYPE, Integer.TYPE).invoke(this.power, Integer.valueOf(i), Long.valueOf(SystemClock.uptimeMillis()), 0, 0);
    }

    void wakeVirtual(int i) throws Exception {
        if (i <= 0) {
            throw new SecurityException("Réveil de l’écran principal interdit.");
        }
        this.power.getClass().getMethod("wakeUpWithDisplayId", Long.TYPE, Integer.TYPE, String.class, String.class, Integer.TYPE).invoke(this.power, Long.valueOf(SystemClock.uptimeMillis()), 2, "PhoneMCP:virtual", "com.android.shell", Integer.valueOf(i));
    }

    void off() throws Exception {
        this.changed = true;
        setPower(0);
    }

    void restore() throws Exception {
        if (this.changed) {
            setPower(2);
            this.changed = false;
        }
    }

    private void setPower(int i) throws Exception {
        long[] jArr = (long[]) this.physical.getMethod("getPhysicalDisplayIds", new Class[0]).invoke(null, new Object[0]);
        if (jArr == null || jArr.length == 0) {
            throw new IllegalStateException("Aucune dalle physique disponible.");
        }
        Exception e = null;
        for (long j : jArr) {
            try {
                IBinder iBinder = (IBinder) this.physical.getMethod("getPhysicalDisplayToken", Long.TYPE).invoke(null, Long.valueOf(j));
                if (iBinder == null) {
                    throw new IllegalStateException("Dalle physique indisponible.");
                }
                this.surface.getMethod("setDisplayPowerMode", IBinder.class, Integer.TYPE).invoke(null, iBinder, Integer.valueOf(i));
            } catch (Exception e2) {
                e = e2;
            }
        }
        if (e != null) {
            throw e;
        }
    }
}
