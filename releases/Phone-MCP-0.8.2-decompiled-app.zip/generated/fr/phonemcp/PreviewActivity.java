package fr.phonemcp;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import java.util.UUID;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public final class PreviewActivity extends Activity implements SurfaceHolder.Callback {
    private boolean attaching;
    private int epoch;
    private boolean fallback;
    private boolean hardware;
    private ImageView image;
    private String pkg;
    private boolean resumed;
    private TextView status;
    private SurfaceView surface;
    private String viewer;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable refresh = new AnonymousClass1();

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().addFlags(8320);
        if (getDisplay() == null || getDisplay().getDisplayId() != 0) {
            finish();
            return;
        }
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setBackgroundColor(-16777216);
        linearLayout.setFitsSystemWindows(true);
        TextView textView = new TextView(this);
        this.status = textView;
        textView.setTextColor(-1);
        this.status.setPadding(dp(16), dp(12), dp(16), dp(12));
        linearLayout.addView(this.status);
        FrameLayout frameLayout = new FrameLayout(this);
        linearLayout.addView(frameLayout, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        SurfaceView surfaceView = new SurfaceView(this);
        this.surface = surfaceView;
        surfaceView.setSecure(true);
        this.surface.setClickable(false);
        this.surface.setFocusable(false);
        this.surface.setContentDescription(getString(R.string.preview_description));
        this.surface.getHolder().addCallback(this);
        frameLayout.addView(this.surface, new FrameLayout.LayoutParams(-1, -1));
        ImageView imageView = new ImageView(this);
        this.image = imageView;
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        this.image.setContentDescription(getString(R.string.preview_description));
        this.image.setClickable(false);
        this.image.setFocusable(false);
        this.image.setVisibility(8);
        frameLayout.addView(this.image, new FrameLayout.LayoutParams(-1, -1));
        Button button = new Button(this);
        button.setText(R.string.preview_close);
        button.setOnClickListener(new View.OnClickListener() { // from class: fr.phonemcp.PreviewActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.lambda$onCreate$0(view);
            }
        });
        linearLayout.addView(button, new LinearLayout.LayoutParams(-1, -2));
        setContentView(linearLayout);
        select(getIntent());
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(0, new OnBackInvokedCallback() { // from class: fr.phonemcp.PreviewActivity$$ExternalSyntheticLambda3
                @Override // android.window.OnBackInvokedCallback
                public final void onBackInvoked() {
                    this.f$0.closePreview();
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$0(View view) {
        closePreview();
    }

    private int dp(int i) {
        return Math.round(i * getResources().getDisplayMetrics().density);
    }

    private void select(Intent intent) {
        stopPreview();
        String stringExtra = intent.getStringExtra("packageName");
        this.pkg = stringExtra;
        this.status.setText(BridgeService.canPreview(stringExtra) ? R.string.preview_active : R.string.preview_stopped);
    }

    @Override // android.app.Activity
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        select(intent);
        if (this.resumed) {
            startSurface();
        }
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        this.resumed = true;
        SurfaceView surfaceView = this.surface;
        if (surfaceView != null) {
            surfaceView.post(new Runnable() { // from class: fr.phonemcp.PreviewActivity$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.startSurface();
                }
            });
        }
    }

    @Override // android.app.Activity
    protected void onPause() {
        this.resumed = false;
        stopPreview();
        super.onPause();
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        this.resumed = false;
        stopPreview();
        super.onDestroy();
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        startSurface();
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
        stopPreview();
        if (this.resumed) {
            startSurface();
        }
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        stopPreview();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void stopPreview() {
        this.epoch++;
        this.main.removeCallbacks(this.refresh);
        String str = this.viewer;
        this.viewer = null;
        this.attaching = false;
        this.hardware = false;
        this.fallback = false;
        if (str != null) {
            BridgeService.detachPreview(str);
        }
        ImageView imageView = this.image;
        if (imageView != null) {
            imageView.setImageDrawable(null);
            this.image.setVisibility(8);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startSurface() {
        if (!this.resumed || this.attaching || this.hardware || this.fallback || this.surface.getWidth() < 1 || this.surface.getHeight() < 1 || !this.surface.getHolder().getSurface().isValid()) {
            return;
        }
        if (!BridgeService.canPreview(this.pkg)) {
            this.status.setText(R.string.preview_stopped);
            return;
        }
        final int i = this.epoch;
        final String string = UUID.randomUUID().toString();
        this.viewer = string;
        this.attaching = true;
        BridgeService.previewSurface(this.pkg, string, this.surface.getSurfaceControl(), this.surface.getWidth(), this.surface.getHeight(), new PhoneAccessibilityService.Reply() { // from class: fr.phonemcp.PreviewActivity$$ExternalSyntheticLambda0
            @Override // fr.phonemcp.PhoneAccessibilityService.Reply
            public final void done(JSONObject jSONObject, String str) {
                this.f$0.lambda$startSurface$1(i, string, jSONObject, str);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$startSurface$1(int i, String str, JSONObject jSONObject, String str2) {
        if (!this.resumed || i != this.epoch) {
            BridgeService.detachPreview(str);
            return;
        }
        this.attaching = false;
        boolean z = str2 == null && jSONObject != null && jSONObject.optBoolean("active");
        this.hardware = z;
        this.fallback = !z;
        if (!z) {
            this.image.setVisibility(0);
            BridgeService.detachPreview(str);
            this.viewer = null;
        }
        this.status.setText(this.hardware ? R.string.preview_active : R.string.preview_unavailable);
        this.main.post(this.refresh);
    }

    /* JADX INFO: renamed from: fr.phonemcp.PreviewActivity$1, reason: invalid class name */
    class AnonymousClass1 implements Runnable {
        AnonymousClass1() {
        }

        @Override // java.lang.Runnable
        public void run() {
            if (!PreviewActivity.this.resumed || PreviewActivity.this.isFinishing()) {
                return;
            }
            if (!BridgeService.canPreview(PreviewActivity.this.pkg)) {
                PreviewActivity.this.stopPreview();
                PreviewActivity.this.status.setText(R.string.preview_stopped);
                return;
            }
            final int i = PreviewActivity.this.epoch;
            if (PreviewActivity.this.hardware) {
                BridgeService.previewSurface(PreviewActivity.this.pkg, PreviewActivity.this.viewer, null, 0, 0, new PhoneAccessibilityService.Reply() { // from class: fr.phonemcp.PreviewActivity$1$$ExternalSyntheticLambda0
                    @Override // fr.phonemcp.PhoneAccessibilityService.Reply
                    public final void done(JSONObject jSONObject, String str) {
                        this.f$0.lambda$run$0(i, jSONObject, str);
                    }
                });
            } else if (PreviewActivity.this.fallback) {
                BridgeService.previewFrame(PreviewActivity.this.pkg, new PhoneAccessibilityService.Reply() { // from class: fr.phonemcp.PreviewActivity$1$$ExternalSyntheticLambda1
                    @Override // fr.phonemcp.PhoneAccessibilityService.Reply
                    public final void done(JSONObject jSONObject, String str) {
                        this.f$0.lambda$run$1(i, jSONObject, str);
                    }
                });
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$run$0(int i, JSONObject jSONObject, String str) {
            if (PreviewActivity.this.resumed && i == PreviewActivity.this.epoch) {
                PreviewActivity.this.status.setText((str == null && jSONObject != null && jSONObject.optBoolean("visible")) ? R.string.preview_active : R.string.preview_unavailable);
                PreviewActivity.this.main.postDelayed(this, 400L);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$run$1(int i, JSONObject jSONObject, String str) {
            if (PreviewActivity.this.resumed && i == PreviewActivity.this.epoch) {
                if (str != null || jSONObject == null) {
                    PreviewActivity.this.image.setImageDrawable(null);
                    PreviewActivity.this.status.setText(R.string.preview_unavailable);
                } else {
                    try {
                        byte[] bArrDecode = Base64.decode(jSONObject.getString("data"), 2);
                        Bitmap bitmapDecodeByteArray = BitmapFactory.decodeByteArray(bArrDecode, 0, bArrDecode.length);
                        if (bitmapDecodeByteArray == null) {
                            throw new IllegalStateException();
                        }
                        PreviewActivity.this.image.setImageBitmap(bitmapDecodeByteArray);
                        PreviewActivity.this.status.setText(R.string.preview_active);
                    } catch (Exception unused) {
                        PreviewActivity.this.image.setImageDrawable(null);
                        PreviewActivity.this.status.setText(R.string.preview_unavailable);
                    }
                }
                PreviewActivity.this.main.postDelayed(this, 40L);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void closePreview() {
        startActivity(new Intent("android.intent.action.MAIN").addCategory("android.intent.category.HOME").addFlags(268435456));
        finishAndRemoveTask();
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        closePreview();
    }
}
