package fr.phonemcp;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.view.SurfaceControl;
import java.util.Arrays;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import okhttp3.HttpUrl;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import rikka.shizuku.Shizuku;

/* JADX INFO: loaded from: classes.dex */
final class BackgroundClient {
    static volatile String lastError = "";
    private ServiceConnection connection;
    private final Context context;
    private volatile int generation;
    private volatile String latestPackage;
    private volatile IBackgroundControl remote;
    private Shizuku.UserServiceArgs serviceArgs;
    private volatile JSONObject state;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService calls = Executors.newSingleThreadExecutor();
    private final ExecutorService previews = Executors.newSingleThreadExecutor();
    private final Set<String> controlledPackages = ConcurrentHashMap.newKeySet();
    private final IPreviewCallback previewCallback = new AnonymousClass1();
    private final IBinder owner = new Binder();

    /* JADX INFO: renamed from: fr.phonemcp.BackgroundClient$1, reason: invalid class name */
    class AnonymousClass1 extends IPreviewCallback.Stub {
        AnonymousClass1() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$onPreviewRequested$0(String str) {
            if (BackgroundClient.this.controlledPackages.contains(str)) {
                BridgeService.showPreview(str);
            }
        }

        @Override // fr.phonemcp.IPreviewCallback
        public void onPreviewRequested(final String str) {
            BackgroundClient.this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$onPreviewRequested$0(str);
                }
            });
        }
    }

    BackgroundClient(Context context) {
        this.context = context.getApplicationContext();
    }

    static boolean permitted() {
        try {
            return Shizuku.pingBinder() && !Shizuku.isPreV11() && Shizuku.getUid() == 2000 && Shizuku.checkSelfPermission() == 0;
        } catch (Exception unused) {
            return false;
        }
    }

    static String permissionStatus() {
        try {
            if (!Shizuku.pingBinder()) {
                return "Shizuku arrêté ou absent";
            }
            if (Shizuku.getUid() != 2000) {
                return "Démarrez Shizuku avec le débogage sans fil, sans root";
            }
            return Shizuku.checkSelfPermission() == 0 ? "Shizuku autorisé" : "Autorisation Phone MCP à accorder dans Shizuku";
        } catch (Exception unused) {
            return "Shizuku indisponible";
        }
    }

    boolean ready() {
        IBackgroundControl iBackgroundControl = this.remote;
        return iBackgroundControl != null && iBackgroundControl.asBinder().isBinderAlive() && this.state != null && this.state.optBoolean("ready");
    }

    JSONObject state() {
        try {
            return new JSONObject(this.state == null ? "{}" : this.state.toString()).put("ready", ready()).put("error", (!lastError.isEmpty() || this.state == null) ? lastError : this.state.optString("error")).put("shizuku", permissionStatus());
        } catch (JSONException unused) {
            return new JSONObject();
        }
    }

    boolean filesReady() {
        return this.remote != null && this.remote.asBinder().isBinderAlive() && this.state != null && this.state.optBoolean("fileServiceReady");
    }

    boolean fileJobActive() {
        return this.state != null && this.state.optBoolean("fileJobActive");
    }

    boolean controls(String str) {
        return str != null && this.controlledPackages.contains(str) && ready();
    }

    String previewPackage() {
        if (controls(this.latestPackage)) {
            return this.latestPackage;
        }
        return null;
    }

    void start(final long j, final boolean z, final boolean z2, final PhoneAccessibilityService.Reply reply) {
        final IBackgroundControl iBackgroundControl = this.remote;
        if (iBackgroundControl != null && iBackgroundControl.asBinder().isBinderAlive() && permitted()) {
            final int i = this.generation + 1;
            this.generation = i;
            this.state = null;
            lastError = HttpUrl.FRAGMENT_ENCODE_SET;
            this.controlledPackages.clear();
            this.latestPackage = null;
            this.calls.execute(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda25
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$start$2(iBackgroundControl, j, z, z2, i, reply);
                }
            });
            return;
        }
        close();
        lastError = HttpUrl.FRAGMENT_ENCODE_SET;
        final int i2 = this.generation;
        if (!permitted()) {
            lastError = permissionStatus();
            reply.done(null, lastError);
            return;
        }
        final AtomicBoolean atomicBoolean = new AtomicBoolean();
        final PhoneAccessibilityService.Reply reply2 = new PhoneAccessibilityService.Reply() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda26
            @Override // fr.phonemcp.PhoneAccessibilityService.Reply
            public final void done(JSONObject jSONObject, String str) {
                this.f$0.lambda$start$3(i2, atomicBoolean, reply, jSONObject, str);
            }
        };
        this.serviceArgs = new Shizuku.UserServiceArgs(new ComponentName(this.context, (Class<?>) BackgroundControlService.class)).daemon(false).processNameSuffix("parallel").debuggable(false).version(18);
        this.connection = new AnonymousClass2(j, z, z2, i2, reply2);
        this.calls.execute(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda27
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$start$5(i2, reply2);
            }
        });
        this.main.postDelayed(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda28
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$start$6(i2, atomicBoolean, reply);
            }
        }, 25000L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$start$0(int i, JSONObject jSONObject, PhoneAccessibilityService.Reply reply) {
        if (i == this.generation) {
            this.state = jSONObject;
            reply.done(jSONObject, null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$start$1(int i, Exception exc, PhoneAccessibilityService.Reply reply) {
        if (i == this.generation) {
            lastError = message(exc);
            reply.done(null, lastError);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$start$2(IBackgroundControl iBackgroundControl, long j, boolean z, boolean z2, final int i, final PhoneAccessibilityService.Reply reply) {
        try {
            iBackgroundControl.stop();
            iBackgroundControl.setPreviewCallback(this.previewCallback);
            final JSONObject jSONObjectUnwrap = unwrap(iBackgroundControl.start(j, this.owner, z, z2));
            this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda13
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$start$0(i, jSONObjectUnwrap, reply);
                }
            });
        } catch (Exception e) {
            this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda14
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$start$1(i, e, reply);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$start$3(int i, AtomicBoolean atomicBoolean, PhoneAccessibilityService.Reply reply, JSONObject jSONObject, String str) {
        if (i == this.generation && atomicBoolean.compareAndSet(false, true)) {
            reply.done(jSONObject, str);
        }
    }

    /* JADX INFO: renamed from: fr.phonemcp.BackgroundClient$2, reason: invalid class name */
    class AnonymousClass2 implements ServiceConnection {
        final /* synthetic */ long val$deadline;
        final /* synthetic */ int val$expected;
        final /* synthetic */ PhoneAccessibilityService.Reply val$once;
        final /* synthetic */ boolean val$parallelDisplay;
        final /* synthetic */ boolean val$screenOff;

        AnonymousClass2(long j, boolean z, boolean z2, int i, PhoneAccessibilityService.Reply reply) {
            this.val$deadline = j;
            this.val$screenOff = z;
            this.val$parallelDisplay = z2;
            this.val$expected = i;
            this.val$once = reply;
        }

        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            if (BackgroundClient.this.connection != this) {
                return;
            }
            final IBackgroundControl iBackgroundControlAsInterface = IBackgroundControl.Stub.asInterface(iBinder);
            BackgroundClient.this.remote = iBackgroundControlAsInterface;
            ExecutorService executorService = BackgroundClient.this.calls;
            final long j = this.val$deadline;
            final boolean z = this.val$screenOff;
            final boolean z2 = this.val$parallelDisplay;
            final int i = this.val$expected;
            final PhoneAccessibilityService.Reply reply = this.val$once;
            executorService.execute(new Runnable() { // from class: fr.phonemcp.BackgroundClient$2$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$onServiceConnected$2(iBackgroundControlAsInterface, j, z, z2, i, reply);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$onServiceConnected$0(int i, JSONObject jSONObject, PhoneAccessibilityService.Reply reply) {
            if (i != BackgroundClient.this.generation) {
                return;
            }
            BackgroundClient.this.state = jSONObject;
            reply.done(jSONObject, null);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$onServiceConnected$2(IBackgroundControl iBackgroundControl, long j, boolean z, boolean z2, final int i, final PhoneAccessibilityService.Reply reply) {
            try {
                iBackgroundControl.setPreviewCallback(BackgroundClient.this.previewCallback);
                BackgroundClient backgroundClient = BackgroundClient.this;
                final JSONObject jSONObjectUnwrap = backgroundClient.unwrap(iBackgroundControl.start(j, backgroundClient.owner, z, z2));
                BackgroundClient.this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$2$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.lambda$onServiceConnected$0(i, jSONObjectUnwrap, reply);
                    }
                });
            } catch (Exception e) {
                BackgroundClient.this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$2$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.lambda$onServiceConnected$1(i, e, reply);
                    }
                });
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$onServiceConnected$1(int i, Exception exc, PhoneAccessibilityService.Reply reply) {
            if (i != BackgroundClient.this.generation) {
                return;
            }
            BackgroundClient.lastError = BackgroundClient.message(exc);
            reply.done(null, BackgroundClient.lastError);
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName componentName) {
            if (BackgroundClient.this.connection == this) {
                BackgroundClient.this.remote = null;
                BackgroundClient.this.state = null;
                BackgroundClient.lastError = "Le service Shizuku s’est arrêté. Relancez une session.";
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$start$5(final int i, final PhoneAccessibilityService.Reply reply) {
        this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$start$4(i, reply);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$start$4(int i, PhoneAccessibilityService.Reply reply) {
        if (i != this.generation) {
            return;
        }
        try {
            Shizuku.bindUserService(this.serviceArgs, this.connection);
        } catch (Exception e) {
            lastError = message(e);
            reply.done(null, lastError);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$start$6(int i, AtomicBoolean atomicBoolean, PhoneAccessibilityService.Reply reply) {
        if (i == this.generation && atomicBoolean.compareAndSet(false, true)) {
            lastError = "Démarrage Shizuku trop long. Ouvrez Shizuku puis relancez la session.";
            String str = lastError;
            close();
            reply.done(null, str);
        }
    }

    void refresh(final PhoneAccessibilityService.Reply reply) {
        final IBackgroundControl iBackgroundControl = this.remote;
        final int i = this.generation;
        if (iBackgroundControl != null && permitted()) {
            this.calls.execute(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda7
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$refresh$9(iBackgroundControl, i, reply);
                }
            });
            return;
        }
        if (iBackgroundControl != null) {
            lastError = permissionStatus();
        }
        reply.done(state(), null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$refresh$7(int i, JSONObject jSONObject, PhoneAccessibilityService.Reply reply) {
        if (i != this.generation) {
            return;
        }
        this.state = jSONObject;
        reply.done(state(), null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$refresh$9(IBackgroundControl iBackgroundControl, final int i, final PhoneAccessibilityService.Reply reply) {
        try {
            final JSONObject jSONObjectUnwrap = unwrap(iBackgroundControl.execute("status", new JSONObject().put("allowedLeasePackages", allowedLeases()).toString()));
            this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda16
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$refresh$7(i, jSONObjectUnwrap, reply);
                }
            });
        } catch (Exception e) {
            this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda17
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$refresh$8(i, e, reply);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$refresh$8(int i, Exception exc, PhoneAccessibilityService.Reply reply) {
        if (i != this.generation) {
            return;
        }
        this.state = null;
        lastError = message(exc);
        reply.done(state(), null);
    }

    void restorePanel(final PhoneAccessibilityService.Reply reply) {
        final IBackgroundControl iBackgroundControl = this.remote;
        final int i = this.generation;
        if (iBackgroundControl == null) {
            reply.done(null, "Service parallèle arrêté");
        } else {
            this.calls.execute(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$restorePanel$12(iBackgroundControl, i, reply);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$restorePanel$10(int i, JSONObject jSONObject, PhoneAccessibilityService.Reply reply) {
        if (i != this.generation) {
            return;
        }
        this.state = jSONObject;
        reply.done(jSONObject, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$restorePanel$12(IBackgroundControl iBackgroundControl, final int i, final PhoneAccessibilityService.Reply reply) {
        try {
            final JSONObject jSONObjectUnwrap = unwrap(iBackgroundControl.restorePanel());
            this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda10
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$restorePanel$10(i, jSONObjectUnwrap, reply);
                }
            });
        } catch (Exception e) {
            this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda12
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$restorePanel$11(i, reply, e);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$restorePanel$11(int i, PhoneAccessibilityService.Reply reply, Exception exc) {
        if (i == this.generation) {
            reply.done(null, message(exc));
        }
    }

    private JSONArray allowedLeases() {
        Settings settings = new Settings(this.context);
        JSONArray jSONArray = new JSONArray();
        for (String str : this.controlledPackages) {
            if (settings.allowed(str, "read") && settings.allowed(str, "write")) {
                jSONArray.put(str);
            } else {
                this.controlledPackages.remove(str);
            }
        }
        return jSONArray;
    }

    private JSONObject previewArguments(String str) throws Exception {
        Settings settings = new Settings(this.context);
        if (!BridgeService.parallelEnabled() || !controls(str) || !permitted() || !settings.allowed(str, "read") || !settings.allowed(str, "capture")) {
            throw new SecurityException("Aperçu indisponible pour cette app.");
        }
        JSONArray jSONArrayPut = new JSONArray().put(str);
        JSONArray jSONArrayOptJSONArray = this.state == null ? null : this.state.optJSONArray("windows");
        if (jSONArrayOptJSONArray != null) {
            for (int i = 0; i < jSONArrayOptJSONArray.length(); i++) {
                String strOptString = jSONArrayOptJSONArray.getJSONObject(i).optString("packageName");
                if (settings.allowed(strOptString, "read") && settings.allowed(strOptString, "capture")) {
                    jSONArrayPut.put(strOptString);
                }
            }
        }
        return new JSONObject().put("packageName", str).put("capturePackages", jSONArrayPut);
    }

    void previewSurface(final String str, String str2, final SurfaceControl surfaceControl, int i, int i2, PhoneAccessibilityService.Reply reply) {
        final BackgroundClient backgroundClient;
        final String str3;
        final PhoneAccessibilityService.Reply reply2;
        Exception exc;
        final int i3 = this.generation;
        final IBackgroundControl iBackgroundControl = this.remote;
        try {
            JSONObject jSONObjectPut = previewArguments(str).put("viewerId", str2);
            if (surfaceControl != null) {
                try {
                    jSONObjectPut.put("width", i).put("height", i2);
                } catch (Exception e) {
                    exc = e;
                    backgroundClient = this;
                    str3 = str2;
                    reply2 = reply;
                    backgroundClient.detachPreview(str3);
                    reply2.done(null, message(exc));
                }
            }
            final String string = jSONObjectPut.toString();
            backgroundClient = this;
            str3 = str2;
            reply2 = reply;
            try {
                this.previews.execute(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda11
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.lambda$previewSurface$15(i3, str, surfaceControl, iBackgroundControl, string, str3, reply2);
                    }
                });
            } catch (Exception e2) {
                e = e2;
                exc = e;
                backgroundClient.detachPreview(str3);
                reply2.done(null, message(exc));
            }
        } catch (Exception e3) {
            e = e3;
            backgroundClient = this;
            str3 = str2;
            reply2 = reply;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$previewSurface$15(final int i, final String str, SurfaceControl surfaceControl, IBackgroundControl iBackgroundControl, String str2, final String str3, final PhoneAccessibilityService.Reply reply) {
        final Exception exc;
        String strRenewPreview;
        try {
            try {
                if (i != this.generation) {
                    throw new IllegalStateException("Session arrêtée.");
                }
                previewArguments(str);
                if (surfaceControl == null) {
                    try {
                        strRenewPreview = iBackgroundControl.renewPreview(str2);
                    } catch (Exception e) {
                        exc = e;
                    }
                } else {
                    strRenewPreview = iBackgroundControl.attachPreview(str2, surfaceControl);
                }
                final JSONObject jSONObjectUnwrap = unwrap(strRenewPreview);
                this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda21
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.lambda$previewSurface$13(i, str, str3, reply, jSONObjectUnwrap);
                    }
                });
                return;
            } catch (Exception e2) {
                e = e2;
                exc = e;
            }
        } catch (Exception e3) {
            e = e3;
        }
        exc = e;
        this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda23
            @Override // java.lang.Runnable
            public final void run() {
                reply.done(null, BackgroundClient.message(exc));
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$previewSurface$13(int i, String str, String str2, PhoneAccessibilityService.Reply reply, JSONObject jSONObject) {
        if (i == this.generation && BridgeService.canPreview(str)) {
            reply.done(jSONObject, null);
        } else {
            detachPreview(str2);
            reply.done(null, "Aperçu arrêté.");
        }
    }

    void detachPreview(final String str) {
        final IBackgroundControl iBackgroundControl = this.remote;
        if (iBackgroundControl == null || str == null) {
            return;
        }
        this.previews.execute(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda18
            @Override // java.lang.Runnable
            public final void run() throws RemoteException {
                iBackgroundControl.detachPreview(str);
            }
        });
    }

    void controlMode(final String str, final boolean z, final long j, final PhoneAccessibilityService.Reply reply) {
        final int i = this.generation;
        final IBackgroundControl iBackgroundControl = this.remote;
        if (iBackgroundControl == null || !iBackgroundControl.asBinder().isBinderAlive() || !permitted()) {
            reply.done(null, "Service Shizuku indisponible. Relancez une session sur le téléphone.");
        } else {
            this.calls.execute(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$controlMode$19(i, iBackgroundControl, str, z, j, reply);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$controlMode$19(final int i, IBackgroundControl iBackgroundControl, String str, boolean z, long j, final PhoneAccessibilityService.Reply reply) {
        try {
            if (i != this.generation || !BridgeService.active() || !permitted()) {
                throw new IllegalStateException("Session ou autorisation arrêtée.");
            }
            final JSONObject jSONObjectUnwrap = unwrap(iBackgroundControl.execute("control_mode", new JSONObject().put("mode", str).put("panelOff", z).put("deadline", j).toString()));
            this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda22
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$controlMode$17(i, jSONObjectUnwrap, reply);
                }
            });
        } catch (Exception e) {
            this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda24
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$controlMode$18(i, e, reply);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$controlMode$17(int i, JSONObject jSONObject, PhoneAccessibilityService.Reply reply) {
        if (i == this.generation) {
            this.state = jSONObject;
            lastError = HttpUrl.FRAGMENT_ENCODE_SET;
            this.controlledPackages.clear();
            this.latestPackage = null;
            reply.done(jSONObject, null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$controlMode$18(int i, Exception exc, PhoneAccessibilityService.Reply reply) {
        if (i == this.generation) {
            lastError = message(exc);
            reply.done(null, lastError);
        }
    }

    void execute(final String str, JSONObject jSONObject, final PhoneAccessibilityService.Reply reply) {
        final int i = this.generation;
        final IBackgroundControl iBackgroundControl = this.remote;
        try {
            if (BridgeService.active() && BridgeService.parallelEnabled() && ready() && permitted()) {
                if (!Arrays.asList("open_app", "open_url", "snapshot", "screenshot", "click", "long_press", "set_text", "scroll", "back", "tap", "swipe").contains(str)) {
                    throw new IllegalArgumentException("Commande parallèle inconnue.");
                }
                final String string = jSONObject.getString("packageName");
                Settings settings = new Settings(this.context);
                String str2 = "screenshot".equals(str) ? "capture" : "snapshot".equals(str) ? "read" : "write";
                if (!settings.allowed(string, "read") || !settings.allowed(string, str2)) {
                    throw new SecurityException("Application ou capacité non autorisée.");
                }
                JSONObject jSONObject2 = new JSONObject(jSONObject.toString());
                if ("screenshot".equals(str)) {
                    JSONArray jSONArrayPut = new JSONArray().put(string);
                    JSONArray jSONArrayOptJSONArray = this.state == null ? null : this.state.optJSONArray("windows");
                    if (jSONArrayOptJSONArray != null) {
                        for (int i2 = 0; i2 < jSONArrayOptJSONArray.length(); i2++) {
                            String strOptString = jSONArrayOptJSONArray.getJSONObject(i2).optString("packageName");
                            if (settings.allowed(strOptString, "read") && settings.allowed(strOptString, "capture")) {
                                jSONArrayPut.put(strOptString);
                            }
                        }
                    }
                    jSONObject2.put("capturePackages", jSONArrayPut);
                }
                final String string2 = jSONObject2.toString();
                this.calls.execute(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda4
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.lambda$execute$22(i, iBackgroundControl, str, string2, string, reply);
                    }
                });
                return;
            }
            throw new IllegalStateException(lastError.isEmpty() ? "Mode parallèle non prêt. Consultez phone_status puis relancez la session avec Shizuku." : lastError);
        } catch (Exception e) {
            reply.done(null, message(e));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$execute$20(int i, String str, String str2, PhoneAccessibilityService.Reply reply, JSONObject jSONObject) {
        if (i == this.generation) {
            if (("open_app".equals(str) || "open_url".equals(str)) && !str2.equals(this.context.getPackageName())) {
                this.controlledPackages.add(str2);
                this.latestPackage = str2;
            }
            reply.done(jSONObject, null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$execute$22(final int i, IBackgroundControl iBackgroundControl, final String str, String str2, final String str3, final PhoneAccessibilityService.Reply reply) {
        try {
            try {
                if (i != this.generation || !BridgeService.active() || !permitted()) {
                    throw new IllegalStateException("Session ou autorisation arrêtée avant envoi.");
                }
                final JSONObject jSONObjectUnwrap = unwrap(iBackgroundControl.execute(str, str2));
                this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda19
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.lambda$execute$20(i, str, str3, reply, jSONObjectUnwrap);
                    }
                });
                return;
            } catch (Exception e) {
                e = e;
            }
        } catch (Exception e2) {
            e = e2;
        }
        final Exception exc = e;
        this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda20
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$execute$21(i, reply, exc);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$execute$21(int i, PhoneAccessibilityService.Reply reply, Exception exc) {
        if (i == this.generation) {
            reply.done(null, message(exc));
        }
    }

    void previewFrame(final String str, final PhoneAccessibilityService.Reply reply) {
        Exception exc;
        final int i = this.generation;
        final IBackgroundControl iBackgroundControl = this.remote;
        try {
            Settings settings = new Settings(this.context);
            try {
                if (!BridgeService.parallelEnabled() || !controls(str) || !permitted() || !settings.allowed(str, "read") || !settings.allowed(str, "capture")) {
                    throw new SecurityException("Aperçu indisponible pour cette app.");
                }
                JSONArray jSONArrayPut = new JSONArray().put(str);
                JSONArray jSONArrayOptJSONArray = this.state == null ? null : this.state.optJSONArray("windows");
                if (jSONArrayOptJSONArray != null) {
                    for (int i2 = 0; i2 < jSONArrayOptJSONArray.length(); i2++) {
                        try {
                            String strOptString = jSONArrayOptJSONArray.getJSONObject(i2).optString("packageName");
                            if (settings.allowed(strOptString, "read") && settings.allowed(strOptString, "capture")) {
                                jSONArrayPut.put(strOptString);
                            }
                        } catch (Exception e) {
                            exc = e;
                        }
                    }
                }
                final String string = new JSONObject().put("packageName", str).put("capturePackages", jSONArrayPut).toString();
                this.previews.execute(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda15
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.lambda$previewFrame$25(i, str, iBackgroundControl, string, reply);
                    }
                });
                return;
            } catch (Exception e2) {
                e = e2;
                exc = e;
            }
        } catch (Exception e3) {
            e = e3;
        }
        exc = e;
        reply.done(null, message(exc));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$previewFrame$25(final int i, final String str, IBackgroundControl iBackgroundControl, String str2, final PhoneAccessibilityService.Reply reply) {
        try {
            try {
                if (i != this.generation || !BridgeService.parallelEnabled() || !controls(str) || !permitted()) {
                    throw new SecurityException("Session arrêtée.");
                }
                final JSONObject jSONObjectUnwrap = unwrap(iBackgroundControl.previewFrame(str2));
                this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda8
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.lambda$previewFrame$23(i, str, reply, jSONObjectUnwrap);
                    }
                });
                return;
            } catch (Exception e) {
                e = e;
            }
        } catch (Exception e2) {
            e = e2;
        }
        final Exception exc = e;
        this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda9
            @Override // java.lang.Runnable
            public final void run() {
                reply.done(null, BackgroundClient.message(exc));
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$previewFrame$23(int i, String str, PhoneAccessibilityService.Reply reply, JSONObject jSONObject) {
        Settings settings = new Settings(this.context);
        if (i == this.generation && BridgeService.parallelEnabled() && controls(str) && permitted() && settings.allowed(str, "read") && settings.allowed(str, "capture")) {
            reply.done(jSONObject, null);
        } else {
            reply.done(null, "Aperçu arrêté.");
        }
    }

    void executeFiles(final String str, JSONObject jSONObject, final PhoneAccessibilityService.Reply reply) {
        Exception exc;
        final int i = this.generation;
        final IBackgroundControl iBackgroundControl = this.remote;
        try {
            try {
                if (!BridgeService.active() || !filesReady() || !permitted()) {
                    throw new IllegalStateException("Démarrez Shizuku puis relancez la session pour les fichiers et APK.");
                }
                if (!Arrays.asList("files_list", "file_job", "download_file", "install_apk", "files_cancel_all").contains(str)) {
                    throw new IllegalArgumentException("Commande fichiers inconnue.");
                }
                if (!new Settings(this.context).filesAllowed()) {
                    try {
                        if (!"files_cancel_all".equals(str)) {
                            throw new SecurityException("Activez Fichiers et APK dans les réglages de Phone MCP.");
                        }
                    } catch (Exception e) {
                        exc = e;
                    }
                }
                final String string = jSONObject.toString();
                this.calls.execute(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda2
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.lambda$executeFiles$28(i, str, iBackgroundControl, string, reply);
                    }
                });
                return;
            } catch (Exception e2) {
                e = e2;
                exc = e;
            }
        } catch (Exception e3) {
            e = e3;
        }
        exc = e;
        reply.done(null, message(exc));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0023, code lost:
    
        if ("files_cancel_all".equals(r8) != false) goto L15;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public /* synthetic */ void lambda$executeFiles$28(final int i, String str, IBackgroundControl iBackgroundControl, String str2, final PhoneAccessibilityService.Reply reply) {
        final Exception exc;
        try {
            try {
                if (i == this.generation && BridgeService.active() && permitted()) {
                    if (!new Settings(this.context).filesAllowed()) {
                        try {
                        } catch (Exception e) {
                            exc = e;
                            this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda30
                                @Override // java.lang.Runnable
                                public final void run() {
                                    this.f$0.lambda$executeFiles$27(i, reply, exc);
                                }
                            });
                        }
                    }
                    final JSONObject jSONObjectUnwrap = unwrap(iBackgroundControl.execute(str, str2));
                    final JSONObject jSONObjectUnwrap2 = unwrap(iBackgroundControl.execute("status", "{}"));
                    this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda29
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.lambda$executeFiles$26(i, jSONObjectUnwrap2, reply, jSONObjectUnwrap);
                        }
                    });
                    return;
                }
                throw new SecurityException("Session ou autorisation fichiers arrêtée.");
            } catch (Exception e2) {
                e = e2;
                exc = e;
                this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda30
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.lambda$executeFiles$27(i, reply, exc);
                    }
                });
            }
        } catch (Exception e3) {
            e = e3;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$executeFiles$26(int i, JSONObject jSONObject, PhoneAccessibilityService.Reply reply, JSONObject jSONObject2) {
        if (i == this.generation) {
            this.state = jSONObject;
            reply.done(jSONObject2, null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$executeFiles$27(int i, PhoneAccessibilityService.Reply reply, Exception exc) {
        if (i == this.generation) {
            reply.done(null, message(exc));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public JSONObject unwrap(String str) throws Exception {
        JSONObject jSONObject = new JSONObject(str);
        if (!jSONObject.optBoolean("ok")) {
            throw new IllegalStateException(jSONObject.optString("error", "Service Shizuku indisponible"));
        }
        JSONObject jSONObject2 = jSONObject.getJSONObject("result");
        Settings settings = new Settings(this.context);
        JSONArray jSONArrayOptJSONArray = jSONObject2.optJSONArray("windows");
        if (jSONArrayOptJSONArray != null) {
            JSONArray jSONArray = new JSONArray();
            for (int i = 0; i < jSONArrayOptJSONArray.length(); i++) {
                JSONObject jSONObject3 = jSONArrayOptJSONArray.getJSONObject(i);
                if (settings.allowed(jSONObject3.optString("packageName"), "read")) {
                    jSONArray.put(jSONObject3);
                }
            }
            jSONObject2.put("windows", jSONArray);
        }
        if (!settings.filesAllowed()) {
            jSONObject2.remove("activeFileJob");
        }
        return jSONObject2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static String message(Exception exc) {
        return exc.getMessage() == null ? exc.getClass().getSimpleName() : exc.getMessage();
    }

    void close() {
        this.generation++;
        this.state = null;
        this.controlledPackages.clear();
        this.latestPackage = null;
        final IBackgroundControl iBackgroundControl = this.remote;
        this.remote = null;
        final Shizuku.UserServiceArgs userServiceArgs = this.serviceArgs;
        final ServiceConnection serviceConnection = this.connection;
        this.serviceArgs = null;
        this.connection = null;
        if (userServiceArgs == null || serviceConnection == null) {
            return;
        }
        this.calls.execute(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$close$30(iBackgroundControl, userServiceArgs, serviceConnection);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$close$30(IBackgroundControl iBackgroundControl, final Shizuku.UserServiceArgs userServiceArgs, final ServiceConnection serviceConnection) {
        if (iBackgroundControl != null) {
            try {
                if (iBackgroundControl.asBinder().isBinderAlive()) {
                    iBackgroundControl.stop();
                }
            } catch (Exception unused) {
            }
        }
        this.main.post(new Runnable() { // from class: fr.phonemcp.BackgroundClient$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                Shizuku.unbindUserService(userServiceArgs, serviceConnection, true);
            }
        });
    }

    void destroy() {
        close();
        this.calls.shutdown();
        this.previews.shutdownNow();
    }
}
