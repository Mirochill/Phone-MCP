package fr.phonemcp;

/* JADX INFO: loaded from: classes.dex */
final class SessionPolicy {
    static final long UNLIMITED = Long.MAX_VALUE;

    static boolean unlimited(long j) {
        return j == Long.MAX_VALUE;
    }

    static boolean validDeadline(long j, long j2) {
        return j >= 0 && j2 > j;
    }

    SessionPolicy() {
    }

    static long deadline(long j, long j2) {
        if (j < 0 || j2 < 0) {
            throw new IllegalArgumentException("Durée de session invalide");
        }
        if (j2 == 0) {
            return Long.MAX_VALUE;
        }
        long jAddExact = Math.addExact(j, Math.multiplyExact(j2, 60000L));
        if (jAddExact != Long.MAX_VALUE) {
            return jAddExact;
        }
        throw new IllegalArgumentException("Durée de session trop longue");
    }

    static boolean active(boolean z, long j, long j2) {
        return z && validDeadline(j, j2);
    }
}
