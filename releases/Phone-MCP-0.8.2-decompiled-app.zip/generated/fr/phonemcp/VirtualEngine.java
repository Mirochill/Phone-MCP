package fr.phonemcp;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.KeyguardManager;
import android.app.UiAutomation;
import android.content.AttributionSource;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.os.SystemClock;
import android.os.UserManager;
import android.util.Base64;
import android.view.Display;
import android.view.InputEvent;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceControl;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import okhttp3.HttpUrl;
import okio.Segment;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
final class VirtualEngine {
    static final int DENSITY = 280;
    static final int HEIGHT = 1280;
    static final int WIDTH = 720;
    private UiAutomation automation;
    private final HandlerThread automationThread;
    private final AtomicBoolean captureBusy;
    private final ExecutorService captureWorker;
    private long contentVersion;
    private Context context;
    private long deadline;
    private VirtualDisplay display;
    private int displayId;
    private PowerManager.WakeLock displayLease;
    private final Handler frames;
    private final HandlerThread framesThread;
    private long generation;
    private final Runnable guardTick;
    private final Map<String, String> identities;
    private volatile String lastCommandError;
    private long lastKeepActive;
    private String lastPreviewRequest;
    private final Set<String> launchedPackages;
    private Method listRootTasks;
    private Method moveRootTask;
    private final Map<String, AccessibilityNodeInfo> nodes;
    private PanelPower panel;
    private boolean panelOff;
    private volatile IPreviewCallback previewCallback;
    private String previewError;
    private final PreviewFrames previewFrames;
    private final PreviewMirror previewMirror;
    private ImageReader reader;
    private boolean requestedPanelOff;
    private boolean sharedSleepRecovery;
    private long snapshotContentVersion;
    private long snapshotGeneration;
    private String snapshotId;
    private String snapshotPackage;
    private long snapshotTime;
    private String stoppedReason;
    private final ParallelTaskLease taskLeases;
    private Object taskManager;
    private final Runnable watchTasks;
    private int windowId;
    private final Handler worker;
    private final HandlerThread workerThread;

    void setPreviewCallback(IPreviewCallback iPreviewCallback) {
        this.previewCallback = iPreviewCallback;
    }

    VirtualEngine() {
        HandlerThread handlerThread = new HandlerThread("phone-mcp-display");
        this.workerThread = handlerThread;
        HandlerThread handlerThread2 = new HandlerThread("phone-mcp-frames");
        this.framesThread = handlerThread2;
        HandlerThread handlerThread3 = new HandlerThread("phone-mcp-accessibility");
        this.automationThread = handlerThread3;
        this.captureWorker = Executors.newSingleThreadExecutor();
        this.captureBusy = new AtomicBoolean();
        this.nodes = new HashMap();
        this.identities = new HashMap();
        this.stoppedReason = HttpUrl.FRAGMENT_ENCODE_SET;
        this.lastCommandError = HttpUrl.FRAGMENT_ENCODE_SET;
        this.displayId = -1;
        this.windowId = -1;
        this.taskLeases = new ParallelTaskLease();
        this.launchedPackages = new HashSet();
        this.previewFrames = new PreviewFrames();
        this.previewMirror = new PreviewMirror();
        this.lastPreviewRequest = HttpUrl.FRAGMENT_ENCODE_SET;
        this.previewError = HttpUrl.FRAGMENT_ENCODE_SET;
        this.guardTick = new Runnable() { // from class: fr.phonemcp.VirtualEngine.2
            @Override // java.lang.Runnable
            public void run() {
                try {
                    VirtualEngine.this.requireSession();
                    if (VirtualEngine.this.sharedSleepRecovery && ((PowerManager) VirtualEngine.this.context.getSystemService(PowerManager.class)).isInteractive() && !((KeyguardManager) VirtualEngine.this.context.getSystemService(KeyguardManager.class)).isKeyguardLocked()) {
                        if (VirtualEngine.this.panel != null) {
                            VirtualEngine.this.panel.restore();
                        }
                        VirtualEngine.this.panelOff = false;
                        VirtualEngine.this.sharedSleepRecovery = false;
                    }
                    if (SystemClock.elapsedRealtime() - VirtualEngine.this.lastKeepActive >= 4000) {
                        if (VirtualEngine.this.panel == null) {
                            VirtualEngine.this.panel = new PanelPower();
                        }
                        VirtualEngine.this.panel.keepActive(VirtualEngine.this.displayId);
                        if (VirtualEngine.this.panelOff && ((PowerManager) VirtualEngine.this.context.getSystemService(PowerManager.class)).isInteractive() && !((KeyguardManager) VirtualEngine.this.context.getSystemService(KeyguardManager.class)).isKeyguardLocked()) {
                            VirtualEngine.this.panel.keepActive(0);
                        }
                        VirtualEngine.this.lastKeepActive = SystemClock.elapsedRealtime();
                    }
                    VirtualEngine.this.worker.postDelayed(this, 1000L);
                } catch (Exception e) {
                    VirtualEngine.this.stoppedReason = e.getMessage();
                    VirtualEngine.this.stopInternal();
                }
            }
        };
        this.watchTasks = new Runnable() { // from class: fr.phonemcp.VirtualEngine.3
            @Override // java.lang.Runnable
            public void run() {
                if (VirtualEngine.this.displayId <= 0 || SystemClock.elapsedRealtime() >= VirtualEngine.this.deadline) {
                    return;
                }
                try {
                    VirtualEngine.this.reconcileTasks();
                    VirtualEngine.this.previewError = HttpUrl.FRAGMENT_ENCODE_SET;
                } catch (Exception unused) {
                    VirtualEngine.this.previewError = "L’aperçu automatique n’a pas pu récupérer la fenêtre. Le contrôle reste limité à l’écran séparé.";
                }
                if (VirtualEngine.this.previewMirror.active()) {
                    if (SystemClock.elapsedRealtime() >= VirtualEngine.this.previewMirror.deadline) {
                        VirtualEngine.this.previewMirror.clear();
                    } else {
                        try {
                            VirtualEngine virtualEngine = VirtualEngine.this;
                            virtualEngine.requirePreview(virtualEngine.previewMirror.pkg, VirtualEngine.this.previewMirror.capturePackages);
                            VirtualEngine.this.previewMirror.visible(true);
                        } catch (Exception unused2) {
                            VirtualEngine.this.previewMirror.visible(false);
                        }
                    }
                }
                VirtualEngine.this.worker.postDelayed(this, VirtualEngine.this.previewError.isEmpty() ? 250L : 1000L);
            }
        };
        handlerThread.start();
        handlerThread2.start();
        handlerThread3.start();
        this.worker = new Handler(handlerThread.getLooper());
        this.frames = new Handler(handlerThread2.getLooper());
    }

    private <T> T onWorker(final Callable<T> callable) throws Exception {
        if (Looper.myLooper() == this.worker.getLooper()) {
            return callable.call();
        }
        FutureTask futureTask = new FutureTask(new Callable() { // from class: fr.phonemcp.VirtualEngine$$ExternalSyntheticLambda2
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return VirtualEngine.lambda$onWorker$0(callable);
            }
        });
        this.worker.post(futureTask);
        try {
            return (T) futureTask.get(10L, TimeUnit.SECONDS);
        } catch (ExecutionException e) {
            Throwable cause = e.getCause();
            if (cause instanceof Exception) {
                throw ((Exception) cause);
            }
            throw new Exception(cause);
        } catch (TimeoutException e2) {
            futureTask.cancel(true);
            this.lastCommandError = "Délai de commande dépassé. Affichage conservé ; relisez l’état avant toute nouvelle action, sans répéter l’écriture.";
            this.worker.post(new Runnable() { // from class: fr.phonemcp.VirtualEngine$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.clearSnapshot();
                }
            });
            throw new IllegalStateException(this.lastCommandError, e2);
        }
    }

    static /* synthetic */ Object lambda$onWorker$0(Callable callable) throws Exception {
        try {
            return callable.call();
        } finally {
            Thread.interrupted();
        }
    }

    JSONObject start(final long j, final boolean z) throws Exception {
        return (JSONObject) onWorker(new Callable() { // from class: fr.phonemcp.VirtualEngine$$ExternalSyntheticLambda16
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return this.f$0.lambda$start$1(j, z);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: startInternal, reason: merged with bridge method [inline-methods] */
    public JSONObject lambda$start$1(long j, boolean z) throws Exception {
        if (Build.VERSION.SDK_INT < 34) {
            throw new IllegalStateException("Le mode parallèle nécessite Android 14 ou plus.");
        }
        if (Process.myUid() != 2000) {
            throw new SecurityException("Le mode parallèle utilise Shizuku démarré en débogage ADB sans root.");
        }
        if (!SessionPolicy.validDeadline(SystemClock.elapsedRealtime(), j)) {
            throw new IllegalArgumentException("Durée de session invalide");
        }
        stopInternal();
        this.deadline = j;
        this.stoppedReason = HttpUrl.FRAGMENT_ENCODE_SET;
        this.requestedPanelOff = z;
        try {
            Class<?> cls = Class.forName("android.app.ActivityThread");
            Object objInvoke = cls.getMethod("currentActivityThread", new Class[0]).invoke(null, new Object[0]);
            if (objInvoke == null) {
                objInvoke = cls.getMethod("systemMain", new Class[0]).invoke(null, new Object[0]);
            }
            this.context = new ContextWrapper((Context) cls.getMethod("getSystemContext", new Class[0]).invoke(objInvoke, new Object[0])) { // from class: fr.phonemcp.VirtualEngine.1
                @Override // android.content.ContextWrapper, android.content.Context
                public Context getApplicationContext() {
                    return this;
                }

                @Override // android.content.ContextWrapper, android.content.Context
                public int getDeviceId() {
                    return 0;
                }

                @Override // android.content.ContextWrapper, android.content.Context
                public String getPackageName() {
                    return "com.android.shell";
                }

                @Override // android.content.ContextWrapper, android.content.Context
                public String getOpPackageName() {
                    return "com.android.shell";
                }

                @Override // android.content.ContextWrapper, android.content.Context
                public AttributionSource getAttributionSource() {
                    return new AttributionSource.Builder(2000).setPackageName("com.android.shell").build();
                }
            };
            requireUnlocked();
            ImageReader imageReaderNewInstance = ImageReader.newInstance(WIDTH, HEIGHT, 1, 3);
            this.reader = imageReaderNewInstance;
            imageReaderNewInstance.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() { // from class: fr.phonemcp.VirtualEngine$$ExternalSyntheticLambda5
                @Override // android.media.ImageReader.OnImageAvailableListener
                public final void onImageAvailable(ImageReader imageReader) {
                    this.f$0.lambda$startInternal$2(imageReader);
                }
            }, this.frames);
            Constructor declaredConstructor = DisplayManager.class.getDeclaredConstructor(Context.class);
            declaredConstructor.setAccessible(true);
            VirtualDisplay virtualDisplayCreateVirtualDisplay = ((DisplayManager) declaredConstructor.newInstance(this.context)).createVirtualDisplay("Phone MCP · session active", WIDTH, HEIGHT, DENSITY, this.reader.getSurface(), 97611);
            this.display = virtualDisplayCreateVirtualDisplay;
            if (virtualDisplayCreateVirtualDisplay != null) {
                int displayId = virtualDisplayCreateVirtualDisplay.getDisplay().getDisplayId();
                this.displayId = displayId;
                if (displayId > 0) {
                    requireIsolatedDisplay();
                    Object objInvoke2 = Class.forName("android.view.WindowManagerGlobal").getMethod("getWindowManagerService", new Class[0]).invoke(null, new Object[0]);
                    objInvoke2.getClass().getMethod("setDisplayImePolicy", Integer.TYPE, Integer.TYPE).invoke(objInvoke2, Integer.valueOf(this.displayId), 0);
                    Class<?> cls2 = Class.forName("android.app.IUiAutomationConnection");
                    Object objNewInstance = Class.forName("android.app.UiAutomationConnection").getConstructor(new Class[0]).newInstance(new Object[0]);
                    if (this.context.createDisplayContext(this.display.getDisplay()).getDisplay().getDisplayId() != this.displayId) {
                        throw new SecurityException("Contexte d’affichage non isolé.");
                    }
                    Constructor declaredConstructor2 = UiAutomation.class.getDeclaredConstructor(Integer.TYPE, Looper.class, cls2);
                    declaredConstructor2.setAccessible(true);
                    this.automation = (UiAutomation) declaredConstructor2.newInstance(Integer.valueOf(this.displayId), this.automationThread.getLooper(), objNewInstance);
                    Field declaredField = UiAutomation.class.getDeclaredField("mDisplayId");
                    declaredField.setAccessible(true);
                    if (declaredField.getInt(this.automation) != this.displayId) {
                        throw new SecurityException("Capture non liée à l’affichage parallèle.");
                    }
                    UiAutomation.class.getMethod("connect", Integer.TYPE).invoke(this.automation, 1);
                    AccessibilityServiceInfo serviceInfo = this.automation.getServiceInfo();
                    serviceInfo.flags |= 80;
                    this.automation.setServiceInfo(serviceInfo);
                    this.automation.setOnAccessibilityEventListener(new UiAutomation.OnAccessibilityEventListener() { // from class: fr.phonemcp.VirtualEngine$$ExternalSyntheticLambda6
                        @Override // android.app.UiAutomation.OnAccessibilityEventListener
                        public final void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
                            this.f$0.lambda$startInternal$4(accessibilityEvent);
                        }
                    });
                    if (z) {
                        PanelPower panelPower = new PanelPower();
                        this.panel = panelPower;
                        panelPower.keepActive(0);
                        this.panel.off();
                        this.panelOff = true;
                        this.lastKeepActive = SystemClock.elapsedRealtime();
                    }
                    this.worker.postDelayed(this.guardTick, 1000L);
                    this.worker.postDelayed(this.watchTasks, 250L);
                    return status();
                }
            }
            throw new IllegalStateException("Android n’a pas créé d’affichage séparé.");
        } catch (Exception e) {
            stopInternal();
            throw readable(e);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$startInternal$2(ImageReader imageReader) {
        Image imageAcquireLatestImage = null;
        try {
            imageAcquireLatestImage = imageReader.acquireLatestImage();
            if (imageAcquireLatestImage != null) {
                this.previewFrames.accept(imageAcquireLatestImage);
            }
        } catch (IllegalStateException unused) {
        } finally {
            if (imageAcquireLatestImage != null) {
                imageAcquireLatestImage.close();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$startInternal$4(AccessibilityEvent accessibilityEvent) {
        final int displayId = accessibilityEvent.getDisplayId();
        final int eventType = accessibilityEvent.getEventType();
        final int windowId = accessibilityEvent.getWindowId();
        this.worker.post(new Runnable() { // from class: fr.phonemcp.VirtualEngine$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$startInternal$3(displayId, eventType, windowId);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$startInternal$3(int i, int i2, int i3) {
        if (i != this.displayId) {
            return;
        }
        if (i2 == 2048) {
            if (i3 == this.windowId) {
                this.contentVersion++;
            }
        } else if (i2 == 4194304 || i2 == 32) {
            this.generation++;
            this.contentVersion++;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void reconcileTasks() throws Exception {
        requireSession();
        if (this.launchedPackages.isEmpty()) {
            return;
        }
        if (this.taskManager == null) {
            Class<?> cls = Class.forName("android.app.IActivityTaskManager");
            this.taskManager = Class.forName("android.app.ActivityTaskManager").getMethod("getService", new Class[0]).invoke(null, new Object[0]);
            this.listRootTasks = cls.getMethod("getAllRootTaskInfos", new Class[0]);
            this.moveRootTask = cls.getMethod("moveRootTaskToDisplay", Integer.TYPE, Integer.TYPE);
        }
        List list = (List) this.listRootTasks.invoke(this.taskManager, new Object[0]);
        String strMainDisplayPackage = mainDisplayPackage();
        for (Object obj : list) {
            Class<?> cls2 = obj.getClass();
            ComponentName componentName = (ComponentName) cls2.getField("topActivity").get(obj);
            if (componentName != null && this.launchedPackages.contains(componentName.getPackageName())) {
                this.taskLeases.observe(componentName.getPackageName(), cls2.getField("taskId").getInt(obj), cls2.getField("displayId").getInt(obj), this.displayId);
            }
        }
        for (Object obj2 : list) {
            Class<?> cls3 = obj2.getClass();
            ComponentName componentName2 = (ComponentName) cls3.getField("topActivity").get(obj2);
            if (componentName2 != null) {
                String packageName = componentName2.getPackageName();
                int i = cls3.getField("taskId").getInt(obj2);
                int i2 = cls3.getField("displayId").getInt(obj2);
                if (i2 == 0 && this.taskLeases.owns(packageName) && cls3.getField("visible").getBoolean(obj2)) {
                    strMainDisplayPackage = packageName;
                }
                if (this.taskLeases.reclaim(packageName, i, i2, this.displayId, (String[]) cls3.getField("childTaskNames").get(obj2))) {
                    requireSession();
                    this.moveRootTask.invoke(this.taskManager, Integer.valueOf(i), Integer.valueOf(this.displayId));
                    clearSnapshot();
                }
            }
        }
        if (strMainDisplayPackage != null && this.taskLeases.owns(strMainDisplayPackage)) {
            if (strMainDisplayPackage.equals(this.lastPreviewRequest)) {
                return;
            }
            this.lastPreviewRequest = strMainDisplayPackage;
            IPreviewCallback iPreviewCallback = this.previewCallback;
            if (iPreviewCallback != null) {
                iPreviewCallback.onPreviewRequested(strMainDisplayPackage);
                return;
            }
            return;
        }
        this.lastPreviewRequest = HttpUrl.FRAGMENT_ENCODE_SET;
    }

    private void requireUnlocked() {
        Context context = this.context;
        if (context == null || !((PowerManager) context.getSystemService(PowerManager.class)).isInteractive() || ((KeyguardManager) this.context.getSystemService(KeyguardManager.class)).isKeyguardLocked()) {
            throw new IllegalStateException("Téléphone verrouillé ou mis en veille. Déverrouillez-le puis relancez la session. Pour garder le contrôle dalle éteinte, utilisez l’option dédiée dans Phone MCP.");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void requireSession() {
        if (Thread.currentThread().isInterrupted()) {
            throw new IllegalStateException("Commande annulée après expiration. Relisez avant d’agir.");
        }
        if (this.displayId <= 0 || this.display == null || SystemClock.elapsedRealtime() >= this.deadline) {
            throw new IllegalStateException("Affichage parallèle arrêté ou session expirée.");
        }
        if (!((UserManager) this.context.getSystemService(UserManager.class)).isUserUnlocked()) {
            throw new IllegalStateException("Déverrouillez Android après le redémarrage.");
        }
        requireIsolatedDisplay();
    }

    private void requireIsolatedDisplay() {
        VirtualDisplay virtualDisplay = this.display;
        if (virtualDisplay == null || !virtualDisplay.getDisplay().isValid() || this.displayId <= 0 || (this.display.getDisplay().getFlags() & 896) != 896) {
            throw new SecurityException("L’isolation et le verrouillage indépendant de l’affichage ne sont pas confirmés.");
        }
    }

    private int displayGroupId() throws Exception {
        if (this.display == null || this.displayId <= 0) {
            return -1;
        }
        Class<?> cls = Class.forName("android.view.DisplayInfo");
        Object objNewInstance = cls.getConstructor(new Class[0]).newInstance(new Object[0]);
        if (((Boolean) Display.class.getMethod("getDisplayInfo", cls).invoke(this.display.getDisplay(), objNewInstance)).booleanValue()) {
            return cls.getField("displayGroupId").getInt(objNewInstance);
        }
        return -1;
    }

    private JSONObject status() throws Exception {
        int iDisplayGroupId = displayGroupId();
        VirtualDisplay virtualDisplay = this.display;
        JSONObject jSONObjectPut = new JSONObject().put("ready", this.displayId > 0).put("displayId", this.displayId).put("displayGroupId", iDisplayGroupId).put("width", WIDTH).put("height", HEIGHT).put("mode", "parallel").put("independentKeyguard", this.displayId > 0).put("independentPowerGroup", iDisplayGroupId > 0).put("sharedSleepRecovery", this.sharedSleepRecovery).put("resumeWithoutRestart", this.displayId > 0).put("displayState", virtualDisplay == null ? 0 : virtualDisplay.getDisplay().getState()).put("physicalPanelOff", this.panelOff).put("requestedPanelOff", this.requestedPanelOff);
        Context context = this.context;
        JSONObject jSONObjectPut2 = jSONObjectPut.put("deviceInteractive", context != null && ((PowerManager) context.getSystemService(PowerManager.class)).isInteractive());
        Context context2 = this.context;
        return jSONObjectPut2.put("keyguardLocked", context2 != null && ((KeyguardManager) context2.getSystemService(KeyguardManager.class)).isKeyguardLocked()).put("error", this.stoppedReason).put("lastCommandError", this.lastCommandError).put("previewError", this.previewError).put("readOnlyPreview", this.displayId > 0).put("previewTransport", this.previewMirror.active() ? "surface" : "frames").put("captureInProgress", this.captureBusy.get()).put("uid", Process.myUid()).put("windows", windowSummary());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ JSONObject lambda$restorePanel$5() throws Exception {
        PanelPower panelPower = this.panel;
        if (panelPower != null) {
            panelPower.restore();
        }
        this.panelOff = false;
        return status();
    }

    JSONObject restorePanel() throws Exception {
        return (JSONObject) onWorker(new Callable() { // from class: fr.phonemcp.VirtualEngine$$ExternalSyntheticLambda7
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return this.f$0.lambda$restorePanel$5();
            }
        });
    }

    JSONObject execute(final String str, final JSONObject jSONObject) throws Exception {
        if (!"status".equals(str) && ((Boolean) onWorker(new Callable() { // from class: fr.phonemcp.VirtualEngine$$ExternalSyntheticLambda14
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return Boolean.valueOf(this.f$0.prepareDisplay());
            }
        })).booleanValue()) {
            Thread.sleep(180L);
        }
        return (JSONObject) onWorker(new Callable() { // from class: fr.phonemcp.VirtualEngine$$ExternalSyntheticLambda15
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return this.f$0.lambda$execute$6(str, jSONObject);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ JSONObject lambda$execute$6(String str, JSONObject jSONObject) throws Exception {
        if (jSONObject == null) {
            jSONObject = new JSONObject();
        }
        return executeInternal(str, jSONObject);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean prepareDisplay() throws Exception {
        requireSession();
        if (this.displayLease == null) {
            PowerManager.WakeLock wakeLock = (PowerManager.WakeLock) PowerManager.class.getMethod("newWakeLock", Integer.TYPE, String.class, Integer.TYPE).invoke(this.context.getSystemService(PowerManager.class), 6, "phonemcp:ui-command", Integer.valueOf(this.displayId));
            this.displayLease = wakeLock;
            wakeLock.setReferenceCounted(false);
        }
        this.displayLease.acquire(35000L);
        if (this.display.getDisplay().getState() == 2) {
            return false;
        }
        if (this.panel == null) {
            this.panel = new PanelPower();
        }
        boolean z = displayGroupId() <= 0;
        if (z) {
            this.panel.off();
            this.panelOff = true;
            this.sharedSleepRecovery = true;
        }
        this.panel.wakeVirtual(this.displayId);
        long jUptimeMillis = SystemClock.uptimeMillis() + 600;
        while (this.display.getDisplay().getState() != 2 && SystemClock.uptimeMillis() < jUptimeMillis) {
            SystemClock.sleep(30L);
        }
        if (z) {
            this.panel.off();
            this.worker.postDelayed(new Runnable() { // from class: fr.phonemcp.VirtualEngine$$ExternalSyntheticLambda9
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$prepareDisplay$7();
                }
            }, 180L);
        }
        if (this.display.getDisplay().getState() == 2) {
            return true;
        }
        throw new IllegalStateException("L’affichage séparé ne s’est pas réveillé. Aucun réveil de l’écran principal n’a été effectué.");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$prepareDisplay$7() {
        PanelPower panelPower;
        if (this.sharedSleepRecovery && this.panelOff && (panelPower = this.panel) != null) {
            try {
                panelPower.off();
            } catch (Exception unused) {
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:149:0x0350 A[Catch: all -> 0x0398, TRY_LEAVE, TryCatch #0 {all -> 0x0398, blocks: (B:37:0x00e3, B:39:0x00e7, B:41:0x00f3, B:43:0x00fb, B:45:0x0103, B:47:0x0114, B:49:0x011a, B:147:0x034b, B:149:0x0350, B:152:0x0370, B:153:0x0377, B:51:0x0124, B:53:0x012a, B:56:0x0132, B:58:0x0143, B:60:0x0149, B:62:0x014f, B:64:0x0155, B:66:0x015b, B:68:0x0165, B:70:0x016b, B:72:0x0175, B:74:0x0189, B:76:0x0192, B:77:0x019a, B:79:0x01a0, B:81:0x01a6, B:86:0x01b4, B:88:0x01c3, B:90:0x01d9, B:92:0x01df, B:93:0x0209, B:94:0x0210, B:95:0x0211, B:96:0x0218, B:97:0x0219, B:99:0x021f, B:103:0x0232, B:104:0x0238, B:106:0x0246, B:108:0x024c, B:109:0x025e, B:110:0x0265, B:111:0x0266, B:112:0x026d, B:113:0x026e, B:114:0x0275, B:115:0x0276, B:116:0x027d, B:117:0x027e, B:118:0x0285, B:119:0x0286, B:120:0x028d, B:121:0x028e, B:123:0x0296, B:125:0x029e, B:127:0x02ac, B:132:0x02c0, B:137:0x02d0, B:139:0x02da, B:141:0x02e0, B:143:0x02f2, B:145:0x02f8, B:146:0x0317, B:154:0x0378, B:155:0x037f, B:156:0x0380, B:157:0x0387, B:158:0x0388, B:159:0x038f, B:160:0x0390, B:161:0x0397), top: B:214:0x00e3 }] */
    /* JADX WARN: Code duplicated, block: B:152:0x0370 A[Catch: all -> 0x0398, TRY_ENTER, TryCatch #0 {all -> 0x0398, blocks: (B:37:0x00e3, B:39:0x00e7, B:41:0x00f3, B:43:0x00fb, B:45:0x0103, B:47:0x0114, B:49:0x011a, B:147:0x034b, B:149:0x0350, B:152:0x0370, B:153:0x0377, B:51:0x0124, B:53:0x012a, B:56:0x0132, B:58:0x0143, B:60:0x0149, B:62:0x014f, B:64:0x0155, B:66:0x015b, B:68:0x0165, B:70:0x016b, B:72:0x0175, B:74:0x0189, B:76:0x0192, B:77:0x019a, B:79:0x01a0, B:81:0x01a6, B:86:0x01b4, B:88:0x01c3, B:90:0x01d9, B:92:0x01df, B:93:0x0209, B:94:0x0210, B:95:0x0211, B:96:0x0218, B:97:0x0219, B:99:0x021f, B:103:0x0232, B:104:0x0238, B:106:0x0246, B:108:0x024c, B:109:0x025e, B:110:0x0265, B:111:0x0266, B:112:0x026d, B:113:0x026e, B:114:0x0275, B:115:0x0276, B:116:0x027d, B:117:0x027e, B:118:0x0285, B:119:0x0286, B:120:0x028d, B:121:0x028e, B:123:0x0296, B:125:0x029e, B:127:0x02ac, B:132:0x02c0, B:137:0x02d0, B:139:0x02da, B:141:0x02e0, B:143:0x02f2, B:145:0x02f8, B:146:0x0317, B:154:0x0378, B:155:0x037f, B:156:0x0380, B:157:0x0387, B:158:0x0388, B:159:0x038f, B:160:0x0390, B:161:0x0397), top: B:214:0x00e3 }] */
    private JSONObject executeInternal(String str, JSONObject jSONObject) throws Exception {
        String strUrl;
        ResolveInfo resolveInfoResolveActivity;
        boolean zPerformAction;
        VirtualEngine virtualEngine = this;
        if ("status".equals(str)) {
            JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("allowedLeasePackages");
            if (jSONArrayOptJSONArray != null) {
                HashSet hashSet = new HashSet();
                for (int i = 0; i < jSONArrayOptJSONArray.length(); i++) {
                    hashSet.add(jSONArrayOptJSONArray.optString(i));
                }
                virtualEngine.launchedPackages.retainAll(hashSet);
                virtualEngine.taskLeases.retain(hashSet);
                if (virtualEngine.previewMirror.active() && !virtualEngine.taskLeases.owns(virtualEngine.previewMirror.pkg)) {
                    virtualEngine.previewMirror.clear();
                }
            }
            return virtualEngine.status();
        }
        virtualEngine.requireSession();
        String string = jSONObject.getString("packageName");
        if (!AccessPolicy.validPackage(string) || PhoneAccessibilityService.forbiddenPackage(virtualEngine.context, string)) {
            throw new SecurityException("Identifiant d’application refusé.");
        }
        if ("open_app".equals(str) || "open_url".equals(str)) {
            if (string.equals(virtualEngine.mainDisplayPackage())) {
                throw new IllegalStateException("Cette app est actuellement utilisée sur l’écran principal. Choisissez une autre app pour conserver les deux usages séparés.");
            }
            Intent intent = "open_url".equals(str) ? new Intent("android.intent.action.VIEW", Uri.parse(FilePolicy.url(jSONObject.getString("url")))).setPackage(string) : virtualEngine.context.getPackageManager().getLaunchIntentForPackage(string);
            if ("open_url".equals(str) && (resolveInfoResolveActivity = virtualEngine.context.getPackageManager().resolveActivity(intent, 0)) != null) {
                intent.setComponent(new ComponentName(resolveInfoResolveActivity.activityInfo.packageName, resolveInfoResolveActivity.activityInfo.name));
            }
            if (intent == null) {
                throw new IllegalStateException("App non lançable.");
            }
            if (intent.getComponent() == null || !string.equals(intent.getComponent().getPackageName())) {
                throw new SecurityException("Point d’entrée de l’app invalide.");
            }
            virtualEngine.clearSnapshot();
            ArrayList arrayList = new ArrayList(Arrays.asList("/system/bin/am", "start", "--display", Integer.toString(virtualEngine.displayId), "-a", intent.getAction(), "-n", intent.getComponent().flattenToString(), "-f", Integer.toString(402653184)));
            if ("open_url".equals(str)) {
                arrayList.add("-d");
                strUrl = FilePolicy.url(jSONObject.getString("url"));
            } else {
                arrayList.add("-c");
                strUrl = "android.intent.category.LAUNCHER";
            }
            arrayList.add(strUrl);
            Process processStart = new ProcessBuilder(arrayList).redirectErrorStream(true).start();
            if (!processStart.waitFor(5L, TimeUnit.SECONDS)) {
                processStart.destroyForcibly();
                throw new IllegalStateException("Android n’a pas confirmé l’ouverture de l’app.");
            }
            String str2 = new String(processStart.getInputStream().readNBytes(4000), StandardCharsets.UTF_8);
            if (processStart.exitValue() != 0 || str2.contains("Error:") || str2.contains("Exception")) {
                throw new IllegalStateException("Ouverture sur l’affichage parallèle refusée : " + str2.substring(0, Math.min(700, str2.length())));
            }
            if (!string.equals(BuildConfig.APPLICATION_ID)) {
                virtualEngine.launchedPackages.add(string);
                try {
                    virtualEngine.reconcileTasks();
                } catch (Exception unused) {
                }
            }
            return new JSONObject().put("requested", true).put("displayId", virtualEngine.displayId).put("instruction", "Relisez phone_snapshot sur cet affichage avant une action.");
        }
        if ("snapshot".equals(str)) {
            return virtualEngine.snapshot(string, jSONObject.optInt("windowId", -1));
        }
        if ("screenshot".equals(str)) {
            return virtualEngine.screenshot(string, jSONObject.optJSONArray("capturePackages"));
        }
        if (!Arrays.asList("click", "long_press", "set_text", "scroll", "back", "tap", "swipe").contains(str)) {
            throw new IllegalArgumentException("Commande parallèle inconnue.");
        }
        AccessibilityNodeInfo accessibilityNodeInfoGuard = virtualEngine.guard(string, virtualEngine.windowId);
        try {
            String str3 = virtualEngine.snapshotId;
            if (str3 == null || !str3.equals(jSONObject.optString("snapshotId")) || !string.equals(virtualEngine.snapshotPackage) || accessibilityNodeInfoGuard.getWindowId() != virtualEngine.windowId || SystemClock.elapsedRealtime() - virtualEngine.snapshotTime > 30000) {
                throw new IllegalStateException("Lecture périmée. Demandez phone_snapshot avant l’action.");
            }
            if ("back".equals(str)) {
                virtualEngine.requireFocusedWindow(accessibilityNodeInfoGuard);
                virtualEngine.key(4);
            } else {
                if (!"tap".equals(str) && !"swipe".equals(str)) {
                    virtualEngine.requireFocusedWindow(accessibilityNodeInfoGuard);
                    AccessibilityNodeInfo accessibilityNodeInfo = virtualEngine.nodes.get(jSONObject.getString("nodeId"));
                    if (accessibilityNodeInfo == null || !accessibilityNodeInfo.refresh()) {
                        throw new IllegalStateException("L’app a remplacé l’élément. Relisez l’écran.");
                    }
                    if (!accessibilityNodeInfo.isVisibleToUser()) {
                        throw new IllegalStateException("L’élément n’est plus visible. Relisez l’écran.");
                    }
                    if (accessibilityNodeInfo.isPassword() || NodeIdentity.protectedAncestor(accessibilityNodeInfo)) {
                        throw new IllegalStateException("Élément protégé.");
                    }
                    if (accessibilityNodeInfo.getWindowId() == accessibilityNodeInfoGuard.getWindowId() && accessibilityNodeInfo.getPackageName() != null && string.contentEquals(accessibilityNodeInfo.getPackageName())) {
                        if (!NodeIdentity.of(accessibilityNodeInfo).equals(virtualEngine.identities.get(jSONObject.getString("nodeId")))) {
                            throw new IllegalStateException("Le texte ou l’état de l’élément a changé. Relisez l’écran.");
                        }
                        virtualEngine.requireSession();
                        if ("click".equals(str)) {
                            zPerformAction = accessibilityNodeInfo.performAction(16);
                        } else if ("long_press".equals(str)) {
                            zPerformAction = accessibilityNodeInfo.isLongClickable() && accessibilityNodeInfo.performAction(32);
                            if (!zPerformAction) {
                                virtualEngine.requireFocusedWindow(accessibilityNodeInfoGuard);
                                if (containsPassword(accessibilityNodeInfoGuard, new int[]{0}, 0)) {
                                    throw new IllegalStateException("Appui long refusé sur un champ protégé.");
                                }
                                Rect rect = new Rect();
                                Rect rect2 = new Rect();
                                accessibilityNodeInfo.getBoundsInScreen(rect);
                                accessibilityNodeInfoGuard.getBoundsInScreen(rect2);
                                if (rect.isEmpty() || !rect2.contains(rect)) {
                                    throw new SecurityException("L’élément dépasse la fenêtre lue.");
                                }
                                virtualEngine.gesture(rect.centerX(), rect.centerY(), rect.centerX(), rect.centerY(), Math.max(1050, Math.min(1800, ViewConfiguration.getLongPressTimeout() + 150)));
                            }
                        } else if ("scroll".equals(str)) {
                            zPerformAction = accessibilityNodeInfo.performAction("backward".equals(jSONObject.getString("direction")) ? 8192 : 4096);
                        } else {
                            String string2 = jSONObject.getString("text");
                            if (string2.length() > 4000 || !accessibilityNodeInfo.isEditable()) {
                                throw new IllegalArgumentException("Champ non éditable ou texte trop long.");
                            }
                            Bundle bundle = new Bundle();
                            bundle.putCharSequence("ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE", string2);
                            zPerformAction = accessibilityNodeInfo.performAction(2097152, bundle);
                        }
                        virtualEngine.clearSnapshot();
                        if (zPerformAction) {
                            throw new IllegalStateException("L’app a refusé l’action. Relisez l’écran.");
                        }
                        JSONObject jSONObjectPut = new JSONObject().put("performed", true).put("displayId", virtualEngine.displayId).put("instruction", "Relisez phone_snapshot pour vérifier le résultat.");
                        accessibilityNodeInfoGuard.recycle();
                        return jSONObjectPut;
                    }
                    throw new IllegalStateException("Élément hors de la fenêtre lue.");
                }
                if (virtualEngine.snapshotGeneration != virtualEngine.generation || virtualEngine.snapshotContentVersion != virtualEngine.contentVersion) {
                    throw new IllegalStateException("Le contenu a changé. Relisez avant un geste par coordonnées.");
                }
                virtualEngine.requireFocusedWindow(accessibilityNodeInfoGuard);
                if (containsPassword(accessibilityNodeInfoGuard, new int[]{0}, 0)) {
                    throw new IllegalStateException("Action par coordonnées refusée sur un champ protégé.");
                }
                Rect rect3 = new Rect();
                accessibilityNodeInfoGuard.getBoundsInScreen(rect3);
                if (!rect3.contains(jSONObject.getInt("tap".equals(str) ? "x" : "fromX"), jSONObject.getInt("tap".equals(str) ? "y" : "fromY")) || ("swipe".equals(str) && !rect3.contains(jSONObject.getInt("toX"), jSONObject.getInt("toY")))) {
                    throw new SecurityException("Le geste dépasse la fenêtre lue.");
                }
                if ("tap".equals(str)) {
                    virtualEngine.gesture(jSONObject.getInt("x"), jSONObject.getInt("y"), jSONObject.getInt("x"), jSONObject.getInt("y"), 60);
                    virtualEngine = this;
                } else {
                    virtualEngine = this;
                    virtualEngine.gesture(jSONObject.getInt("fromX"), jSONObject.getInt("fromY"), jSONObject.getInt("toX"), jSONObject.getInt("toY"), Math.max(100, Math.min(1000, jSONObject.optInt("durationMs", 350))));
                }
            }
            zPerformAction = true;
            virtualEngine.clearSnapshot();
            if (zPerformAction) {
                throw new IllegalStateException("L’app a refusé l’action. Relisez l’écran.");
            }
            JSONObject jSONObjectPut2 = new JSONObject().put("performed", true).put("displayId", virtualEngine.displayId).put("instruction", "Relisez phone_snapshot pour vérifier le résultat.");
            accessibilityNodeInfoGuard.recycle();
            return jSONObjectPut2;
        } catch (Throwable th) {
            accessibilityNodeInfoGuard.recycle();
            throw th;
        }
    }

    private String mainDisplayPackage() {
        List<AccessibilityWindowInfo> list;
        UiAutomation uiAutomation = this.automation;
        String string = null;
        if (uiAutomation == null || (list = uiAutomation.getWindowsOnAllDisplays().get(0)) == null) {
            return null;
        }
        try {
            for (AccessibilityWindowInfo accessibilityWindowInfo : list) {
                if (accessibilityWindowInfo.getType() == 1) {
                    AccessibilityNodeInfo root = accessibilityWindowInfo.getRoot();
                    if (root != null) {
                        try {
                            if (root.getPackageName() != null) {
                                string = root.getPackageName().toString();
                                if (accessibilityWindowInfo.isFocused() || accessibilityWindowInfo.isActive()) {
                                    if (root != null) {
                                        root.recycle();
                                    }
                                    Iterator<AccessibilityWindowInfo> it = list.iterator();
                                    while (it.hasNext()) {
                                        it.next().recycle();
                                    }
                                    return string;
                                }
                            }
                        } catch (Throwable th) {
                            if (root != null) {
                                root.recycle();
                            }
                            throw th;
                        }
                    }
                    if (root != null) {
                        root.recycle();
                    }
                }
            }
            Iterator<AccessibilityWindowInfo> it2 = list.iterator();
            while (it2.hasNext()) {
                it2.next().recycle();
            }
            return string;
        } catch (Throwable th2) {
            Iterator<AccessibilityWindowInfo> it3 = list.iterator();
            while (it3.hasNext()) {
                it3.next().recycle();
            }
            throw th2;
        }
    }

    private AccessibilityNodeInfo guard(String str) {
        return guard(str, -1);
    }

    private AccessibilityNodeInfo guard(String str, int i) {
        AccessibilityNodeInfo root;
        requireSession();
        List<AccessibilityWindowInfo> list = this.automation.getWindowsOnAllDisplays().get(this.displayId);
        if (list == null) {
            throw new IllegalStateException("Aucune fenêtre sur l’affichage parallèle. Ouvrez d’abord l’app.");
        }
        AccessibilityNodeInfo accessibilityNodeInfo = null;
        try {
            WindowPolicy.Info info = null;
            for (AccessibilityWindowInfo accessibilityWindowInfo : list) {
                if (accessibilityWindowInfo.getType() != 2 && (root = accessibilityWindowInfo.getRoot()) != null) {
                    String string = root.getPackageName() == null ? HttpUrl.FRAGMENT_ENCODE_SET : root.getPackageName().toString();
                    WindowPolicy.Info info2 = new WindowPolicy.Info(accessibilityWindowInfo.getId(), string, accessibilityWindowInfo.getLayer(), accessibilityWindowInfo.isActive(), accessibilityWindowInfo.isFocused());
                    if (!str.equals(string) || ((i >= 0 && accessibilityWindowInfo.getId() != i) || WindowPolicy.choose(Arrays.asList(info, info2), str) != info2)) {
                        root.recycle();
                    } else {
                        if (accessibilityNodeInfo != null) {
                            accessibilityNodeInfo.recycle();
                        }
                        accessibilityNodeInfo = root;
                        info = info2;
                    }
                }
            }
            if (accessibilityNodeInfo == null) {
                throw new IllegalStateException("L’app demandée n’est pas visible sur l’affichage parallèle. L’écran principal n’est jamais utilisé en secours.");
            }
            Iterator<AccessibilityWindowInfo> it = list.iterator();
            while (it.hasNext()) {
                it.next().recycle();
            }
            return accessibilityNodeInfo;
        } catch (Throwable th) {
            if (accessibilityNodeInfo != null) {
                accessibilityNodeInfo.recycle();
            }
            Iterator<AccessibilityWindowInfo> it2 = list.iterator();
            while (it2.hasNext()) {
                it2.next().recycle();
            }
            throw th;
        }
    }

    private void requireFocusedWindow(AccessibilityNodeInfo accessibilityNodeInfo) {
        List<AccessibilityWindowInfo> list = this.automation.getWindowsOnAllDisplays().get(this.displayId);
        boolean z = false;
        if (list != null) {
            try {
                for (AccessibilityWindowInfo accessibilityWindowInfo : list) {
                    if (accessibilityWindowInfo.getId() == accessibilityNodeInfo.getWindowId() && accessibilityWindowInfo.isFocused()) {
                        z = true;
                    }
                }
                Iterator<AccessibilityWindowInfo> it = list.iterator();
                while (it.hasNext()) {
                    it.next().recycle();
                }
            } catch (Throwable th) {
                Iterator<AccessibilityWindowInfo> it2 = list.iterator();
                while (it2.hasNext()) {
                    it2.next().recycle();
                }
                throw th;
            }
        }
        if (!z) {
            throw new IllegalStateException("La fenêtre demandée n’a plus le focus sur l’affichage parallèle. Relisez l’écran.");
        }
    }

    private void requireCaptureWindow(String str, JSONArray jSONArray) {
        String string;
        List<AccessibilityWindowInfo> list = this.automation.getWindowsOnAllDisplays().get(this.displayId);
        if (list == null) {
            throw new IllegalStateException("Aucune fenêtre à capturer.");
        }
        try {
            Iterator<AccessibilityWindowInfo> it = list.iterator();
            while (it.hasNext()) {
                AccessibilityNodeInfo root = it.next().getRoot();
                if (root != null) {
                    try {
                        string = root.getPackageName() == null ? HttpUrl.FRAGMENT_ENCODE_SET : root.getPackageName().toString();
                    } catch (Throwable th) {
                        if (root != null) {
                            root.recycle();
                        }
                        throw th;
                    }
                }
                boolean zEquals = str.equals(string);
                if (jSONArray != null) {
                    for (int i = 0; i < jSONArray.length(); i++) {
                        if (string.equals(jSONArray.optString(i))) {
                            zEquals = true;
                        }
                    }
                }
                if (root == null || !zEquals || containsPassword(root, new int[]{0}, 0)) {
                    throw new IllegalStateException("Capture refusée : fenêtre non autorisée, inaccessible ou champ protégé. Actualisez phone_status.");
                }
                if (root != null) {
                    root.recycle();
                }
            }
            Iterator<AccessibilityWindowInfo> it2 = list.iterator();
            while (it2.hasNext()) {
                it2.next().recycle();
            }
        } catch (Throwable th2) {
            Iterator<AccessibilityWindowInfo> it3 = list.iterator();
            while (it3.hasNext()) {
                it3.next().recycle();
            }
            throw th2;
        }
    }

    private JSONArray windowSummary() throws Exception {
        List<AccessibilityWindowInfo> list;
        JSONArray jSONArray = new JSONArray();
        UiAutomation uiAutomation = this.automation;
        if (uiAutomation != null && this.displayId > 0 && (list = uiAutomation.getWindowsOnAllDisplays().get(this.displayId)) != null) {
            try {
                for (AccessibilityWindowInfo accessibilityWindowInfo : list) {
                    AccessibilityNodeInfo root = accessibilityWindowInfo.getRoot();
                    if (root != null) {
                        try {
                            if (root.getPackageName() != null) {
                                Rect rect = new Rect();
                                accessibilityWindowInfo.getBoundsInScreen(rect);
                                jSONArray.put(new JSONObject().put("windowId", accessibilityWindowInfo.getId()).put("packageName", root.getPackageName().toString()).put("focused", accessibilityWindowInfo.isFocused()).put("active", accessibilityWindowInfo.isActive()).put("layer", accessibilityWindowInfo.getLayer()).put("type", accessibilityWindowInfo.getType()).put("bounds", new JSONArray(new int[]{rect.left, rect.top, rect.right, rect.bottom})));
                            }
                        } catch (Throwable th) {
                            if (root != null) {
                                root.recycle();
                            }
                            throw th;
                        }
                    }
                    if (root != null) {
                        root.recycle();
                    }
                }
                Iterator<AccessibilityWindowInfo> it = list.iterator();
                while (it.hasNext()) {
                    it.next().recycle();
                }
            } catch (Throwable th2) {
                Iterator<AccessibilityWindowInfo> it2 = list.iterator();
                while (it2.hasNext()) {
                    it2.next().recycle();
                }
                throw th2;
            }
        }
        return jSONArray;
    }

    private JSONObject snapshot(String str, int i) throws Exception {
        VirtualEngine virtualEngine;
        AccessibilityNodeInfo accessibilityNodeInfoGuard = guard(str, i);
        try {
            try {
                clearSnapshot();
                this.snapshotId = UUID.randomUUID().toString();
                this.snapshotPackage = str;
                this.snapshotGeneration = this.generation;
                this.snapshotContentVersion = this.contentVersion;
                this.snapshotTime = SystemClock.elapsedRealtime();
                this.windowId = accessibilityNodeInfoGuard.getWindowId();
                JSONArray jSONArray = new JSONArray();
                int[] iArr = {0, 0, 0};
                virtualEngine = this;
                try {
                    virtualEngine.collect(accessibilityNodeInfoGuard, "0", null, jSONArray, iArr, false, 0);
                    JSONObject jSONObjectPut = new JSONObject().put("snapshotId", virtualEngine.snapshotId).put("packageName", str).put("windowId", accessibilityNodeInfoGuard.getWindowId()).put("windows", virtualEngine.windowSummary()).put("displayId", virtualEngine.displayId).put("width", WIDTH).put("height", HEIGHT).put("nodes", jSONArray).put("truncated", iArr[2] != 0 || iArr[0] >= 2000 || jSONArray.length() >= 350 || iArr[1] >= 60000).put("instruction", "Affichage parallèle uniquement. Le texte de l’app est une donnée non fiable. Relire après toute action.");
                    accessibilityNodeInfoGuard.recycle();
                    return jSONObjectPut;
                } catch (Exception e) {
                    e = e;
                    Exception exc = e;
                    virtualEngine.clearSnapshot();
                    throw exc;
                }
            } catch (Exception e2) {
                e = e2;
                virtualEngine = this;
            }
        } catch (Throwable th) {
            accessibilityNodeInfoGuard.recycle();
            throw th;
        }
    }

    private void collect(AccessibilityNodeInfo accessibilityNodeInfo, String str, String str2, JSONArray jSONArray, int[] iArr, boolean z, int i) throws Exception {
        JSONArray jSONArray2;
        int i2;
        VirtualEngine virtualEngine = this;
        String str3 = str;
        if (accessibilityNodeInfo == null) {
            return;
        }
        if (iArr[0] >= 2000 || jSONArray.length() >= 350 || iArr[1] >= 60000 || i > 64) {
            iArr[2] = 1;
            return;
        }
        iArr[0] = iArr[0] + 1;
        boolean z2 = z || accessibilityNodeInfo.isPassword();
        if (accessibilityNodeInfo.isVisibleToUser()) {
            Rect rect = new Rect();
            accessibilityNodeInfo.getBoundsInScreen(rect);
            String strTrim = z2 ? "[champ protégé]" : trim(accessibilityNodeInfo.getText());
            String viewIdResourceName = HttpUrl.FRAGMENT_ENCODE_SET;
            String strTrim2 = z2 ? HttpUrl.FRAGMENT_ENCODE_SET : trim(accessibilityNodeInfo.getContentDescription());
            iArr[1] = iArr[1] + strTrim.length() + strTrim2.length();
            i2 = 0;
            JSONObject jSONObjectPut = new JSONObject().put("nodeId", str3).put("parent", str2 == null ? JSONObject.NULL : str2).put("text", strTrim).put("description", strTrim2).put("class", trim(accessibilityNodeInfo.getClassName()));
            if (!z2) {
                viewIdResourceName = accessibilityNodeInfo.getViewIdResourceName();
            }
            JSONObject jSONObjectPut2 = jSONObjectPut.put("viewId", viewIdResourceName).put("clickable", !z2 && accessibilityNodeInfo.isClickable()).put("editable", !z2 && accessibilityNodeInfo.isEditable()).put("scrollable", !z2 && accessibilityNodeInfo.isScrollable()).put("enabled", accessibilityNodeInfo.isEnabled()).put("checkable", !z2 && accessibilityNodeInfo.isCheckable()).put("checked", !z2 && accessibilityNodeInfo.isChecked()).put("selected", !z2 && accessibilityNodeInfo.isSelected()).put("longClickable", !z2 && accessibilityNodeInfo.isLongClickable()).put("bounds", new JSONArray(new int[]{rect.left, rect.top, rect.right, rect.bottom}));
            jSONArray2 = jSONArray;
            jSONArray2.put(jSONObjectPut2);
            if (!z2) {
                virtualEngine.nodes.put(str3, AccessibilityNodeInfo.obtain(accessibilityNodeInfo));
                virtualEngine.identities.put(str3, NodeIdentity.of(accessibilityNodeInfo));
            }
        } else {
            jSONArray2 = jSONArray;
            i2 = 0;
        }
        if (z2) {
            return;
        }
        int i3 = i2;
        while (i3 < accessibilityNodeInfo.getChildCount() && iArr[i2] < 2000 && jSONArray2.length() < 350 && iArr[1] < 60000) {
            AccessibilityNodeInfo child = accessibilityNodeInfo.getChild(i3);
            try {
                virtualEngine.collect(child, str3 + "." + i3, str3, jSONArray2, iArr, false, i + 1);
                if (child != null) {
                    child.recycle();
                }
                i3++;
                virtualEngine = this;
                str3 = str;
                jSONArray2 = jSONArray;
            } catch (Throwable th) {
                if (child != null) {
                    child.recycle();
                }
                throw th;
            }
        }
    }

    private static String trim(CharSequence charSequence) {
        if (charSequence == null) {
            return HttpUrl.FRAGMENT_ENCODE_SET;
        }
        String string = charSequence.toString();
        return string.substring(0, Math.min(string.length(), Segment.SHARE_MINIMUM));
    }

    private static boolean containsPassword(AccessibilityNodeInfo accessibilityNodeInfo, int[] iArr, int i) {
        int i2 = iArr[0] + 1;
        iArr[0] = i2;
        if (i2 > 1000 || i > 50) {
            return true;
        }
        if (accessibilityNodeInfo == null) {
            return false;
        }
        if (accessibilityNodeInfo.isVisibleToUser() && accessibilityNodeInfo.isPassword()) {
            return true;
        }
        for (int i3 = 0; i3 < accessibilityNodeInfo.getChildCount(); i3++) {
            AccessibilityNodeInfo child = accessibilityNodeInfo.getChild(i3);
            try {
                if (containsPassword(child, iArr, i + 1)) {
                    return true;
                }
                if (child != null) {
                    child.recycle();
                }
            } finally {
                if (child != null) {
                    child.recycle();
                }
            }
        }
        return false;
    }

    private JSONObject screenshot(String str, JSONArray jSONArray) throws Exception {
        Bitmap bitmapCaptureBitmap;
        requireCaptureWindow(str, jSONArray);
        AccessibilityNodeInfo accessibilityNodeInfoGuard = guard(str);
        try {
            if (containsPassword(accessibilityNodeInfoGuard, new int[]{0}, 0)) {
                throw new IllegalStateException("Capture refusée : champ protégé ou écran trop complexe.");
            }
            accessibilityNodeInfoGuard.recycle();
            try {
                bitmapCaptureBitmap = captureBitmap();
                if (bitmapCaptureBitmap != null) {
                    try {
                        if (bitmapCaptureBitmap.getWidth() == WIDTH && bitmapCaptureBitmap.getHeight() == HEIGHT) {
                            requireCaptureWindow(str, jSONArray);
                            AccessibilityNodeInfo accessibilityNodeInfoGuard2 = guard(str);
                            try {
                                if (containsPassword(accessibilityNodeInfoGuard2, new int[]{0}, 0)) {
                                    throw new IllegalStateException("L’écran protégé a changé pendant la capture.");
                                }
                                accessibilityNodeInfoGuard2.recycle();
                                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                bitmapCaptureBitmap.compress(Bitmap.CompressFormat.JPEG, 65, byteArrayOutputStream);
                                if (byteArrayOutputStream.size() > 300000) {
                                    throw new IllegalStateException("Capture trop volumineuse. Réessayez après avoir changé de vue.");
                                }
                                JSONObject jSONObjectPut = new JSONObject().put("mimeType", "image/jpeg").put("data", Base64.encodeToString(byteArrayOutputStream.toByteArray(), 2)).put("width", WIDTH).put("height", HEIGHT).put("displayId", this.displayId).put("coordinateSpace", new JSONObject().put("unit", "snapshot_pixels").put("originX", 0).put("originY", 0).put("scaleX", 1).put("scaleY", 1));
                                if (bitmapCaptureBitmap != null) {
                                    bitmapCaptureBitmap.recycle();
                                }
                                return jSONObjectPut;
                            } catch (Throwable th) {
                                accessibilityNodeInfoGuard2.recycle();
                                throw th;
                            }
                        }
                    } catch (Throwable th2) {
                        th = th2;
                        if (bitmapCaptureBitmap != null) {
                            bitmapCaptureBitmap.recycle();
                        }
                        throw th;
                    }
                }
                throw new IllegalStateException("Capture de l’affichage parallèle indisponible.");
            } catch (Throwable th3) {
                th = th3;
                bitmapCaptureBitmap = null;
            }
        } catch (Throwable th4) {
            accessibilityNodeInfoGuard.recycle();
            throw th4;
        }
    }

    JSONObject previewFrame(JSONObject jSONObject) throws Exception {
        final String string = jSONObject.getString("packageName");
        final JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("capturePackages");
        final int iIntValue = ((Integer) onWorker(new Callable() { // from class: fr.phonemcp.VirtualEngine$$ExternalSyntheticLambda11
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return this.f$0.lambda$previewFrame$8(string, jSONArrayOptJSONArray);
            }
        })).intValue();
        byte[] next = this.previewFrames.next();
        onWorker(new Callable() { // from class: fr.phonemcp.VirtualEngine$$ExternalSyntheticLambda12
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return this.f$0.lambda$previewFrame$9(iIntValue, string, jSONArrayOptJSONArray);
            }
        });
        return new JSONObject().put("data", Base64.encodeToString(next, 2)).put("displayId", iIntValue);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ Integer lambda$previewFrame$8(String str, JSONArray jSONArray) throws Exception {
        requireSession();
        if (!this.taskLeases.owns(str)) {
            throw new SecurityException("Cette app n’est plus contrôlée sur l’écran séparé.");
        }
        requireCaptureWindow(str, jSONArray);
        AccessibilityNodeInfo accessibilityNodeInfoGuard = guard(str);
        try {
            if (containsPassword(accessibilityNodeInfoGuard, new int[]{0}, 0)) {
                throw new SecurityException("Champ protégé.");
            }
            accessibilityNodeInfoGuard.recycle();
            return Integer.valueOf(this.displayId);
        } catch (Throwable th) {
            accessibilityNodeInfoGuard.recycle();
            throw th;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ Object lambda$previewFrame$9(int i, String str, JSONArray jSONArray) throws Exception {
        requireSession();
        if (this.displayId != i || !this.taskLeases.owns(str)) {
            throw new SecurityException("L’affichage a changé.");
        }
        requireCaptureWindow(str, jSONArray);
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void requirePreview(String str, JSONArray jSONArray) throws Exception {
        requireSession();
        if (!this.taskLeases.owns(str)) {
            throw new SecurityException("Cette app n’est plus contrôlée sur l’écran séparé.");
        }
        requireCaptureWindow(str, jSONArray);
        AccessibilityNodeInfo accessibilityNodeInfoGuard = guard(str);
        try {
            if (containsPassword(accessibilityNodeInfoGuard, new int[]{0}, 0)) {
                throw new SecurityException("Champ protégé.");
            }
            accessibilityNodeInfoGuard.recycle();
        } catch (Throwable th) {
            accessibilityNodeInfoGuard.recycle();
            throw th;
        }
    }

    JSONObject attachPreview(final JSONObject jSONObject, final SurfaceControl surfaceControl) throws Exception {
        return (JSONObject) onWorker(new Callable() { // from class: fr.phonemcp.VirtualEngine$$ExternalSyntheticLambda10
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return this.f$0.lambda$attachPreview$10(jSONObject, surfaceControl);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ JSONObject lambda$attachPreview$10(JSONObject jSONObject, SurfaceControl surfaceControl) throws Exception {
        String string = jSONObject.getString("packageName");
        String string2 = jSONObject.getString("viewerId");
        if (string2.length() > 80) {
            throw new IllegalArgumentException("Identifiant d’aperçu invalide.");
        }
        JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("capturePackages");
        requirePreview(string, jSONArrayOptJSONArray);
        if (this.context.checkSelfPermission("android.permission.ACCESS_SURFACE_FLINGER") != 0) {
            throw new SecurityException("Android ne permet pas de garantir un miroir sans entrées.");
        }
        this.previewMirror.attach(this.displayId, surfaceControl, string2, string, jSONArrayOptJSONArray, jSONObject.getInt("width"), jSONObject.getInt("height"));
        return new JSONObject().put("active", true).put("visible", true).put("transport", "surface");
    }

    JSONObject renewPreview(final JSONObject jSONObject) throws Exception {
        return (JSONObject) onWorker(new Callable() { // from class: fr.phonemcp.VirtualEngine$$ExternalSyntheticLambda13
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return this.f$0.lambda$renewPreview$11(jSONObject);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ JSONObject lambda$renewPreview$11(JSONObject jSONObject) throws Exception {
        boolean z;
        if (!this.previewMirror.matches(jSONObject.getString("viewerId")) || !jSONObject.getString("packageName").equals(this.previewMirror.pkg)) {
            throw new IllegalStateException("Aperçu graphique arrêté.");
        }
        this.previewMirror.capturePackages = jSONObject.optJSONArray("capturePackages");
        this.previewMirror.deadline = SystemClock.elapsedRealtime() + 2500;
        try {
            requirePreview(this.previewMirror.pkg, this.previewMirror.capturePackages);
            z = true;
        } catch (Exception unused) {
            z = false;
        }
        this.previewMirror.visible(z);
        return new JSONObject().put("active", true).put("visible", z).put("transport", "surface");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ Object lambda$detachPreview$12(String str) throws Exception {
        if (!this.previewMirror.matches(str)) {
            return null;
        }
        this.previewMirror.clear();
        return null;
    }

    void detachPreview(final String str) {
        try {
            onWorker(new Callable() { // from class: fr.phonemcp.VirtualEngine$$ExternalSyntheticLambda8
                @Override // java.util.concurrent.Callable
                public final Object call() {
                    return this.f$0.lambda$detachPreview$12(str);
                }
            });
        } catch (Exception unused) {
        }
    }

    private Bitmap captureBitmap() throws Exception {
        Bitmap bitmap;
        if (!this.captureBusy.compareAndSet(false, true)) {
            throw new IllegalStateException("La capture Android précédente se termine encore. Les autres commandes restent disponibles.");
        }
        final CompletableFuture completableFuture = new CompletableFuture();
        final UiAutomation uiAutomation = this.automation;
        this.captureWorker.execute(new Runnable() { // from class: fr.phonemcp.VirtualEngine$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$captureBitmap$13(uiAutomation, completableFuture);
            }
        });
        try {
            return (Bitmap) completableFuture.get(2500L, TimeUnit.MILLISECONDS);
        } catch (TimeoutException e) {
            if (!completableFuture.completeExceptionally(e) && (bitmap = (Bitmap) completableFuture.getNow(null)) != null) {
                bitmap.recycle();
            }
            throw new IllegalStateException("Capture Android trop lente ; affichage et session conservés. Les autres commandes restent disponibles. Relisez l’état, sans répéter une action.");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$captureBitmap$13(UiAutomation uiAutomation, CompletableFuture completableFuture) {
        try {
            Bitmap bitmapTakeScreenshot = uiAutomation.takeScreenshot();
            if (!completableFuture.complete(bitmapTakeScreenshot) && bitmapTakeScreenshot != null) {
                bitmapTakeScreenshot.recycle();
            }
            this.captureBusy.set(false);
        } catch (Throwable th) {
            try {
                completableFuture.completeExceptionally(th);
            } finally {
                this.captureBusy.set(false);
            }
        }
    }

    private void point(int i, int i2) {
        if (i < 0 || i >= WIDTH || i2 < 0 || i2 >= HEIGHT) {
            throw new IllegalArgumentException("Coordonnées hors de l’affichage parallèle.");
        }
    }

    private void inject(InputEvent inputEvent) throws Exception {
        requireSession();
        if (this.displayId <= 0) {
            throw new SecurityException("Affichage principal interdit.");
        }
        InputEvent.class.getMethod("setDisplayId", Integer.TYPE).invoke(inputEvent, Integer.valueOf(this.displayId));
        if (((Integer) InputEvent.class.getMethod("getDisplayId", new Class[0]).invoke(inputEvent, new Object[0])).intValue() != this.displayId) {
            throw new SecurityException("L’événement ne cible pas l’affichage parallèle.");
        }
        Constructor<?> declaredConstructor = Class.forName("android.hardware.input.InputManager").getDeclaredConstructor(Context.class);
        declaredConstructor.setAccessible(true);
        Object objNewInstance = declaredConstructor.newInstance(this.context);
        if (!((Boolean) objNewInstance.getClass().getMethod("injectInputEvent", InputEvent.class, Integer.TYPE).invoke(objNewInstance, inputEvent, 1)).booleanValue()) {
            throw new IllegalStateException("Android a refusé l’action sur l’affichage parallèle.");
        }
    }

    private void key(int i) throws Exception {
        long jUptimeMillis = SystemClock.uptimeMillis();
        inject(new KeyEvent(jUptimeMillis, jUptimeMillis, 0, i, 0));
        inject(new KeyEvent(jUptimeMillis, SystemClock.uptimeMillis(), 1, i, 0));
    }

    private void gesture(int i, int i2, int i3, int i4, int i5) throws Exception {
        int i6;
        point(i, i2);
        point(i3, i4);
        long jUptimeMillis = SystemClock.uptimeMillis();
        int i7 = 1;
        int iMax = Math.max(1, i5 / 25);
        int i8 = 0;
        while (true) {
            int i9 = iMax + 1;
            if (i8 > i9) {
                return;
            }
            if (i8 == 0) {
                i6 = 0;
            } else {
                i6 = i8 == i9 ? i7 : 2;
            }
            float fMin = Math.min(1.0f, i8 / iMax);
            int i10 = i8;
            MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, SystemClock.uptimeMillis(), i6, i + ((i3 - i) * fMin), i2 + ((i4 - i2) * fMin), 0);
            motionEventObtain.setSource(4098);
            try {
                inject(motionEventObtain);
                motionEventObtain.recycle();
                if (i10 <= iMax) {
                    SystemClock.sleep(i5 / iMax);
                }
                i8 = i10 + 1;
                i7 = 1;
            } catch (Throwable th) {
                motionEventObtain.recycle();
                throw th;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void clearSnapshot() {
        this.generation++;
        this.snapshotId = null;
        this.windowId = -1;
        Iterator<AccessibilityNodeInfo> it = this.nodes.values().iterator();
        while (it.hasNext()) {
            it.next().recycle();
        }
        this.nodes.clear();
        this.identities.clear();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ Object lambda$stop$14() throws Exception {
        stopInternal();
        return null;
    }

    void stop() {
        try {
            onWorker(new Callable() { // from class: fr.phonemcp.VirtualEngine$$ExternalSyntheticLambda4
                @Override // java.util.concurrent.Callable
                public final Object call() {
                    return this.f$0.lambda$stop$14();
                }
            });
        } catch (Exception unused) {
        }
    }

    void destroy() {
        stop();
        this.captureWorker.shutdownNow();
        this.workerThread.quitSafely();
        this.framesThread.quitSafely();
        this.automationThread.quitSafely();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void stopInternal() {
        PowerManager.WakeLock wakeLock = this.displayLease;
        if (wakeLock != null) {
            if (wakeLock.isHeld()) {
                this.displayLease.release();
            }
            this.displayLease = null;
        }
        this.deadline = 0L;
        this.displayId = -1;
        this.worker.removeCallbacks(this.guardTick);
        this.worker.removeCallbacks(this.watchTasks);
        clearSnapshot();
        this.previewMirror.clear();
        this.launchedPackages.clear();
        this.taskLeases.clear();
        this.previewFrames.clear();
        this.lastPreviewRequest = HttpUrl.FRAGMENT_ENCODE_SET;
        this.previewError = HttpUrl.FRAGMENT_ENCODE_SET;
        this.taskManager = null;
        this.listRootTasks = null;
        this.moveRootTask = null;
        PanelPower panelPower = this.panel;
        if (panelPower != null) {
            try {
                panelPower.restore();
            } catch (Exception unused) {
                this.stoppedReason = "La dalle n’a pas pu être rallumée. Utilisez le bouton latéral.";
            }
            this.panel = null;
        }
        this.panelOff = false;
        this.sharedSleepRecovery = false;
        if (this.automation != null) {
            try {
                UiAutomation.class.getMethod("disconnect", new Class[0]).invoke(this.automation, new Object[0]);
            } catch (Exception unused2) {
            }
            this.automation = null;
        }
        VirtualDisplay virtualDisplay = this.display;
        if (virtualDisplay != null) {
            virtualDisplay.release();
            this.display = null;
        }
        ImageReader imageReader = this.reader;
        if (imageReader != null) {
            imageReader.setOnImageAvailableListener(null, null);
            this.reader.close();
            this.reader = null;
        }
    }

    private static Exception readable(Exception exc) {
        Throwable cause = exc;
        while ((cause instanceof InvocationTargetException) && cause.getCause() != null) {
            cause = cause.getCause();
        }
        return new IllegalStateException("Mode parallèle indisponible : " + (cause.getMessage() == null ? cause.getClass().getSimpleName() : cause.getMessage()), cause);
    }
}
