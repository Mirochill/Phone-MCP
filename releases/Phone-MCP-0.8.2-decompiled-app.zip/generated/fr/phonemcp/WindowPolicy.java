package fr.phonemcp;

import java.util.List;

/* JADX INFO: loaded from: classes.dex */
final class WindowPolicy {
    WindowPolicy() {
    }

    static final class Info {
        final boolean active;
        final boolean focused;
        final int id;
        final int layer;
        final String pkg;

        Info(int i, String str, int i2, boolean z, boolean z2) {
            this.id = i;
            this.pkg = str;
            this.layer = i2;
            this.active = z;
            this.focused = z2;
        }
    }

    static Info choose(List<Info> list, String str) {
        Info info = null;
        for (Info info2 : list) {
            if (info2 != null && info2.id >= 0 && str != null && str.equals(info2.pkg) && (info == null || info2.layer > info.layer || ((info2.layer == info.layer && info2.active && !info.active) || (info2.layer == info.layer && info2.active == info.active && info2.focused && !info.focused)))) {
                info = info2;
            }
        }
        return info;
    }

    static boolean backTargets(int i, String str, int i2, String str2) {
        return i >= 0 && i == i2 && str != null && str.equals(str2);
    }
}
